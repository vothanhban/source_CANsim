#include "edittreewidget.h"

editTreeWidget::editTreeWidget(QWidget *parent) :
    QTreeWidget(parent)
{
}
