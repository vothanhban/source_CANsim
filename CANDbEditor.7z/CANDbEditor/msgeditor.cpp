#include "msgeditor.h"
#include "ui_msgeditor.h"

MsgEditor::MsgEditor(QWidget *parent) :
    QDialog(parent)
{
   setupUi(this);
}

MsgEditor::~MsgEditor()
{
    //delete ui;
}
