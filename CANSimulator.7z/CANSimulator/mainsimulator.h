#ifndef MAINSIMULATOR_H
#define MAINSIMULATOR_H

#include <QMainWindow>
#include <QMdiSubWindow>
#include "ui_mainsimulator.h"
#include "measuresetup.h"

class MainSimulator : public QMainWindow, Ui_MainSimulator
{
    Q_OBJECT

public:
    explicit MainSimulator(QWidget *parent = 0);
    ~MainSimulator();
    void setConfigPath(QString path) {m_ConfigPath=path;}
    void showMeasureSetup();

public slots:
    void slotOpenConfig();
    void slotCloseMeasureSetup();
private:
    MeasureSetupModel *m_MeasureModel;
    MeasureSetupWindow * m_MeasureWindow;
    QMdiSubWindow *m_SubWin;
    MeasureSetupItemCommon * m_rootItem;
    QString m_ConfigPath;
};

#endif // MAINSIMULATOR_H
