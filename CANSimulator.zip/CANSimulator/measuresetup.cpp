#include "measuresetup.h"
#include "ui_measuresetup.h"

#include <QDebug>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QPainter>
#include <QToolButton>
#include <QPaintEvent>
#include <QJsonDocument>

MeasureSetupWidget * widgets[10];

MeasureSetupWindow::MeasureSetupWindow(QWidget *parent, MeasureSetupModel * model) :
    QMainWindow(parent)
{
    setupUi(this);
#if 1
    QString buttonStyle = "QToolButton{border:none;background-color:rgba(0, 255, 0,100);}"; //background-color:rgba(0, 255, 0,100);

    activeGridLayout->setSpacing(5);
    int min,max;
    QIcon icon(":/icons/node.png");
    //    min = icon.
    int i=0;
    QWidget * wd = new QWidget();
    wd->setFixedWidth(20);
    wd->setMaximumWidth(50);
    wd->setMaximumHeight(100);
    activeGridLayout->addWidget(wd,10,10);
    activeGridLayout->addWidget(wd,0,0);

    activeGridLayout->setColumnMinimumWidth(10,10);
    widgets[i] = new MeasureSetupWidget(QIcon(":/icons/node.png"),QString("A0"),this);
    widgets[i]->setStyleSheet(buttonStyle);
    widgets[i]->setMinimumSize(50,50);
    widgets[i]->setMaximumSize(100,100);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],10,2);

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(":/icons/node.png"),QString("A1"),this);
    widgets[i]->setStyleSheet(buttonStyle);
    widgets[i]->setMinimumSize(50,50);
    widgets[i]->setMaximumSize(100,100);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],10,3);

    activeGridLayout->addWidget(wd,10,4);

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(":/icons/node.png"),QString("A2"),this);
    widgets[i]->setStyleSheet(buttonStyle);
    widgets[i]->setMinimumSize(100,50);
    widgets[i]->setMaximumSize(200,100);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],10,5);

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(":/icons/node.png"),QString("B1"),this);
    widgets[i]->setStyleSheet(buttonStyle);
    widgets[i]->setMinimumSize(100,50);
    widgets[i]->setMaximumSize(200,100);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],11,5);

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(":/icons/node.png"),QString("B2"),this);
    widgets[i]->setStyleSheet(buttonStyle);
    widgets[i]->setMinimumSize(100,50);
    widgets[i]->setMaximumSize(200,100);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],12,6);
#endif

}

MeasureSetupWindow::~MeasureSetupWindow()
{
    //    delete ui;
}

void MeasureSetupModel::deleteItemsRecursive(MeasureSetupItemCommon *item)
{
    if(!item) return;
    for (int i=0;i<item->childCount();) {
        deleteItemsRecursive(item->child(i));
    }
    delete item;
}

void MeasureSetupModel::loadConfig(const QString &configPath)
{
    /*read Json file and create measure setup*/
    if(m_rootItem){
        /*delete all items*/
        deleteItemsRecursive( m_rootItem);
        m_rootItem = NULL;
    }
#if 1
    //For testing
    MeasureSetupItemCommon * newItem, *tmpItem;
    m_rootItem = new MeasureSetupItemCommon(NULL,E_MeasureSetupItemType_IG,E_MeasureSetupBranch_IG);
    newItem = new MeasureSetupItemCommon(NULL,E_MeasureSetupItemType_Interface,E_MeasureSetupBranch_Main);
    m_rootItem->addChildren(0,newItem);
    tmpItem = newItem;
    newItem =  new MeasureSetupItemCommon(NULL,E_MeasureSetupItemType_Trace,E_MeasureSetupBranch_View);
#else


#endif
}

void MeasureSetupWindow::resizeEvent(QResizeEvent * evt)
{
}

void MeasureSetupWindow::paintEvent(QPaintEvent *evt)
{
    int i = 0;
    activeGridLayout->setSpacing(5);
    widgets[i]->setIconSize(widgets[i]->size());
    i++;
    widgets[i]->setIconSize(widgets[i]->size());
    i++;
    widgets[i]->setIconSize(widgets[i]->size());
    i++;
    widgets[i]->setIconSize(widgets[i]->size());
    i++;
    widgets[i]->setIconSize(widgets[i]->size());

    QPainter  line (this);
    line.setPen(QColor(Qt::red));
    line.drawLine(widgets[0]->pos().x()+widgets[0]->size().width(),
            widgets[0]->pos().y()+widgets[0]->size().height()/2,
            widgets[1]->pos().x(),
            widgets[1]->pos().y()+widgets[1]->size().height()/2
            );

}

void MeasureSetupWidget::mouseReleaseEvent(QMouseEvent *mouse)
{
    switch (mouse->button()) {
    case Qt::RightButton:
    {
        QMenu pPopup (this);
        QAction pAction1 ("Insert filter", this);
        QAction pAction2 ("Break", this);
        pPopup.addAction(&pAction1);
        pPopup.addAction(&pAction2);

        QAction* pItem = pPopup.exec(mouse->globalPos());

        if(pItem == &pAction1)
        {
            qDebug()<< "1";
        }
        else if(pItem == &pAction2)
        {
            qDebug()<< "2";
        }
    }
        break;
    default:
        break;
    }
    QToolButton::mouseReleaseEvent(mouse);
}

MeasureSetupItemCommon::MeasureSetupItemCommon(MeasureSetupItemCommon *parent,E_MeasureSetupItemType itemType ,E_MeasureSetupBranch itemBranch )
{
    m_parentItem = parent;
    m_itemType = itemType ;
    m_itemBranch = itemBranch;
    m_JoinActive = true;
}

MeasureSetupItemCommon::~MeasureSetupItemCommon()
{
    //    foreach (MeasureSetupItemCommon* child, m_childItems) {
    //        if(child && child->getBranch() == getBranch()) delete child;
    //    }
    //    qDeleteAll(m_childItems);
    cleanWidget();
    cleanWindow();
}

MeasureSetupItemCommon *MeasureSetupItemCommon::child(int number)
{
    return m_childItems.value(number);
}

int MeasureSetupItemCommon::childCount() const
{
    return m_childItems.count();
}

int MeasureSetupItemCommon::childNumber() const
{
    if (m_parentItem)
        return m_parentItem->m_childItems.indexOf(const_cast<MeasureSetupItemCommon*>(this));
    return 0;
}

/*   [addChild]*/
/* [Me]-->[currentChild]*/
/*==>[Me]-->[currentChild]*/
/*      |-->[insertChild] */
bool MeasureSetupItemCommon::addChildren(int position, MeasureSetupItemCommon * child)
{
    if (position < 0 || position > m_childItems.size() || child == NULL)
        return false;
    m_childItems.insert(position, child);
    return true;
}

/*   [insertChild]*/
/* [Me]-->[currentChild]*/
/*==>[Me]-->[insertChild]-->[currentChild]*/
bool MeasureSetupItemCommon::insertChildren(int position, MeasureSetupItemCommon * child)
{
    if (position < 0 || position > m_childItems.size() || child == NULL)
        return false;
    MeasureSetupItemCommon * currentChild;
    currentChild = m_childItems.takeAt(position);
    m_childItems.removeAt(position);
    child->m_childItems.insert(0, currentChild);
    m_childItems.insert(position,child);
    currentChild->m_parentItem = child;
    return true;
}

MeasureSetupItemCommon *MeasureSetupItemCommon::parent()
{
    return m_parentItem;
}

bool MeasureSetupItemCommon::removeChildren(MeasureSetupItemCommon * child)
{
    if ( child == NULL )
        return false;
    return  m_childItems.removeOne(child);
}

void MeasureSetupItemCommon::refreshConnection()
{
    disconnect(this,SIGNAL(sendData()));
    foreach (MeasureSetupItemCommon * child, m_childItems) {
        if(child){
            connect(this,SIGNAL(sendData(MessageCommon*)),child,SLOT(rcvData(MessageCommon*)));
        }
    }
}

QJsonValue MeasureSetupItemCommon::saveDocument(QJsonArray & parent )
{
    return QJsonValue();
}
