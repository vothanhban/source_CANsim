#include "mainsimulator.h"
#include "measuresetup.h"
#include <QMdiArea>
#include <QMdiSubWindow>
#include <QFileDialog>
MainSimulator::MainSimulator(QWidget *parent) :
    QMainWindow(parent)
  //    ui(new Ui::MainSimulator)
{
    setupUi(this);
    m_MeasureWindow = NULL;
    m_MeasureModel = NULL;

    connect(actionOpenConfig,SIGNAL(triggered()),this, SLOT(slotOpenConfig()));
    connect(actionSave,SIGNAL(triggered()),this, SLOT(slotSaveConfig()));
    connect(actionSaveAs,SIGNAL(triggered()),this, SLOT(slotSaveAsConfig()));
}

MainSimulator::~MainSimulator()
{
}

void MainSimulator::showMeasureSetup()
{
    if(m_MeasureWindow){
        m_MeasureWindow->showMaximized();
    }else{
        if(!m_MeasureModel){
            m_MeasureModel = new MeasureSetupModel(m_ConfigPath);
        }
        QMdiSubWindow * subWin;
        m_MeasureWindow = new MeasureSetupWindow(this,m_MeasureModel);
        m_MeasureWindow->setWindowTitle(QString("Measurement Setup [") + m_ConfigPath +QString("]"));
        QMdiArea * mdiArea = new QMdiArea(this);
        setCentralWidget(mdiArea);
        subWin =  mdiArea->addSubWindow(m_MeasureWindow,0);
        connect(m_MeasureWindow,SIGNAL(destroyed()),this, SLOT(slotCloseMeasureSetup()));
    }
}

void MainSimulator::slotOpenConfig()
{
    QFileDialog * fileDialog=new QFileDialog();
    //    QString fileName = QFileDialog::getOpenFileName( fileDialog, ("Create new database file"), QDir::currentPath(), ("Database files (*.json);;All files (*.*)"), 0, QFileDialog::DontUseNativeDialog );
    QString fileName = QFileDialog::getOpenFileName( fileDialog, ("Open configuration"), QDir::currentPath(), ("Configuration file (*.json);;All files (*.*)"), 0, QFileDialog::DontUseNativeDialog );
    if(!fileName.isEmpty()){
        if(m_MeasureModel){
            delete m_MeasureModel;
            m_MeasureModel=NULL;
        }
        if(m_MeasureWindow){
            delete m_MeasureWindow;
            m_MeasureWindow = NULL;
        }
        m_MeasureModel =  new MeasureSetupModel(fileName);
        m_ConfigPath = fileName;
        showMeasureSetup();
    }
}

void MainSimulator::slotSaveAsConfig()
{
    QFileDialog * fileDialog=new QFileDialog();
    QString fileName = QFileDialog::getSaveFileName(fileDialog, ("Save configuration"), QDir::currentPath(), ("Configuration file (*.json);;All files (*.*)"), 0, QFileDialog::DontUseNativeDialog );
    if(!fileName.isEmpty()){
        if(m_MeasureModel){
            m_ConfigPath = fileName;
            m_MeasureModel->saveConfig(fileName);
        }
    }
}
void MainSimulator::slotSaveConfig()
{
    if(m_MeasureModel){
        m_MeasureModel->saveConfig(m_ConfigPath);
    }
}

void MainSimulator::slotCloseMeasureSetup(){
    qDebug()<<__FUNCTION__<<__LINE__;
    m_MeasureWindow = NULL;
}

