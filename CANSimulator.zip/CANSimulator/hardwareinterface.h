#ifndef HARDWAREINTERFACE_H
#define HARDWAREINTERFACE_H
#include "ui_HardwareInterface.h"

class HardwareInterfaceManager;

class HardwareInterfaceConfigWindow: public Ui_hardwareinterface
{
public:
    HardwareInterfaceConfigWindow();

private:
    HardwareInterfaceManager * m_HardwareConfig;
};

typedef struct CANHardwareConfig{
    bool m_Used;
    unsigned int m_Baud;
}CANHardwareConfig;


class HardwareInterfaceManager{
public:
    HardwareInterfaceManager();
    ~HardwareInterfaceManager();
    void loadConfig(QJsonValue config); //load config from Json node
    /*                  [{"name":"CAN 1", "baud":500 },
                        {"name":"CAN 2", "baud":500 }]
    */
    QJsonValue saveConfig(); //Save config to an Json node
    void startSimulate();
    void stopSimulate();
    CANHardwareConfig getConfig(unsigned int port); //port 0: can1, 1: can2
    void setConfig(unsigned int port,CANHardwareConfig config );
//Add the protocol APIs here (init, send, recv,...)

private:
    CANHardwareConfig m_HardwareCfg[2]; //Two CAN port
};

#endif // HARDWAREINTERFACE_H
