#include "tracemanager.h"
#include "ui_tracemanager.h"
#include <QDebug>
TraceWindow::TraceWindow(QWidget *parent, TraceManager * tracemanager) :
    QMainWindow(parent)
{
    setupUi(this);
    m_TraceManager = tracemanager;
    if(m_TraceManager){
        qDebug()<< m_TraceManager->getModel();
        m_treeView->setModel(m_TraceManager->getModel());
    }
    connect(m_ActionToggleTimeMode,SIGNAL(triggered()),m_TraceManager,SLOT(toggleTimeDisplay()));
    connect(m_ActionPausePlay,SIGNAL(triggered()),m_TraceManager,SLOT(togglePlayPause()));
}

TraceWindow::~TraceWindow()
{

}

TraceDataModel::TraceDataModel(QObject *parent)
    :MeasureSetupCommonModel(parent),
      m_DeltaT(false),
      m_Play(true)
{

    QVector<QVariant> rootData;
    rootData <<  "Time" << "Channel" << "ID" << "Name" << "Event Type" << "Dir" << "DLC" << "Data";
    rootItem = new MeasureSetupCommonItemModel(rootData, E_ModelItemType_None);
//     qDebug()<< __FUNCTION__ << __LINE__;
}

QVariant TraceDataModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid())
        return QVariant();

    if (role != Qt::DisplayRole &&
            role != Qt::DecorationRole &&
            role != Qt::BackgroundRole &&
            role != Qt::ForegroundRole)
        return QVariant();

    if(role == Qt::DisplayRole){
        MeasureSetupCommonItemModel *item = getItem(index);
        if(item->getType() == E_ModelItemType_Mesg ){
             if(index.column()==E_IndexColumn_Time){
                 if(m_DeltaT == true){
                     return item->data(index.column()).toList().at(0);
                 }else{
                    return item->data(index.column()).toList().at(1);
                 }
             }else if(index.column()==E_IndexColumn_Direction){
                 if(item->data(E_IndexColumn_Direction)==E_Direction_Rx){
                    return QString("Rx");
                 }else{
                    return QString("Tx");
                 }
             }else if(index.column()==E_IndexColumn_EventType){
                if(item->data(E_IndexColumn_EventType)==true){
                    return QString("TxReq");
                }
             }else if(index.column()==E_IndexColumn_ID){
                return QString::number(item->data(index.column()).toUInt(),16).toUpper();
             }else{
                 return item->data(index.column());
             }
        }else  if(item->getType() == E_ModelItemType_SignalInMessage ){
                return item->data(index.column());
        }
        return QVariant();
    }else if(role == Qt::DecorationRole && index.column()== E_IndexColumn_Time){
        MeasureSetupCommonItemModel *item = getItem(index);
        switch (item->getType()) {
        case E_ModelItemType_Mesg:
        {
            QPixmap px(":/icons/message.png");
            return px.scaled(14,14);
        }
            break;
        case E_ModelItemType_Signal:
        case E_ModelItemType_SignalInMessage:
        {
            QPixmap px(":/icons/signal.png");
            return px.scaled(14,14);
        }
            break;
        default:
            break;
        }
    }else if(role == Qt::BackgroundRole){
        MeasureSetupCommonItemModel *item = getItem(index);
        switch (item->getType()) {
            case E_ModelItemType_Mesg:
            if(index.row()%2 != 0){
                return QVariant( QColor( 215, 227, 229 ) );
            }
            break;
        }
    }else if(role == Qt::ForegroundRole){
        if(m_Play == false){
            return QVariant( QColor( 0xa0, 0xa0, 0xa0 ) );
        }
    }
     return QVariant();
}

bool TraceDataModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    bool result = true;
    if (role != Qt::EditRole)
        return false;
    MeasureSetupCommonItemModel *item = getItem(index);
    result = item->setData(index.column(), value);
    if (result)
        emit dataChanged(index, index);
    return result;
}

bool TraceDataModel::setHeaderData(int section, Qt::Orientation orientation,
                                        const QVariant &value, int role)
{
    if (role != Qt::EditRole || orientation != Qt::Horizontal)
        return false;
    bool result = rootItem->setData(section, value);
    if (result)
        emit headerDataChanged(orientation, section, section);
    return result;
}

Qt::ItemFlags TraceDataModel::flags(const QModelIndex &index) const
{
    if (!index.isValid())
        return 0;

    return (QAbstractItemModel::flags(index) & ~Qt::ItemIsEditable);
}


QVariant TraceDataModel::headerData(int section, Qt::Orientation orientation,
                                         int role) const
{
    if (orientation == Qt::Horizontal && role == Qt::DisplayRole)
        return rootItem->data(section);
    return QVariant();
}

void TraceDataModel::reset()
{
    removeRows(0,rowCount());
}

bool TraceManager::process(MeasureSetupMessageCommon * message)
{
    if(!message || m_Play==false)return false;
    int row=-1;
    QModelIndex index;
    MeasureSetupCommonItemModel * item;
    QList <QVariant> times;
    switch (message->getMessageType()) {
    case E_MsgDataID_CANMsg:
    {
        MeasureSetupMessageCAN * __msgCAN = static_cast <MeasureSetupMessageCAN*> (message);
        row  = getMatchRow(__msgCAN->getMessageInfo());
        if(row==-1){
            m_TraceModel->insertRows(m_TraceModel->rowCount(),1,index); //insert at last
            index = m_TraceModel->index(m_TraceModel->rowCount()-1,0);
            if(__msgCAN->getMessageInfo().m_CANSignals.size() > 0){
                m_TraceModel->insertRows(0,__msgCAN->getMessageInfo().m_CANSignals.size(),index);
            }
        }else{
            index = m_TraceModel->index(row,0);
        }
        if(index.isValid()){
            item = m_TraceModel->getItem(index);
            if(item){
                    item->setType(E_ModelItemType_Mesg);
                    if(row!=-1){
                        times.insert(0,__msgCAN->getTimeStamp()-item->data(E_IndexColumn_Time).toList()[1].toLongLong());
                    }else{
                        times.insert(0,0);
                    }
                    times.insert(1,__msgCAN->getTimeStamp());
                    item->setData(E_IndexColumn_Time,QVariant(times));
                    item->setData(E_IndexColumn_ID,__msgCAN->getMessageInfo().m_Id);
                    item->setData(E_IndexColumn_Name,__msgCAN->getMessageInfo().m_Name);
                    item->setData(E_IndexColumn_Direction,__msgCAN->getMessageInfo().m_Direction);
                    item->setData(E_IndexColumn_EventType,__msgCAN->getMessageInfo().m_isReqToTx);
                    item->setData(E_IndexColumn_Channel,__msgCAN->getMessageInfo().m_Channel);
                    item->setData(E_IndexColumn_DLC,__msgCAN->getMessageInfo().m_Len);

                    QString dataStr;
                    QString tmpStr;
                    for(int i=0;i<__msgCAN->getMessageInfo().m_Len;i++){
                        tmpStr = QString("%01").arg(__msgCAN->getMessageInfo().m_Data[i],0,16).toUpper();
                        if(tmpStr.length()==1){
                            dataStr.append("0");
                        }
                        dataStr.append(tmpStr);
                        dataStr.append("  ");
                    }
                    item->setData(E_IndexColumn_Data,dataStr);

                    row = 0;
                    foreach (CANSignalSimulate signal, __msgCAN->getMessageInfo().m_CANSignals) {
                        index=index.child(row,0);
                        item=m_TraceModel->getItem(index);
                        item->setType(E_ModelItemType_SignalInMessage);
                        item->setData(0,signal.m_CANSign.m_Name);
                        item->setData(1,signal.m_Value.dValue);
                        row++;
                        index=index.parent();
                    }
                    /*For signals*/

            }
        }
    }
        break;
    default:
        break;
    }
}

int TraceManager::getMatchRow(CANMessageSimulate CANMsg)
{
    int row=-1;
    MeasureSetupCommonItemModel * item = NULL;
    QModelIndex index;
    for(row=0 ; row< m_TraceModel->rowCount();row++){
        index = m_TraceModel->index(row,0);
        item = m_TraceModel->getItem(index);
        if(item->data(E_IndexColumn_ID) == CANMsg.m_Id &&
                item->data(E_IndexColumn_Direction) == CANMsg.m_Direction &&
                item->data(E_IndexColumn_EventType) == CANMsg.m_isReqToTx &&
                item->data(E_IndexColumn_Channel) == CANMsg.m_Channel &&
                item->data(E_IndexColumn_DLC) == CANMsg.m_Len
                ){
                return row;
        }
    }
    return -1;
}
