#include "interactivemanager.h"
#include "ui_interactivemanager.h"
#include <QSplitter>
#include <QSlider>
#include <QTableWidgetItem>
#include <QItemDelegate>
#include <QComboBox>
#include <QCheckBox>
#include <QMessageBox>
#include <QSpinBox>

typedef enum{
    E_IndexMsgColumn_Name=0,
    E_IndexMsgColumn_ID,
    E_IndexMsgColumn_Channel,
    E_IndexMsgColumn_DLC,
    E_IndexMsgColumn_Trigger,
    E_IndexMsgColumn_Cycle_Check,
    E_IndexMsgColumn_Cycle_Value,
    E_IndexMsgColumn_Cycle_Bar,
    E_IndexMsgColumn_Data
}E_IndexMsgColumn;

typedef enum{
    E_IndexSgnColumn_SB=0,
    E_IndexSgnColumn_Name,
    E_IndexSgnColumn_Raw,
    E_IndexSgnColumn_Phy,
    E_IndexSgnColumn_Unit,
    E_IndexSgnColumn_WaveUsed,
    E_IndexSgnColumn_WaveDef
}E_IndexSgnColumn;

InteractiveManagerWindow::InteractiveManagerWindow(QWidget *parent,QVector<CANMessageSimulate> * msg,CANSimulatorDatabaseAssosiate * db):
    QMainWindow(parent),
    m_AssosiateDb(db),
    m_Msgs(msg)
{
    setupUi(this);
    m_TableWidgetMsg->horizontalHeader()->setDefaultAlignment(Qt::AlignLeft);
    m_TableWidgetSgn->horizontalHeader()->setDefaultAlignment(Qt::AlignLeft);
    //    QString buttonStyle = "QTableWidget{border:none;background-color:rgba(143,188,143,100);}"; //background-color:rgba(0, 255, 0,100);
    //    m_TableWidgetSgn->setStyleSheet(buttonStyle);

    QSplitter * split = new QSplitter(Qt::Vertical) ;
    split->addWidget(m_TableWidgetMsg);
    split->addWidget(m_TableWidgetSgn);

    gridLayout->addWidget(split);
    drawMsgTable();
    if(m_Msgs && m_Msgs->size()>0){
        drawSignTable(m_Msgs->at(0));
    }
    connect(m_TableWidgetMsg,SIGNAL(cellPressed(int,int)),this,SLOT(slotMsgCellClick(int,int)));
    connect(m_AddNewButton,SIGNAL(clicked()),this,SLOT(slotAddMessage()));
    connect(m_DeleteButton,SIGNAL(clicked()),this,SLOT(slotRemoveMessage()));
    connect(m_SpecialFrameButton,SIGNAL(clicked()),this,SLOT(slotSpecialFrame()));
}

void InteractiveManagerWindow::slotAddMessage()
{
    QVector<CANMessageSimulate> rspMsg;
    rspMsg.clear();
    IGInsertMessageDialog dialog(this,m_AssosiateDb,&rspMsg);
    dialog.exec();
    if(rspMsg.size()>0){
        foreach (CANMessageSimulate newMsg, rspMsg) {
            m_Msgs->append(newMsg);
        }
        drawMsgTable();
    }
}

void InteractiveManagerWindow::slotRemoveMessage()
{
    //m_AssosiateDb
    if(m_TableWidgetMsg->currentRow()>=0 &&m_TableWidgetMsg->currentRow() < m_Msgs->size()){
        m_Msgs->remove(m_TableWidgetMsg->currentRow());
        drawMsgTable();
    }
}

void InteractiveManagerWindow::slotSpecialFrame()
{

}

void InteractiveManagerWindow::slotWidgetChange(int value)
{
    QTableWidgetItem * item = NULL;
    int column= sender()->property("column").toInt();
    if(column==E_IndexMsgColumn_Cycle_Bar||
            column==E_IndexMsgColumn_Cycle_Check||
            column==E_IndexMsgColumn_Channel||
            column==E_IndexMsgColumn_DLC
            ){
        for (int i=0;i<m_TableWidgetMsg->rowCount();i++){
            if(m_TableWidgetMsg->cellWidget(i,sender()->property("column").toInt()) == sender()){
                if(column==E_IndexMsgColumn_Cycle_Bar){
                    qDebug()<<"cycle" << value;
                    item = m_TableWidgetMsg->item(i,(int)E_IndexMsgColumn_Cycle_Value);
                    item->setData(Qt::DisplayRole,value);
                }else if(column==E_IndexMsgColumn_Cycle_Check){
                    qDebug()<<"Cycle sent" << value;
                }else if(column==E_IndexMsgColumn_Channel){
                    qDebug()<<"channel" << value;
                }else if(column==E_IndexMsgColumn_DLC){
                    qDebug()<<"DLC" << value;
                }
                m_TableWidgetMsg->setCurrentCell(i,column);
                emit m_TableWidgetMsg->cellPressed(i,column);
                break;
            }
        }
    }
}

void InteractiveManagerWindow::slotWidgetChange(const QString  &value)
{
    int column= sender()->property("column").toInt();
    qDebug()<< __FUNCTION__ << __LINE__ <<column << value;
    if(column>=E_IndexMsgColumn_Data && column <= E_IndexMsgColumn_Data + 7){
        for (int i=0;i<m_TableWidgetMsg->rowCount();i++){
            if(m_TableWidgetMsg->cellWidget(i,sender()->property("column").toInt()) == sender()){
                //                qDebug()<<i<<column << value;
                (*m_Msgs)[i].m_Data[column-E_IndexMsgColumn_Data] = value.toInt(NULL,16);
                m_TableWidgetMsg->setCurrentCell(i,column);
                emit m_TableWidgetMsg->cellPressed(i,column);
                break;
            }
        }
    }
}

void InteractiveManagerWindow::slotSendNow()
{
    qDebug()<< "Send" << m_Running;
    if(m_Running){
        for (int i=0;i<m_TableWidgetMsg->rowCount();i++){
            if(m_TableWidgetMsg->cellWidget(i,E_IndexMsgColumn_Trigger) == sender()){
                //Send message
                break;
            }
        }
    }else{
        QMessageBox::information(this,"Send","The simulation has not been started yet!");
    }
}

void InteractiveManagerWindow::slotMsgCellClick(int row, int column)
{
    //Open
    //    qDebug()<< "click" << row<<column <<endl;
    if(row<m_TableWidgetMsg->rowCount() && row >=0){
        if(m_Msgs && row < m_Msgs->size()){
            drawSignTable(m_Msgs->at(row));
        }
    }
}

void InteractiveManagerWindow::slotSgnWidgetChange(int value)
{
    int column= sender()->property("column").toInt();
    qDebug()<< __FUNCTION__ << __LINE__ << column<< value;
    if(column==E_IndexSgnColumn_WaveUsed ){
        for (int i=0;i<m_TableWidgetSgn->rowCount();i++){
            if(m_TableWidgetSgn->cellWidget(i,sender()->property("column").toInt()) == sender()){
                if(column==E_IndexSgnColumn_WaveUsed){
                    //                    qDebug()<<"Wave used" << value;
                }
                emit m_TableWidgetSgn->cellChanged(i,column);
                break;
            }
        }
    }

}
void InteractiveManagerWindow::slotSgnWidgetChange(qulonglong value)
{
    int column= sender()->property("column").toInt();
    qDebug()<< __FUNCTION__ << __LINE__ << column<< value;
    if(column==E_IndexSgnColumn_Raw){
        for (int i=0;i<m_TableWidgetSgn->rowCount();i++){
            if(m_TableWidgetSgn->cellWidget(i,sender()->property("column").toInt()) == sender()){
                if(column==E_IndexSgnColumn_Raw){
                    //                    qDebug()<<"Raw Value" << value;
                    m_TableWidgetSgn->setCurrentCell(i,column);
                    emit m_TableWidgetSgn->cellChanged(i,column);
                }else{

                }
                break;
            }
        }
    }

}

void InteractiveManagerWindow::slotSgnDefineWave()
{
    int column= sender()->property("column").toInt();
    qDebug()<< __FUNCTION__ << __LINE__ << column;
    if(column==E_IndexSgnColumn_WaveDef  ){
        for (int i=0;i<m_TableWidgetSgn->rowCount();i++){
            if(m_TableWidgetSgn->cellWidget(i,column) == sender()){

                InteractiveSignalDefineDialog dialog(this,&(*m_Msgs)[m_TableWidgetMsg->currentRow()].m_CANSignals[i]);
                dialog.exec();
                QStringList string(QString("None,Sine,Square").split(','));
                static_cast<QToolButton*>(m_TableWidgetSgn->cellWidget(i,column))->setText(
                            string[(*m_Msgs)[m_TableWidgetMsg->currentRow()].m_CANSignals[i].m_WaveForm]
                        );
                break;
            }
        }
    }

}

void InteractiveManagerWindow::slotSgnCellChange(int row, int column)
{
    if(m_Reload == true)return;
    int msgIndex = m_TableWidgetMsg->currentRow();

    qDebug()<< "cell change" << row << column << msgIndex;
    switch (column) {
    case E_IndexSgnColumn_Phy:
    {
        QTableWidgetItem * item = m_TableWidgetSgn->item(row,column);
        double phyValue=0;
        if(item){
            qDebug() << "Phy" <<item->data(Qt::DisplayRole);
            phyValue = item->data(Qt::DisplayRole).toDouble();
        }

        //Need clip min/max physical value
        if(phyValue < (*m_Msgs)[msgIndex].m_CANSignals[row].m_CANSign.m_Min ){
            phyValue = (*m_Msgs)[msgIndex].m_CANSignals[row].m_CANSign.m_Min;
        }else if(phyValue > (*m_Msgs)[msgIndex].m_CANSignals[row].m_CANSign.m_Max){
            phyValue = (*m_Msgs)[msgIndex].m_CANSignals[row].m_CANSign.m_Max;
        }
        qDebug()<< "after clamp" << phyValue;
        ULongLongSpinBox * spinBox = static_cast <ULongLongSpinBox*> (m_TableWidgetSgn->cellWidget(row,E_IndexSgnColumn_Raw));
        if(spinBox){
            qDebug()<<"To raw"<<(*m_Msgs)[msgIndex].m_CANSignals[row].to_signal_value(phyValue).uValue;
            m_Reload = true;
            spinBox->setValue((*m_Msgs)[msgIndex].m_CANSignals[row].to_signal_value(phyValue).uValue);
            (*m_Msgs)[msgIndex].packall();
            drawMsgTable();
            m_Reload = false;
            (*m_Msgs)[msgIndex].m_CANSignals[row].m_Value.dValue = phyValue;
        }
    }
        break;
    case E_IndexSgnColumn_Raw:
    {
        ULongLongSpinBox * spinBox = static_cast <ULongLongSpinBox*> (m_TableWidgetSgn->cellWidget(row,column));
        if(spinBox){
            qDebug() << "Raw" <<spinBox->value();
        }
        (*m_Msgs)[msgIndex].m_CANSignals[row].m_Value.dValue = (*m_Msgs)[msgIndex].m_CANSignals[row].to_physical_value(spinBox->value());
        //        (*m_Msgs)[msgIndex].m_CANSignals[row].m_Value.dValue = phyValue;
        QTableWidgetItem * item = m_TableWidgetSgn->item(row,E_IndexSgnColumn_Phy);
        m_Reload = true;
        item->setData(Qt::DisplayRole,(*m_Msgs)[msgIndex].m_CANSignals[row].m_Value.dValue);
        (*m_Msgs)[msgIndex].packall();
        drawMsgTable();
        m_Reload = false;
    }
        break;
    case E_IndexSgnColumn_WaveUsed:
    {
        QCheckBox * checkBox = static_cast<QCheckBox*>(m_TableWidgetSgn->cellWidget(row,column));
        if(checkBox){
            qDebug() << "Wave used" <<checkBox->isChecked();
            (*m_Msgs)[msgIndex].m_CANSignals[row].m_WaveUsed = checkBox->isChecked();
        }
    }
        break;
    default:
        break;
    }
}

void InteractiveManagerWindow::drawMsgTable()
{
    //Name | Identifier | Channel | DLC | Trigger | Cycle [ms]                  | Data [0-7]  |
    //                                            | <Check> | <Time> | <Slider> |             |
    m_TableWidgetMsg->clear();
    m_Reload = true;
    QColor bgrColor(143,188,143,100);
    m_TableWidgetMsg->setColumnCount(16);
    m_TableWidgetMsg->setHorizontalHeaderLabels(QStringList(QString("Name|Identifier|Channel|DLC|Trigger|Cycle [ms]|||Data [0-7]|||||||||").split("|")));
    m_TableWidgetMsg->setRowCount(m_Msgs->size());

    if(m_Msgs && m_Msgs->size()>0){
        int i = 0;
        QTableWidgetItem * item;
        foreach (CANMessageSimulate  msg, *m_Msgs) {
            //Name
            item = new QTableWidgetItem(msg.m_Name);
            item->setFlags(item->flags() & ~ (Qt::ItemIsEditable | Qt::ItemIsSelectable));
            item->setBackgroundColor(bgrColor);
            m_TableWidgetMsg->setItem(i,E_IndexMsgColumn_Name,item);

            //Identifier
            item = new QTableWidgetItem();
            item->setBackgroundColor(bgrColor);
            if(!msg.m_Name.isEmpty()){
                item->setFlags(item->flags() & ~ (Qt::ItemIsEditable | Qt::ItemIsSelectable));
            }else{

            }
            item->setData(Qt::DisplayRole,QString::number(msg.m_Id,16).toUpper());
            item->setData(Role_IDValue,msg.m_Id);
            m_TableWidgetMsg->setItem(i,E_IndexMsgColumn_ID,item);

            //Channel
            QComboBox * box = new QComboBox(m_TableWidgetMsg);
            box->addItems(QStringList(QString("CAN1,CAN2").split(",")));
            box->setCurrentIndex(msg.m_Channel-1);
            box->setProperty("column",E_IndexMsgColumn_Channel);
            m_TableWidgetMsg->setCellWidget(i,E_IndexMsgColumn_Channel,box);
            connect(box,SIGNAL(currentIndexChanged(int)),this,SLOT(slotWidgetChange(int)));

            //Trigger
            QToolButton * button = new QToolButton(m_TableWidgetMsg);
            button->setText("Send");
            QString buttonStyle = "QToolButton{border:none;}"; //background-color:rgba(0, 255, 0,100);
            button->setStyleSheet(buttonStyle);
            connect(button,SIGNAL(pressed()),this,SLOT(slotSendNow()));

            QFont  f;
            f.setBold(true);
            button->setFont(f);
            m_TableWidgetMsg->setCellWidget(i,E_IndexMsgColumn_Trigger,button);

            //DLC
            QSpinBox *spinBox = new QSpinBox();
            spinBox->setRange(1,msg.m_Len);
            spinBox->setValue((int)msg.m_LenRun);
            spinBox->setProperty("column",E_IndexMsgColumn_DLC);
            spinBox->setProperty("lenrun",msg.m_LenRun);
            spinBox->setProperty("len",msg.m_Len);
            m_TableWidgetMsg->setCellWidget(i,E_IndexMsgColumn_DLC,spinBox);
            connect(spinBox,SIGNAL(valueChanged(int)),this,SLOT(slotWidgetChange(int)));

            item = new QTableWidgetItem();
            item->setBackgroundColor(bgrColor);
            item->setData(Qt::DisplayRole, msg.m_Len);
            item->setFlags(item->flags()| Qt::ItemIsEditable);
            m_TableWidgetMsg->setItem(i,E_IndexMsgColumn_DLC,item);

            //Cycle -  Transmit cycle
            QCheckBox * checkBox = new QCheckBox();
            checkBox->setChecked(msg.m_CycleSent);
            checkBox->setProperty("column",E_IndexMsgColumn_Cycle_Check);

            m_TableWidgetMsg->setCellWidget(i,E_IndexMsgColumn_Cycle_Check,checkBox);
            connect(checkBox,SIGNAL(stateChanged(int)),this,SLOT(slotWidgetChange(int)));

            //Cycle -  Value
            item = new QTableWidgetItem();
            item->setBackgroundColor(bgrColor);
            item->setData(Qt::DisplayRole,msg.m_Cycle);
            item->setFlags(item->flags()| Qt::ItemIsEditable);
            m_TableWidgetMsg->setItem(i,E_IndexMsgColumn_Cycle_Value,item);

            //Cycle -  Slider bar
            QSlider * slider = new QSlider(Qt::Horizontal,this);

            slider->setValue(msg.m_Cycle);
            slider->setProperty("column",E_IndexMsgColumn_Cycle_Bar);
            connect(slider,SIGNAL(valueChanged(int)),this,SLOT(slotWidgetChange(int)));
            slider->setMaximum(1000);
            m_TableWidgetMsg->setCellWidget(i,E_IndexMsgColumn_Cycle_Bar,slider);
            m_TableWidgetMsg->setRowHeight(i,22);

            //Data
            for (int d=0;d<8;d++){
                if(d<msg.m_Len){
                    LineEdit * edit = new LineEdit(this);
                    edit->setStyleSheet(QString("QLineEdit {border:none;}"));
                    HexStringValidator * validate = new HexStringValidator(edit);
                    validate->setRange(0,255);
                    edit->setValidator(validate);
                    edit->setText(QString::number(msg.m_Data[d],16).toUpper());
                    edit->setProperty("column",E_IndexMsgColumn_Data+d);
                    m_TableWidgetMsg->setCellWidget(i,E_IndexMsgColumn_Data+d,edit);
                    connect(edit,SIGNAL(textChanged(QString)),this,SLOT(slotWidgetChange(const QString&)));
                }else{
                    item = new QTableWidgetItem();
                    if(item){
                        item->setFlags(item->flags() & ~ (Qt::ItemIsEditable | Qt::ItemIsSelectable));
                        item->setData(Qt::BackgroundRole,bgrColor);
                        m_TableWidgetMsg->setItem(i,E_IndexMsgColumn_Data+d,item);
                    }
                }
            }
            ++i;

        }
        m_TableWidgetMsg->setCurrentCell(0,0);
    }
    m_TableWidgetMsg->setColumnWidth(E_IndexMsgColumn_Cycle_Check,20);
    m_TableWidgetMsg->setColumnWidth(E_IndexMsgColumn_Cycle_Value,50);
    m_TableWidgetMsg->setColumnWidth(E_IndexMsgColumn_Channel,55);
    m_TableWidgetMsg->setColumnWidth(E_IndexMsgColumn_ID,55);
    m_TableWidgetMsg->setColumnWidth(E_IndexMsgColumn_Trigger,55);
    m_TableWidgetMsg->setColumnWidth(E_IndexMsgColumn_DLC,35);
    m_TableWidgetMsg->setColumnWidth(E_IndexMsgColumn_Data,20);
    m_TableWidgetMsg->setColumnWidth(E_IndexMsgColumn_Data+1,20);
    m_TableWidgetMsg->setColumnWidth(E_IndexMsgColumn_Data+2,20);
    m_TableWidgetMsg->setColumnWidth(E_IndexMsgColumn_Data+3,20);
    m_TableWidgetMsg->setColumnWidth(E_IndexMsgColumn_Data+4,20);
    m_TableWidgetMsg->setColumnWidth(E_IndexMsgColumn_Data+5,20);
    m_TableWidgetMsg->setColumnWidth(E_IndexMsgColumn_Data+6,20);
    m_TableWidgetMsg->setColumnWidth(E_IndexMsgColumn_Data+7,20);

    m_Reload = false;
}

void InteractiveManagerWindow::drawSignTable(const CANMessageSimulate & message)
{
    //SB | Name | Raw | Physical | Unit | Used Waveform | Waveform defined |
    m_Reload = true;
    m_TableWidgetSgn->clear();
    disconnect(m_TableWidgetSgn,SIGNAL(cellChanged(int,int)));
    QColor bgrColor(189,183,107,100);
    m_TableWidgetSgn->setColumnCount(7);
    m_TableWidgetSgn->setHorizontalHeaderLabels(QStringList(QString("SB|Name|Raw|Physical|Unit|Used Waveform|Waveform defined").split("|")));
    m_TableWidgetSgn->setRowCount(message.m_CANSignals.size());
    int i = 0;
    QTableWidgetItem * item;
    foreach (CANSignalSimulate  sgn, message.m_CANSignals) {
        item = new QTableWidgetItem();
        item->setBackgroundColor(bgrColor);
        item->setData(Qt::DisplayRole,sgn.m_StartBit);
        item->setFlags(item->flags()& (~Qt::ItemIsEditable));
        m_TableWidgetSgn->setItem(i,E_IndexSgnColumn_SB,item);

        item = new QTableWidgetItem(sgn.m_CANSign.m_Name);
        item->setBackgroundColor(bgrColor);
        item->setFlags(item->flags()& (~Qt::ItemIsEditable));
        m_TableWidgetSgn->setItem(i,E_IndexSgnColumn_Name,item);

        U_CANValue value = sgn.to_signal_value(sgn.m_Value.dValue);
        ULongLongSpinBox * ulSpinBox = new ULongLongSpinBox(this);
        ulSpinBox->setMaximum(255);
        ulSpinBox->setMinimum(0);
        ulSpinBox->setBase(16);
        ulSpinBox->setValue(value.uValue);
        ulSpinBox->setProperty("column",E_IndexSgnColumn_Raw);
        m_TableWidgetSgn->setCellWidget(i,E_IndexSgnColumn_Raw,ulSpinBox);
        connect(ulSpinBox,SIGNAL(valueChanged(qulonglong)),this,SLOT(slotSgnWidgetChange(qulonglong)));

        //FIXME: need to create checkbox if signal is 1bit, combobox if value table
        item = new QTableWidgetItem();
        item->setBackgroundColor(bgrColor);
        item->setData(Qt::DisplayRole,sgn.m_Value.dValue);
        m_TableWidgetSgn->setItem(i,E_IndexSgnColumn_Phy,item);

        QCheckBox * checkBox = new QCheckBox();
        checkBox->setChecked(sgn.m_WaveUsed);
        checkBox->setProperty("column",E_IndexSgnColumn_WaveUsed);
        m_TableWidgetSgn->setCellWidget(i,E_IndexSgnColumn_WaveUsed,checkBox);
        connect(checkBox,SIGNAL(stateChanged(int)),this,SLOT(slotSgnWidgetChange(int)));

        QToolButton * button = new QToolButton(m_TableWidgetSgn);
        QStringList Wave(QString("None,Sine,Square").split(","));
        button->setText(Wave.at(sgn.m_WaveForm));
        QString buttonStyle = "QToolButton{border:none;background-color:rgba(143,188,143,100);}"; //background-color:rgba(0, 255, 0,100);
        button->setProperty("column",E_IndexSgnColumn_WaveDef);
        button->setStyleSheet(buttonStyle);
        m_TableWidgetSgn->setCellWidget(i,E_IndexSgnColumn_WaveDef,button);

        connect(button,SIGNAL(pressed()),this,SLOT(slotSgnDefineWave()));
        m_TableWidgetSgn->setRowHeight(i,20);
        ++i;
    }
    connect(m_TableWidgetSgn,SIGNAL(cellChanged(int,int)),this,SLOT(slotSgnCellChange(int,int)));
    m_Reload = false;
}

InteractiveManager::InteractiveManager(/*const*/ CANSimulatorDatabaseAssosiate * assosiateDb):
    m_AssosiateDb(assosiateDb)
{
    m_Msgs.clear();
}

bool InteractiveManager::process(MeasureSetupMessageCommon * message )
{
    if(!message) return false;

    switch (message->getMessageType() ) {
    case E_MsgDataID_Timer:
    {
        MeasureSetupMessageTimer * msgTimer = static_cast<MeasureSetupMessageTimer*> (message);
        // Check messages to transmit
        foreach (CANMessageSimulate msg, m_Msgs) {
            if(msg.m_CycleSent && msgTimer->getTimeStamp()%msg.m_Cycle == 0){
                //need transmit this message;
                msg.pack(msgTimer->getTimeStamp());
                msg.m_Direction = E_Direction_Tx;
                MeasureSetupMessageCAN * newMsg =  new MeasureSetupMessageCAN(msgTimer->getTimeStamp(),msg);
                m_Events.append(newMsg);
            }
        }
    }
        break;
    default:
        break;
    }
    if(m_Events.size()>0) return true;
    return false;
}

void InteractiveManager::startSimulate()
{
    m_Running = true;
}

void InteractiveManager::stopSimulate()
{
    m_Running = false;
}

unsigned int InteractiveManager::events()
{
    return m_Events.size();
}

MeasureSetupMessageCommon * InteractiveManager::getEvent()
{
    if(!m_Events.isEmpty()){
       return m_Events.takeFirst();
    }else{
        return NULL;
    }
}

void InteractiveManager::clearEvents()
{
    while(!m_Events.isEmpty()){
        delete m_Events.takeFirst();
    }
}

void InteractiveManager::loadConfig(const QJsonValue & config)
{
    /*
                     {
                           "type": "IG",
                            "AFTER":1,
                            "name":"IG1",
                "MSGS":[
                     {
                     "file":"ECU1.dbc",
                     "name": "ENGINE",
                     "cycle": 100,
                     "enable": true,
                     "txreq": false,
                     "len": 8,
                     "data":[1,2,3,4,5,6,7,8],
                     "SIGNS":[
                            { "name":"SPEED", "sb": 0,"wave":"none","enable":true,
                                "waveprop": {
                                    "none":{},
                                    "sine":{"amplitude":10.0,"cycles":100,"phase":45,"offset":10.0},
                                    "square":{"crestval":10.0, "troughval":0.0,"crestcycles":100, "troughcycles":100}
                                 }
                            }
                      ]
                    }
             ]
         }
*/
    //    qDebug()<< config;
    if(config.isObject()){
        QJsonObject rootObj =  config.toObject();
        QJsonValue tmpValue  =rootObj["MSGS"];
        setName(rootObj["name"].toString());
        //        qDebug()<< tmpValue;
        if(tmpValue.isArray()){
            QJsonArray msgArray = tmpValue.toArray();
            foreach (const QJsonValue & message, msgArray) {
                //                qDebug()<< message;
                QJsonObject msgObj = message.toObject();

                if(!msgObj.isEmpty()){
                    QString msgPath  = msgObj["file"].toString();
                    QString msgName  = msgObj["name"].toString();
                    CANMessageSimulate newMsg = m_AssosiateDb->getMessagesInfo((const QString)msgPath,(const QString)msgName);

                    newMsg.m_Cycle = msgObj["cycle"].toInt();
                    newMsg.m_CycleSent = msgObj["enable"].toBool();
                    newMsg.m_LenRun = msgObj["len"].toInt();
                    QJsonArray dataArray = msgObj["data"].toArray();
                    if(!dataArray.isEmpty()){
                        for(int i = 0; i < 8 && i < newMsg.m_LenRun && i < dataArray.size();i++){
                            newMsg.m_Data[i] = (unsigned char)dataArray.at(i).toInt();
                            qDebug()<<newMsg.m_Data[i];
                        }
                    }
                    qDebug()<<msgPath << msgName <<newMsg.m_DbPath << newMsg.m_Name;
                    if(msgPath == newMsg.m_DbPath && msgName == newMsg.m_Name){
                        QJsonArray sgnArray = msgObj["SIGNS"].toArray();
                        if(!sgnArray.isEmpty()){
                            QJsonObject tmpSgnObj;
                            foreach (const QJsonValue & signal, sgnArray) {
                                for (int s=0;s< newMsg.m_CANSignals.size();s++) {
                                    tmpSgnObj = signal.toObject();
                                    if(newMsg.m_CANSignals[s].m_CANSign.m_Name == tmpSgnObj["name"].toString()){
                                        if(tmpSgnObj["wave"].toString() == QString("sine")){
                                            newMsg.m_CANSignals[s].m_WaveForm = E_CANSignalWaveForm_Sine;
                                        }else if(tmpSgnObj["wave"].toString() == QString("square")){
                                            newMsg.m_CANSignals[s].m_WaveForm = E_CANSignalWaveForm_Square;
                                        }else{
                                            newMsg.m_CANSignals[s].m_WaveForm = E_CANSignalWaveForm_None;
                                        }
                                        newMsg.m_CANSignals[s].m_WaveUsed = tmpSgnObj["enable"].toBool();
                                        QJsonObject tmpWaveProp = tmpSgnObj["waveprop"].toObject();
                                        if(!tmpWaveProp.isEmpty()){
                                            QJsonObject tmpSineProp = tmpWaveProp["sine"].toObject();
                                            qDebug()<<"Sine" << tmpSineProp;
                                            if(!tmpSineProp.isEmpty()){
                                                //                                                "sine":{"amplitude":10.0,"cycles":100,"phase":45,"offset":10.0},
                                                newMsg.m_CANSignals[s].m_WaveFormProperties.m_Sine.m_Amplitude = tmpSineProp["amplitude"].toDouble();
                                                newMsg.m_CANSignals[s].m_WaveFormProperties.m_Sine.m_Offset = tmpSineProp["offset"].toDouble();
                                                newMsg.m_CANSignals[s].m_WaveFormProperties.m_Sine.m_Cycle = tmpSineProp["cycles"].toInt();
                                                newMsg.m_CANSignals[s].m_WaveFormProperties.m_Sine.m_Phase = tmpSineProp["phase"].toInt();
                                            }

                                            QJsonObject tmpSquareProp = tmpWaveProp["square"].toObject();
                                            qDebug()<<"Square" << tmpSquareProp;
                                            if(!tmpSquareProp.isEmpty()){
                                                //                                                "square":{"crestval":10.0, "troughval":0.0,"crestcycles":100, "troughcycles":100}
                                                newMsg.m_CANSignals[s].m_WaveFormProperties.m_Square.m_CycleH = tmpSquareProp["crestcycles"].toInt();
                                                newMsg.m_CANSignals[s].m_WaveFormProperties.m_Square.m_CycleL = tmpSquareProp["troughcycles"].toInt();
                                                newMsg.m_CANSignals[s].m_WaveFormProperties.m_Square.m_PeakH = tmpSquareProp["crestval"].toDouble();
                                                newMsg.m_CANSignals[s].m_WaveFormProperties.m_Square.m_PeakL = tmpSquareProp["troughval"].toDouble();
                                            }

                                        }
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    m_Msgs.append(newMsg);
                }
            }
        }
    }
}

const QJsonValue  InteractiveManager::saveConfig()
{
    /*
{
   "type": "IG",
    "AFTER":1,
    "name":"IG1",
    "MSGS":[
         {
         "file":"ECU1.dbc",
         "name": "ENGINE",
         "cycle": 100,
         "enable": true,
         "txreq": false,
         "len": 8,
         "data":[1,2,3,4,5,6,7,8],
         "SIGNS":[
                { "name":"SPEED", "sb": 0,"wave":"none","enable":true,
                    "waveprop": {
                        "none":{},
                        "sine":{"amplitude":10.0,"cycles":100,"phase":45,"offset":10.0},
                        "square":{"crestval":10.0, "troughval":0.0,"crestcycles":100, "troughcycles":100}
                     }
                }
          ]
        }
 ]
}
*/
    QJsonObject rootObject, msgObject, sgnObj, wavePropObj, sineObj, squareObj;
    QJsonArray msgArray, sgnArray, msgData;
    foreach (const CANMessageSimulate & msg, m_Msgs) {
        if(msg.m_DbPath.isEmpty() || msg.m_isCANErrorFrame == true){
            msgObject["name"] = QString("Can Error frame");
        }else{
            msgObject["file"] = msg.m_DbPath;
            msgObject["name"] = msg.m_Name;
        }
        msgObject["cycle"] = (int)msg.m_Cycle;
        msgObject["enable"] = msg.m_CycleSent;
        msgObject["txreq"] = msg.m_isReqToTx;
        msgObject["len"] = msg.m_LenRun;
#if 1
        while (msgData.size()>0) {
            msgData.removeFirst();
        }
#endif

        for(int i=0;i<msg.m_Len&&i<8;i++){
            msgData.append((int)msg.m_Data[i]);
        }
        msgObject["data"] = msgData;
#if 1
        while (sgnArray.size()>0) {
            sgnArray.removeFirst();
        }
        foreach (const CANSignalSimulate & signal, msg.m_CANSignals) {
            static QStringList waveList=QString("none,sine,square").split(",");
            sgnObj["name"] = signal.m_CANSign.m_Name;
            sgnObj["sb"] = signal.m_StartBit;
            sgnObj["enable"] = signal.m_WaveUsed;
            sgnObj["wave"] = waveList.at(signal.m_WaveForm);

            sineObj["amplitude"] = signal.m_WaveFormProperties.m_Sine.m_Amplitude;
            sineObj["cycles"] = (int)signal.m_WaveFormProperties.m_Sine.m_Cycle;
            sineObj["phase"] = signal.m_WaveFormProperties.m_Sine.m_Phase;
            sineObj["offset"] = signal.m_WaveFormProperties.m_Sine.m_Offset;

            squareObj["crestcycle"] = (int)signal.m_WaveFormProperties.m_Square.m_CycleH;
            squareObj["troughcycles"] = (int)signal.m_WaveFormProperties.m_Square.m_CycleL;
            squareObj["crestval"] = signal.m_WaveFormProperties.m_Square.m_PeakH;
            squareObj["troughval"] = signal.m_WaveFormProperties.m_Square.m_PeakL;

            wavePropObj["sine"]=sineObj;
            wavePropObj["square"]=squareObj;
            wavePropObj["none"]=QJsonObject();

            sgnObj["waveformprop"] = wavePropObj;

            sgnArray.append(sgnObj);
        }
        msgObject["SIGNS"]=sgnArray;
#endif
        msgArray.append(msgObject);
    }
    rootObject["MSGS"]=msgArray;
    rootObject["type"]=QString("IG");
    rootObject["name"]=this->getName();


    return rootObject;
}

InteractiveSignalDefineDialog:: InteractiveSignalDefineDialog(QWidget *parent ,  CANSignalSimulate * signal , unsigned int cycle ):
    QDialog(parent),
    m_Cycle(cycle),
    m_RspSignal(signal)
{
    if(!m_RspSignal) close();
    setupUi(this);

    connect(m_Amplitude,SIGNAL(editingFinished()),this,SLOT(slotEditted()));
    connect(m_Period,SIGNAL(editingFinished()),this,SLOT(slotEditted()));
    connect(m_Phase,SIGNAL(editingFinished()),this,SLOT(slotEditted()));
    connect(m_Offset,SIGNAL(editingFinished()),this,SLOT(slotEditted()));
    connect(m_CrestTime,SIGNAL(editingFinished()),this,SLOT(slotEditted()));
    connect(m_CrestValue,SIGNAL(editingFinished()),this,SLOT(slotEditted()));
    connect(m_TroughTime,SIGNAL(editingFinished()),this,SLOT(slotEditted()));
    connect(m_TroughValue,SIGNAL(editingFinished()),this,SLOT(slotEditted()));
    connect(m_SelectWaveForm,SIGNAL(currentIndexChanged(int)),this,SLOT(slotChangeWaveform(int)));
    slotChangeWaveform((int)m_RspSignal->m_WaveForm);
    m_SelectWaveForm->setCurrentIndex((int)m_RspSignal->m_WaveForm);
    m_SampleTimeWd->setText(QString::number(m_Cycle));
    m_PhyMinWd->setText(QString::number(m_RspSignal->m_CANSign.m_Min));
    m_PhyMaxWd->setText(QString::number(m_RspSignal->m_CANSign.m_Max));

    m_Amplitude->setText(QString::number(m_RspSignal->m_WaveFormProperties.m_Sine.m_Amplitude));
    m_Phase->setText(QString::number(m_RspSignal->m_WaveFormProperties.m_Sine.m_Phase));
    m_Offset->setText(QString::number(m_RspSignal->m_WaveFormProperties.m_Sine.m_Offset ));
    m_Period->setText(QString::number(m_RspSignal->m_WaveFormProperties.m_Sine.m_Cycle));
    m_CrestTime->setText(QString::number(m_RspSignal->m_WaveFormProperties.m_Square.m_CycleH));
    m_CrestValue->setText(QString::number(m_RspSignal->m_WaveFormProperties.m_Square.m_PeakH));
    m_TroughTime->setText(QString::number(m_RspSignal->m_WaveFormProperties.m_Square.m_CycleL));
    m_TroughValue->setText(QString::number(m_RspSignal->m_WaveFormProperties.m_Square.m_PeakL));

    slotEditted();
}

void InteractiveSignalDefineDialog::accept()
{
    QDialog::accept();
}


void InteractiveSignalDefineDialog::slotChangeWaveform(int index)
{
    if(m_RspSignal){
        m_RspSignal->m_WaveForm = (E_CANSignalWaveForm)index;
    }
    qDebug()<<index;
    switch (index) {
    case E_CANSignalWaveForm_None:
        m_BlankPage->setVisible(true);
        m_PageSquare->setVisible(false);
        m_PageSine->setVisible(false);
        break;
    case E_CANSignalWaveForm_Sine:
        m_PageSine->setVisible(true);
        m_BlankPage->setVisible(false);
        m_PageSquare->setVisible(false);

        break;
    case E_CANSignalWaveForm_Square:
        m_PageSquare->setVisible(true);
        m_PageSine->setVisible(false);
        m_BlankPage->setVisible(false);

        break;

    default:
        break;
    }
    slotEditted();
}

void InteractiveSignalDefineDialog::slotEditted(){
    qDebug()<< __FUNCTION__<<m_SelectWaveForm->currentIndex();
    switch (m_SelectWaveForm->currentIndex()) {
    case E_CANSignalWaveForm_None:
        m_Plot->clearGraphs();
        m_Plot->replot();
        break;
    case E_CANSignalWaveForm_Sine:
    {
        m_RspSignal->m_WaveFormProperties.m_Sine.m_Amplitude = m_Amplitude->text().toDouble();
        m_RspSignal->m_WaveFormProperties.m_Sine.m_Cycle = m_Period->text().toUInt();
        m_RspSignal->m_WaveFormProperties.m_Sine.m_Phase = m_Phase->text().toUInt();
        m_RspSignal->m_WaveFormProperties.m_Sine.m_Offset = m_Offset->text().toDouble();
        //TODO: draw value
        QVector<double> x(m_RspSignal->m_WaveFormProperties.m_Sine.m_Cycle*2),y(m_RspSignal->m_WaveFormProperties.m_Sine.m_Cycle*2);
        m_Cycle = 10;
        for(int i=0;i<m_RspSignal->m_WaveFormProperties.m_Sine.m_Cycle*2;i++){
            x[i] = m_Cycle *i;
            y[i] = m_RspSignal->m_WaveFormProperties.m_Sine.m_Amplitude *
                    sin(2*PI * x[i]/(m_Cycle*m_RspSignal->m_WaveFormProperties.m_Sine.m_Cycle)
                        + PI*m_RspSignal->m_WaveFormProperties.m_Sine.m_Phase/180) + m_RspSignal->m_WaveFormProperties.m_Sine.m_Offset ;
        }
        m_Plot->clearGraphs();
        m_Plot->addGraph();
        m_Plot->graph(0)->setData(x, y);

        // give the axes some labels:
        m_Plot->yAxis->setLabel("Value");
        m_Plot->xAxis->setLabel("Time[ms]");

        m_Plot->rescaleAxes();
        m_Plot->replot();

    }
        break;
    case E_CANSignalWaveForm_Square:
    {
        m_RspSignal->m_WaveFormProperties.m_Square.m_CycleH = m_CrestTime->text().toUInt();
        m_RspSignal->m_WaveFormProperties.m_Square.m_CycleL = m_TroughTime->text().toUInt();
        m_RspSignal->m_WaveFormProperties.m_Square.m_PeakH = m_CrestValue->text().toDouble();
        m_RspSignal->m_WaveFormProperties.m_Square.m_PeakL = m_TroughValue->text().toDouble();
        //TODO: draw value
        QVector<double> x((m_RspSignal->m_WaveFormProperties.m_Square.m_CycleH + m_RspSignal->m_WaveFormProperties.m_Square.m_CycleL)*2),
                y((m_RspSignal->m_WaveFormProperties.m_Square.m_CycleH + m_RspSignal->m_WaveFormProperties.m_Square.m_CycleL)*2);
        m_Cycle = 10;
        for(int i=0;i<(m_RspSignal->m_WaveFormProperties.m_Square.m_CycleH + m_RspSignal->m_WaveFormProperties.m_Square.m_CycleL)*2;i++){
            x[i] = i;
            y[i] =  i%(m_RspSignal->m_WaveFormProperties.m_Square.m_CycleH + m_RspSignal->m_WaveFormProperties.m_Square.m_CycleL) <m_RspSignal->m_WaveFormProperties.m_Square.m_CycleH?
                        m_RspSignal->m_WaveFormProperties.m_Square.m_PeakH:m_RspSignal->m_WaveFormProperties.m_Square.m_PeakL;
        }
        m_Plot->clearGraphs();
        m_Plot->addGraph();
        m_Plot->graph(0)->setData(x, y);

        // give the axes some labels:
        m_Plot->yAxis->setLabel("Value");
        m_Plot->xAxis->setLabel("Time[ms]");

        m_Plot->rescaleAxes();
        m_Plot->replot();
    }
        break;
    default:
        break;
    }
}

IGInsertMessageDialog::IGInsertMessageDialog(QWidget *parent,CANSimulatorDatabaseAssosiate * AssosiateDb,QVector<CANMessageSimulate> * rspData):
    QDialog(parent),
    m_RspData(rspData),
    m_AssosiateDb(AssosiateDb)
{
    setupUi(this);
    m_treeWidget->expandAll();

    QStringList paths= m_AssosiateDb->getDbPath();
    QTreeWidgetItem * itemFile, * itemMsgHeader, *itemMsg;
    foreach (QString path, paths) {

        itemFile= new  QTreeWidgetItem();
        itemMsgHeader = new  QTreeWidgetItem();

        itemFile->setData(0,Qt::DisplayRole,path);
        itemFile->setIcon(0,QIcon(":/icons/connection.png"));

        itemMsgHeader->setData(0,Qt::DisplayRole,"Messages");
        itemMsgHeader->setIcon(0,QIcon(":/icons/message.png"));

        itemFile->addChild(itemMsgHeader);

        foreach (CANMessageSimulate msg, m_AssosiateDb->getMessagesInfo()) {
            itemMsg = new  QTreeWidgetItem();
            itemMsg->setData(0,Qt::DisplayRole,msg.m_Name);
            itemMsg->setData(0,Qt::UserRole,msg.m_Id);
            itemMsg->setIcon(0,QIcon(":/icons/message.png"));
            itemMsgHeader->addChild(itemMsg);
        }
        m_treeWidget->insertTopLevelItem(m_treeWidget->topLevelItemCount(),itemFile);
    }
    m_treeWidget->expandAll();

}

void IGInsertMessageDialog::accept()
{
    QList<QTreeWidgetItem *> items = m_treeWidget->selectedItems();
    QTreeWidgetItem * parent;
    foreach (QTreeWidgetItem * currentItem, items) {
        if(currentItem && currentItem->childCount() == 0){
            parent = currentItem->parent();
            if(parent && parent->data(0,Qt::DisplayRole) == QVariant("Messages")){
                parent = parent->parent();
                CANMessageSimulate rspData = m_AssosiateDb->getMessagesInfo(parent->data(0,Qt::DisplayRole).toString(), currentItem->data(0,Qt::DisplayRole).toString());
                if(m_RspData){
                    m_RspData->append(rspData);
                }
            }else         if(parent && parent->data(0,Qt::DisplayRole) == QVariant("Events")){
                parent = parent->parent();
                CANMessageSimulate rspData;
                rspData.m_isCANErrorFrame = true;
                rspData.m_Len = 0;
                rspData.m_LenRun = 0;
                rspData.m_Name = QString("CAN Error frame");
                if(m_RspData){
                    m_RspData->append(rspData);
                }
            }
        }

    }
    QDialog::accept();

}
