#ifndef INTERACTIVEMANAGER_H
#define INTERACTIVEMANAGER_H

#include <QMainWindow>
#include <QStandardItemModel>
#include <QItemDelegate>
#include <QTableWidgetItem>
#include <QVariant>
#include "ui_interactivemanager.h"
#include "measuresetup.h"
#include "measuresetupmessage.h"
#include "simulatormvcommon.h"
#include "ui_insertmessagedialog.h"
#include "ui_interactivesignaldefinedialog.h"
#include <math.h>


class InteractiveManagerWindow : public QMainWindow, Ui_InteractiveManager
{
    Q_OBJECT
    enum{
        Role_IDValue = Qt::UserRole +1,
    };
public:
    explicit InteractiveManagerWindow(QWidget *parent = 0,QVector<CANMessageSimulate> * msg=0,CANSimulatorDatabaseAssosiate * db=0);
    ~InteractiveManagerWindow(){}
    void startSimulate();
    void stopSimulate();
public slots:
    void slotAddMessage();
    void slotRemoveMessage();
    void slotSpecialFrame();

    void slotCellChange(int row, int column){
        qDebug()<< row << column;
    }
    void slotWidgetChange(int value);
    void slotWidgetChange(const QString & value);
    void slotSendNow();
    void slotMsgCellClick(int row, int column);

    void slotSgnWidgetChange(int);
    void slotSgnWidgetChange(qulonglong);
    void slotSgnCellChange(int row, int column);
    void slotSgnDefineWave();
private:
    void updateSignal(int row);
    void updateMessage(int row);
    void drawMsgTable();
    void drawSignTable(const CANMessageSimulate & message);
    CANSimulatorDatabaseAssosiate * m_AssosiateDb;
    QVector<CANMessageSimulate> * m_Msgs;
    bool m_Reload ;
    bool m_Running;
};

class InteractiveManager: public MeasureSetupManagerCommon
{
    Q_OBJECT

public:
    explicit  InteractiveManager(/*const*/ CANSimulatorDatabaseAssosiate * assosiateDb=NULL);
    ~InteractiveManager (){m_Msgs.clear();}
    virtual bool process(MeasureSetupMessageCommon * message = NULL);
    virtual void startSimulate();
    virtual void stopSimulate();
    virtual unsigned int events();
    virtual MeasureSetupMessageCommon * getEvent();
    virtual void clearEvents();
    virtual void loadConfig(QJsonValue config);
    virtual QJsonValue saveConfig();

    QVector<CANMessageSimulate> & getMessageInfo(){return m_Msgs;}
private:
    /*const*/ CANSimulatorDatabaseAssosiate * m_AssosiateDb;
    QVector<CANMessageSimulate> m_Msgs;
    bool m_Running;
};

class InteractiveSignalDefineDialog: public QDialog,Ui_InteractiveSignDefineDialog
{
    Q_OBJECT
public:
    explicit InteractiveSignalDefineDialog(QWidget *parent = NULL,  CANSignalSimulate * signal = NULL, unsigned int cycle = 0);
    void accept();
public slots:
    void slotEditted();
    void slotChangeWaveform(int index);
private:
    CANSignalSimulate * m_RspSignal;
    unsigned int m_Cycle;
};

class IGInsertMessageDialog: public QDialog,Ui_InsertMessageDialog
{
    Q_OBJECT
public:
   IGInsertMessageDialog(QWidget *parent=0,CANSimulatorDatabaseAssosiate * AssosiateDb=NULL,QVector<CANMessageSimulate> * rspData=NULL);
   IGInsertMessageDialog(){}
public Q_SLOTS:
   void accept() ;
private:
    QVector<CANMessageSimulate> * m_RspData;
    CANSimulatorDatabaseAssosiate *m_AssosiateDb;
};

class InteractiveMsgHeaderModel: public QStandardItemModel
{

public:
    QVariant data(const QModelIndex &index, int role) const
    {
        return index.column();
    }
};


#endif // INTERACTIVEMANAGER_H
