#ifndef MEASURESETUP_H
#define MEASURESETUP_H

#include <QMainWindow>
#include <QToolButton>
#include <QThread>
#include <QDebug>
#include <QCloseEvent>
#include<QJsonDocument>
#include <CANDefines.h>
#include "measuresetupmessage.h"
#include "ui_measuresetup.h"
#include "utilities.h"
class MeasureSetupItemCommon;
class MeasureSetupModel;
class MeasureSetupManagerCommon;
class MeasureSetupAbstractTable;
class FilterNodeManager;
class TraceManager;
class InteractiveManager;
class HardwareInterfaceManager;

typedef enum{
    E_MeasureSetupItemType_None=0,
    E_MeasureSetupItemType_Join,
    E_MeasureSetupItemType_Filter,
    E_MeasureSetupItemType_IG,
    E_MeasureSetupItemType_Interface,
    E_MeasureSetupItemType_Trace
}E_MeasureSetupItemType;

typedef enum{
    E_MeasureSetupBranch_None = 0,
    E_MeasureSetupBranch_IG,
    E_MeasureSetupBranch_Main,
    E_MeasureSetupBranch_View,
}E_MeasureSetupBranch;


class MeasureSetupWindow : public QMainWindow,Ui_MeasureSetup
{
    Q_OBJECT
public:
    explicit MeasureSetupWindow(QWidget *parent = 0 , MeasureSetupModel * model=0);
    ~MeasureSetupWindow();
    virtual void resizeEvent(QResizeEvent *);
    virtual void paintEvent(QPaintEvent *evt);
    void drawModel();
    void startSimulate();
    void stopSimulate();
public slots:
    void slotDrawContextMenu(const QPoint & pos);
    void slotOpenOpeWindow();
    void slotTimerTest();

protected:
    virtual void closeEvent(QCloseEvent *evt){evt->ignore();}
private:
    void rePaint();
    MeasureSetupAbstractTable * findItems(MeasureSetupItemCommon * item, int &row, int & column);
    MeasureSetupModel *m_Model;
};

class MeasureSetupModel: public QObject{
    Q_OBJECT
public:
    explicit MeasureSetupModel(const QString &path = QString()){
        m_Running=false;
        m_IGTable = NULL;
        m_ViewTable=NULL;
        m_MainTable = NULL;
        m_AssosiateDb=NULL;
        loadConfig(path);
        //         m_rootItem=NULL;
    }
    ~MeasureSetupModel();

    const QStringList & getAssosiateDb(){
        if(m_AssosiateDb){
            return m_AssosiateDb->getDbPath();
        }
        return QStringList();
    }

    void removeConnection();
    void refreshConnection();
signals:
    void signalModelChange();

public slots:
    void slotAddDbAssosiate(const QString & dbPath){
        if(m_AssosiateDb){
            m_AssosiateDb->addDbPath(dbPath);
        }
    }

    void slotRemoveDbAssosiate(const QString & dbPath){
        if(m_AssosiateDb){
            m_AssosiateDb->removeDbPath(dbPath);
        }
    }

    void saveConfig(const QString & path=QString());

private:
    friend class MeasureSetupWindow;
    void loadConfig(const QString &configPath);

    CANSimulatorDatabaseAssosiate * m_AssosiateDb;
    MeasureSetupAbstractTable *m_IGTable;
    MeasureSetupAbstractTable *m_MainTable;
    MeasureSetupAbstractTable *m_ViewTable;

    bool m_Running;
};

class MeasureSetupWidget: public QToolButton
{
    Q_OBJECT
public:
    MeasureSetupWidget(const QIcon& icon,
                       const QString &text,
                       QWidget *parent=0)
        :QToolButton(parent){
        setIcon(icon);
        setText(text);
    }
    ~MeasureSetupWidget(){}
signals:
    void signalContextMenu(const QPoint & pos);
    void signalDoubleClick();
protected:
    void mouseReleaseEvent(QMouseEvent *);
    bool event(QEvent *e);
private:
};

class MeasureSetupManagerCommon: public QObject
{
    Q_OBJECT
public:
    MeasureSetupManagerCommon(){}
    ~MeasureSetupManagerCommon(){}

    virtual bool process(MeasureSetupMessageCommon * message = NULL){return true;}
    virtual void startSimulate(){}
    virtual void stopSimulate(){}
    virtual unsigned int events(){return 0;}
    virtual MeasureSetupMessageCommon * getEvent(){return NULL;}
    virtual void clearEvents(){}

    virtual void loadConfig(const QJsonValue & config){} //load config from Json node
    virtual const QJsonValue saveConfig(){return QJsonValue();} //Save config to an Json node

    void setName(const QString & name){m_Name = name;}
    QString & getName(){return m_Name;}

signals:
    friend class FilterNodeManager;
    friend class TraceManager;
    friend class InteractiveManager;
    friend class HardwareInterfaceManager;
    void notifyEvent(MeasureSetupMessageCommon msg);

private:
    QString m_Name;
    unsigned long long m_TimeStamp;
};

class MeasureSetupItemCommon: public QObject
{
    Q_OBJECT
public:
    explicit MeasureSetupItemCommon(E_MeasureSetupItemType itemType = E_MeasureSetupItemType_None, E_MeasureSetupBranch itemBranch = E_MeasureSetupBranch_None);
    ~MeasureSetupItemCommon();

    void setType(E_MeasureSetupItemType itemType){m_itemType = itemType;}
    E_MeasureSetupItemType getType(){return m_itemType ;}
    E_MeasureSetupBranch getBranch(){return m_itemBranch;}
    const QJsonValue  saveConfig();
    void loadConfig(const QJsonValue &);

    void cleanWidget(){qDeleteAll(m_widget);}
    void cleanWindow(){
        if(m_OperateWindow) delete m_OperateWindow;
        m_OperateWindow=NULL;
    }

signals:
    void signalDrawContextMenu(const QPoint & pos);
    void signalOpenOpeWindow();
    void sendData( MeasureSetupMessageCommon & data);

public slots:
    void rcvData(MeasureSetupMessageCommon & data);
    void slotCloseOpeWindow(){qDebug()<<"Close windows";m_OperateWindow=NULL;}
    void slotOpenOpeWindow();
    void slotDrawContextMenu(const QPoint & pos);
    virtual void slotEventNotify(MeasureSetupMessageCommon evt){emit sendData(evt);}
    void slotJoinToggle(bool check);

private:
    friend class MeasureSetupModel;
    friend class MeasureSetupWindow;

    E_MeasureSetupItemType m_itemType;
    E_MeasureSetupBranch m_itemBranch;
    QVector <MeasureSetupWidget *>m_widget;
    QWidget * m_OperateWindow;
    MeasureSetupManagerCommon * m_Manager;
    bool m_IsJoin;
    QString m_Name;
private:
    virtual bool processData(MeasureSetupMessageCommon * data = 0){
        if(m_Manager){
            if( m_Manager->process(data)){
                return true;
            }
        }
        return true;
    }
};

class MeasureSetupAbstractTable{

public:
    MeasureSetupAbstractTable();
    ~MeasureSetupAbstractTable();
    int rowCount();
    int columnCount();

    void insertRows(int position, int rows);
    void insertColumns(int row,int position, int columns);

    void removeRows(int position, int rows);
    void removeColumns(int row,int position, int columns);

    void removeAll();
    void setItem(int row, int column, MeasureSetupItemCommon * item)
    {
        if(m_TableItems.size() > row){
            if(m_TableItems[row].size()>column){
                m_TableItems[row][column] =  item;
            }
        }else{
            return;
        }
    }

    MeasureSetupItemCommon * item(int row, int column)
    {
        if(m_TableItems.size() > row){
            if(m_TableItems[row].size()>column){
                return m_TableItems[row] [column];
            }
        }
        return NULL;
    }

private:
    friend class MeasureSetupModel;
    friend class MeasureSetupWindow;
    //    MeasureSetupItemCommon * rootItem;
    QVector< QVector<MeasureSetupItemCommon*> > m_TableItems;
};

#endif // MEASURESETUP_H
