#ifndef MEASURESETUPMESSAGE_H
#define MEASURESETUPMESSAGE_H
#include <utilities.h>
typedef enum{
    E_MsgDataID_None=0,
    E_MsgDataID_Timer,
    E_MsgDataID_CANMsg,
    E_MsgDataID_Command,
}E_MsgDataID;

typedef enum{
    E_MsgCommand_None=0,
    E_MsgCommand_StartSimulate,
    E_MsgCommand_StopSimulate
}E_MsgCommand;

class MeasureSetupMessageCommon{
public:
    MeasureSetupMessageCommon(unsigned long long timestamp=0,
                              E_MsgDataID id=E_MsgDataID_None) :
        m_Timestamp(timestamp),
        m_MsgType(id)
    {}
    E_MsgDataID getMessageType(){return m_MsgType;}
    unsigned long long getTimeStamp(){return m_Timestamp;}
private:
    E_MsgDataID m_MsgType;
    unsigned long long m_Timestamp;
};


class MeasureSetupMessageCAN: public MeasureSetupMessageCommon
{
public:
    MeasureSetupMessageCAN(unsigned long long timestamp=0, const CANMessageSimulate & msg = CANMessageSimulate() ):
        MeasureSetupMessageCommon(timestamp,E_MsgDataID_CANMsg)
    {
        m_CANMsg =msg;
    }
    ~MeasureSetupMessageCAN(){}
    CANMessageSimulate & getMessageInfo(){return m_CANMsg;}
private:
    CANMessageSimulate m_CANMsg;
};

class MeasureSetupMessageCommand: public MeasureSetupMessageCommon
{
    MeasureSetupMessageCommand(unsigned long long timestamp=0, const E_MsgCommand & command = E_MsgCommand_None):
        MeasureSetupMessageCommon(timestamp,E_MsgDataID_CANMsg)
    {
        m_Command = command;
        m_CustomData = NULL;
    }
    ~MeasureSetupMessageCommand(){}

    E_MsgCommand getCommand(){return m_Command;}

private:
    E_MsgCommand m_Command;
    void * m_CustomData;
};

#endif // MEASURESETUPMESSAGE_H
