#ifndef ASSOSIATEDB_H
#define ASSOSIATEDB_H
#include "utilities.h"
#include "candefine.h"
#include "ui_AssosiateDbdialog.h"

typedef struct{
    QString m_Name;
    QString m_Path;
    QVector<CANMessageSimulate> m_Messages;
}CANAssosiateDbInfo;

class CANSimulatorDatabaseAssosiate{
public:
    CANSimulatorDatabaseAssosiate(){}
    ~CANSimulatorDatabaseAssosiate(){}


    const QVector<CANAssosiateDbInfo> &getAssosiateDbInfo(){return m_AssosiateDbInfo;}
//    QVector<CANMessageSimulate> & getMessagesInfo(){return m_Messages;}

    const QStringList getDbPath();
    const QStringList getDbName();


    const CANMessageSimulate  findMessagesInfo(const QString &path,const QString &msgName);
    const CANMessageSimulate  findMessagesInfo(const QString &path,unsigned int id);
    const QString findNameByPath(const QString & path);

    CANMessageSimulate  findMessageById(unsigned int id, unsigned char len);

//    QVector<CANMessageSimulate> & getMessagesByFile(QString &path);
    void test();

public :
    void slotAcceptNewAssosiateDb(const QVector<CANAssosiateDbInfo> & updated);
private:
    void addDbPath(CANAssosiateDbInfo & addedInfo);
    void removeDbPath(CANAssosiateDbInfo & removedInfo);

private:
    QVector<CANAssosiateDbInfo> m_AssosiateDbInfo;
//    QVector<CANMessageSimulate> m_Messages;
};

class AssosiateDbDialog: public QDialog, Ui_AsspsiateDbDialog
{Q_OBJECT

public:
    AssosiateDbDialog(QWidget * parent=0,const QVector<CANAssosiateDbInfo> &  assosiateDb = QVector<CANAssosiateDbInfo>()):
    QDialog(parent),
      m_AssosiateDbInfo(assosiateDb)
    {
        setupUi(this);
//        setAttribute(Qt::WA_DeleteOnClose, true);
        m_TableDb->horizontalHeader()->setDefaultAlignment(Qt::AlignLeft);
        drawAssosiateDb();
        connect(m_AddButton,SIGNAL(clicked()),this,SLOT(slotAddNewDb()));
        connect(m_RemoveButton,SIGNAL(clicked()),this,SLOT(slotRemoveDb()));
        connect(m_TableDb,SIGNAL(clicked(QModelIndex)),this,SLOT(slotSelectDbTableIndex(QModelIndex)));
        connect(m_TableDb,SIGNAL(cellChanged(int,int)),this,SLOT(slotCellChange(int,int)));

    }
public slots:
    void slotAddNewDb();
    void slotRemoveDb();
    void slotCellChange(int row, int column);
    void slotSelectDbTableIndex(QModelIndex);

signals:
    void acceptAssosiateDbInfo(const QVector<CANAssosiateDbInfo> & assosiateDbInfo);
protected:
    void accept()
    {
        qDebug()<< "Accept";
        emit acceptAssosiateDbInfo(m_AssosiateDbInfo);
        QDialog::accept();
    }

private:
    QVector<CANAssosiateDbInfo> m_AssosiateDbInfo;

private:
    void drawAssosiateDb();
};

#endif // ASSOSIATEDB_H
