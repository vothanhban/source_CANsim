#include "assosiatedb.h"
#include <QFile>
#include <QFileDialog>
#include <QMessageBox>
#include<QChar>

const QStringList CANSimulatorDatabaseAssosiate::getDbPath(){
    QStringList retPath;
    foreach (const CANAssosiateDbInfo & dbInfo , m_AssosiateDbInfo) {
        retPath.append(dbInfo.m_Path);
    }
    return retPath;
}

const QStringList CANSimulatorDatabaseAssosiate::getDbName(){
    QStringList retName;
    foreach (const CANAssosiateDbInfo & dbInfo , m_AssosiateDbInfo) {
        retName.append(dbInfo.m_Name);
    }
    return retName;
}
void CANSimulatorDatabaseAssosiate::addDbPath(CANAssosiateDbInfo & addedInfo){
    QFile file(addedInfo.m_Path);
    qDebug()<< "Load Db file: " <<  addedInfo.m_Path;
    addedInfo.m_Messages.clear();
    if(file.open(QIODevice::ReadOnly)){
        qDebug()<< "Open OK ";
        QString string = file.readAll();
        QStringList lines = string.split(QString("\n"),QString::SkipEmptyParts);

        CANSignalSimulate newSignal;
        CANMessageSimulate newMsg;
        foreach (QString line, lines) {
            line.remove(QChar('\r\n'));
            QStringList lineItems =  line.split(QRegularExpression(":| "),QString::SkipEmptyParts);
            if(lineItems.at(0) == QString("SG_")){
                /*SG_ PWM_CVVAL : 48|16@1+ (6.103515625E-005,0) [0|1] ""  NODE1
              -->"SG_", "PWM_CVVAL", "48", "16", "1+", "6.103515625E-005", "0", "0", "1", """", "NODE1"
                  0            1       2     3    4          5             6    7    8     9     10
                  0: SG_
                  1: signal name
                  2: start bit
                  3: length in bit
                  4: format intel/motorola
                  5: factor
                  6: offset
                  7: min
                  8: max
                */
                // :| |@|\\||\\(|\\)|\\[|\\]|,|\\+
                lineItems =  line.split(QRegularExpression(":| |@|\\||\\(|\\)|\\[|\\]|,|\n"),QString::SkipEmptyParts);
                //                qDebug()<<line;
                if(lineItems.size() >= 11){
                    /*
    E_DBCIndexSignal_Name=1,
    E_DBCIndexSignal_StartBit,
    E_DBCIndexSignal_Len,
    E_DBCIndexSignal_ByteOrder,
    E_DBCIndexSignal_ValueType=E_DBCIndexSignal_ByteOrder,
    E_DBCIndexSignal_Factor,
    E_DBCIndexSignal_Offset,
    E_DBCIndexSignal_Min,
    E_DBCIndexSignal_Max,
    E_DBCIndexSignal_VTable,
    E_DBCIndexSignal_Node
*/
                    QString tmpString;
                    //1
                    newSignal.m_CANSign.m_Name = lineItems.at(E_DBCIndexSignal_Name);

                    //2
                    unsigned int added=0;
                    tmpString = lineItems.at(E_DBCIndexSignal_StartBit);
                    if(tmpString.at(0)=='m'){
                        added=1;
                        if(tmpString=="m"){
                            newSignal.m_CANSign.m_Multiplex = E_CANSignalMultiplex_OR;
                        }else{
                            newSignal.m_CANSign.m_Multiplex = E_CANSignalMultiplex_ED;
                            newSignal.m_CANSign.m_MultiplexedValue = tmpString.remove(QChar('m')).toDouble();
                        }
                    }
                    newSignal.m_StartBit = lineItems.at(E_DBCIndexSignal_StartBit+added).toInt();

                    //3
                    newSignal.m_CANSign.m_Length = (unsigned char)lineItems.at(E_DBCIndexSignal_Len+added).toInt();

                    //4
                    tmpString = lineItems.at(E_DBCIndexSignal_ByteOrder+added);

                    if(tmpString.at(0) == '0'){
                        newSignal.m_CANSign.m_ByteOrder = E_CANByteOrder_Motorola;
                    }else{
                        newSignal.m_CANSign.m_ByteOrder = E_CANByteOrder_Intel;
                    }
                    if(tmpString.at(1) == '+'){
                        newSignal.m_CANSign.m_ValueType = E_CANSignalType_UnSigned;
                    }else{
                        newSignal.m_CANSign.m_ValueType = E_CANSignalType_Signed;
                    }

                    //5 E_DBCIndexSignal_Factor
                    newSignal.m_CANSign.m_Factor = lineItems.at(E_DBCIndexSignal_Factor+added).toDouble();

                    //6 E_DBCIndexSignal_Offset,
                    newSignal.m_CANSign.m_Offset = lineItems.at(E_DBCIndexSignal_Offset+added).toDouble();

                    //7 E_DBCIndexSignal_Min,
                    newSignal.m_CANSign.m_Min = lineItems.at(E_DBCIndexSignal_Min+added).toDouble();

                    //8 E_DBCIndexSignal_Max,
                    newSignal.m_CANSign.m_Max  = lineItems.at(E_DBCIndexSignal_Max+added).toDouble();

                    //9 E_DBCIndexSignal_Unit,
                    tmpString = lineItems.at(E_DBCIndexSignal_Unit+added);
                    if(tmpString!="\"\""){
                        newSignal.m_CANSign.m_Unit  = tmpString.remove(QChar('"'));
                    }else{
                        newSignal.m_CANSign.m_Unit.clear();
                    }

                    //10 E_DBCIndexSignal_Node
                    newSignal.m_CANSign.m_Node  = lineItems.at(E_DBCIndexSignal_Node+added);
//                    newMsg.m_CANSignals.append(newSignal);
                    if(addedInfo.m_Messages.size()>0){
                        qDebug()<<addedInfo.m_Messages.size();
                        addedInfo.m_Messages[addedInfo.m_Messages.size()-1].m_CANSignals.append(newSignal);
                    }
                    qDebug()<<"\tSG: " <<newSignal.m_CANSign.m_Name
                           <<newSignal.m_CANSign.m_Length
                          <<newSignal.m_StartBit
                         <<newSignal.m_CANSign.m_Multiplex
                        <<newSignal.m_CANSign.m_MultiplexedValue
                       <<newSignal.m_CANSign.m_ByteOrder
                      <<newSignal.m_CANSign.m_Factor
                     <<newSignal.m_CANSign.m_Offset
                    <<newSignal.m_CANSign.m_Min
                    <<newSignal.m_CANSign.m_Max
                      ;
                }


            }else if(lineItems.at(0) == QString("BO_")){
                newMsg.m_CANSignals.clear();
                newMsg=CANMessageSimulate();
                lineItems =  line.split(QRegularExpression(":| |:|\n"),QString::SkipEmptyParts);
                if(lineItems.size()>=5){
                    newMsg.m_DbPath = addedInfo.m_Path;
                    //1. E_DBCIndexMsg_Id
                    newMsg.m_Id = lineItems.at(E_DBCIndexMsg_Id).toUInt();

                    //2. E_DBCIndexMsg_Name
                    newMsg.m_Name = lineItems.at(E_DBCIndexMsg_Name);

                    //3. E_DBCIndexMsg_Len
                    newMsg.m_Len = newMsg.m_LenRun = (unsigned char)lineItems.at(E_DBCIndexMsg_Len).toInt();

                    //Node. E_DBCIndexMsg_RxNode
                    newMsg.m_RxNodes.append(lineItems.at(E_DBCIndexMsg_RxNode));
                    qDebug()<<"MSG:"
                           <<newMsg.m_Name
                          <<QString("0x") + QString::number(newMsg.m_Id,16)
                         <<newMsg.m_Len
                        <<newMsg.m_RxNodes   ;
                    addedInfo.m_Messages.append(newMsg);
                }
            }
        }
        file.close();
    }
}

void CANSimulatorDatabaseAssosiate::removeDbPath(CANAssosiateDbInfo & removedInfo)
{
    removedInfo.m_Messages.clear();
}

CANMessageSimulate  CANSimulatorDatabaseAssosiate::findMessageById(unsigned int id, unsigned char len)
{
    foreach (const CANAssosiateDbInfo &info, m_AssosiateDbInfo) {
        foreach (const CANMessageSimulate & msg, info.m_Messages) {
            if(msg.m_Len == len &&
                    msg.m_Id == id){
                return msg;
            }
        }
    }
    return CANMessageSimulate();
}

void CANSimulatorDatabaseAssosiate::test(){
//    CANMessageSimulate newMsg;
//    CANSignalSimulate newSignal;

//    newSignal.m_StartBit = 1;
//    newSignal.m_Value.dValue = 1.5;
//    newSignal.m_CANSign.m_Factor = 0.5;
//    newSignal.m_CANSign.m_ByteOrder = E_CANByteOrder_Intel;
//    newSignal.m_CANSign.m_Length = 8;
//    newSignal.m_CANSign.m_Max = 10;
//    newSignal.m_CANSign.m_Min =-10;
//    newSignal.m_CANSign.m_ValueType = E_CANSignalType_Signed;
//    newSignal.m_CANSign.m_Name = QString("SPEED");
//    newSignal.m_WaveForm = E_CANSignalWaveForm_None;
//    newMsg.m_CANSignals.append(newSignal);

//    newSignal.m_CANSign.m_Length = 4;
//    newSignal.m_CANSign.m_Factor = -0.5;
//    newSignal.m_CANSign.m_Name = QString("STATUS");
//    newMsg.m_CANSignals.append(newSignal);

//    newMsg.m_Channel = 1;
//    newMsg.m_Direction = E_Direction_Rx;
//    newMsg.m_DbPath = "ECU1.dbc";
//    newMsg.m_Name = "ENGINE";
//    newMsg.m_Id = 0x300;
//    newMsg.m_isReqToTx = false;
//    newMsg.m_Len = 8;
//    m_Messages.append(newMsg);


//    newMsg.m_Len = 4;

//    newMsg.m_CANSignals.clear();

//    newSignal.m_CANSign.m_Length = 4;
//    newSignal.m_CANSign.m_Name = QString("LEFT-TOP");
//    newMsg.m_CANSignals.append(newSignal);

//    newSignal.m_CANSign.m_Length = 4;
//    newSignal.m_CANSign.m_Name = QString("LEFT-REAR");
//    newMsg.m_CANSignals.append(newSignal);

//    newSignal.m_CANSign.m_Length = 4;
//    newSignal.m_CANSign.m_Name = QString("RIGHT-TOP");
//    newMsg.m_CANSignals.append(newSignal);

//    newSignal.m_CANSign.m_Length = 4;
//    newSignal.m_CANSign.m_Name = QString("RIGHT-REAR");
//    newMsg.m_CANSignals.append(newSignal);

//    newMsg.m_Channel = 2;
//    newMsg.m_Direction = E_Direction_Tx;
//    newMsg.m_DbPath = "ECU1.dbc";
//    newMsg.m_Name = "APA";
//    newMsg.m_Id = 0x301;
//    m_Messages.append(newMsg);
//    CANAssosiateDbInfo assoDb;
//    assoDb.m_Name = "ECU1";
//    assoDb.m_Path = "path/ECU1";
//    m_AssosiateDbInfo.append(assoDb);
}

void CANSimulatorDatabaseAssosiate::slotAcceptNewAssosiateDb(const QVector<CANAssosiateDbInfo> & updatedDbInfo)
{
    bool foundNew=false, foundOld=false;
    qDebug()<<__FUNCTION__<<__LINE__ << updatedDbInfo.size();
    int index=0;
    foreach (const CANAssosiateDbInfo& uInfo, updatedDbInfo) {
        foundOld = false;
        qDebug()<<__FUNCTION__<<__LINE__ << uInfo.m_Name << uInfo.m_Path;
        for(int i = 0;i<m_AssosiateDbInfo.size();i++){
            if(uInfo.m_Path == m_AssosiateDbInfo[i].m_Path){
                //TODO: update the name
                m_AssosiateDbInfo[i].m_Name = uInfo.m_Name;
                foundOld=true;
                break;
            }
        }
        if(!foundOld){
            //Add new db
            CANAssosiateDbInfo addedInfo = updatedDbInfo[index];
            addDbPath(addedInfo);
            m_AssosiateDbInfo.append(addedInfo);
        }
        index++;
    }


    //    foreach (CANAssosiateDbInfo& currentInfo, m_AssosiateDbInfo) {
    for(int i = 0;i<m_AssosiateDbInfo.size();i++){
        foundNew = false;
        foreach (const CANAssosiateDbInfo& uInfo, updatedDbInfo) {
            if(uInfo.m_Path == m_AssosiateDbInfo[i].m_Path){
                //TODO: update the name
                m_AssosiateDbInfo[i].m_Name = uInfo.m_Name;
                foundNew=true;
                break;
            }
        }
        if(!foundNew){
            //remove new db
            removeDbPath(m_AssosiateDbInfo[i]);
            m_AssosiateDbInfo.removeAt(i);
            i--;continue;
        }
    }
}

const QString CANSimulatorDatabaseAssosiate::findNameByPath(const QString & path)
{
    foreach (const CANAssosiateDbInfo& info, m_AssosiateDbInfo) {
        if(info.m_Path== path){
            return info.m_Name;
        }
    }
}

const CANMessageSimulate  CANSimulatorDatabaseAssosiate::findMessagesInfo(const QString &path,const QString &msgName)
{
    foreach (const CANAssosiateDbInfo info, m_AssosiateDbInfo) {
        foreach (const CANMessageSimulate & msg, info.m_Messages) {
            if(msg.m_DbPath == path &&
                    msg.m_Name == msgName){
                return msg;
            }
        }
    }
    return CANMessageSimulate();
}

const CANMessageSimulate  CANSimulatorDatabaseAssosiate::findMessagesInfo(const QString &path,unsigned int id)
{
    foreach (const CANAssosiateDbInfo info, m_AssosiateDbInfo) {
        foreach (const CANMessageSimulate & msg, info.m_Messages) {
            if(msg.m_DbPath == path &&
                    msg.m_Id == id){
                return msg;
            }
        }
    }
    return CANMessageSimulate();
}

void AssosiateDbDialog::slotAddNewDb()
{
    QFileDialog * fileDialog=new QFileDialog();
    QString fileName = QFileDialog::getOpenFileName(fileDialog, ("Select .DBC file"), QDir::currentPath(), ("CAN Database file (*.DBC);;All files (*.*)"), 0, QFileDialog::DontUseNativeDialog );
    QTableWidgetItem *item;
    if(!fileName.isEmpty()){
        foreach (const CANAssosiateDbInfo & info, m_AssosiateDbInfo) {
            if(fileName==info.m_Path){
                QMessageBox::information(this,"Duplicated database", QString("The database file: ") + fileName+QString("\n already existed!"));
                return;
            }
        }
        CANAssosiateDbInfo newInfo ;
        newInfo.m_Name=QStringList(fileName.split("/")).last();
        newInfo.m_Path=fileName;
        m_AssosiateDbInfo.append(newInfo);
        drawAssosiateDb();
    }
}

void AssosiateDbDialog::slotRemoveDb()
{
    if(m_TableDb->currentIndex().isValid()){
        int  ret = QMessageBox::question(this,"Remove database", QString("Do you want to remove database file: \n") +
                                         m_TableDb->item(m_TableDb->currentIndex().row(),1)->data(Qt::DisplayRole).toString() + QString("?"),
                                         QMessageBox::Yes,QMessageBox::No   );
        if(ret== QMessageBox::Yes){
            m_AssosiateDbInfo.removeAt(m_TableDb->currentIndex().row());
            drawAssosiateDb();
        }
    }
}

void AssosiateDbDialog::slotCellChange(int row, int column)
{
    QTableWidgetItem * item;
    item=m_TableDb->item(row,column);
    if(item && column ==0){
        qDebug()<<"Cell change";
        m_AssosiateDbInfo[row].m_Name = item->data(Qt::EditRole).toString();
    }
}

void AssosiateDbDialog::slotSelectDbTableIndex(QModelIndex index)
{
    if(m_TableDb){
        if(index.isValid()){
            m_RemoveButton->setEnabled(true);
        }else{
            m_RemoveButton->setEnabled(false);
        }
    }
}

void AssosiateDbDialog::drawAssosiateDb()
{
    if(m_TableDb){
        m_TableDb->setRowCount(0);
    }
    if(m_AssosiateDbInfo.size()>0){
        int row=0;
        QTableWidgetItem * item;
        foreach (const CANAssosiateDbInfo & DbInfo, m_AssosiateDbInfo) {
            m_TableDb->insertRow(m_TableDb->rowCount());

            item=new QTableWidgetItem(DbInfo.m_Name);
            if(row%2)item->setData(Qt::BackgroundColorRole,QColor(222,222,222));
            m_TableDb->setItem(row,0,item);

            item=new QTableWidgetItem(DbInfo.m_Path);
            item->setFlags(item->flags()& (~Qt::ItemIsEditable));
            if(row%2)item->setData(Qt::BackgroundColorRole,QColor(222,222,222));
            m_TableDb->setItem(row,1,item);
            m_TableDb->setRowHeight(row,18);

            row++;
        }
        m_TableDb->resizeColumnsToContents();
    }
}
