#ifndef HARDWAREINTERFACE_H
#define HARDWAREINTERFACE_H
#include "ui_hardwareinterface.h"
#include "measuresetup.h"
#include "measuresetupmessage.h"
#include"candefine.h"
#include"assosiatedb.h"
#include <QJsonValue>
#include <QSerialPort>
#include <QTimer>
#include <stdint.h>
#include <stdio.h>

class HardwareIO;
class HardwareInterfaceManager;
/*
    uint8_t sourceID;
    uint8_t destID;
    uint8_t sourceType;
    uint8_t destType;
    uint16_t commandID; //E_CommandID
    uint8_t lenght;
*/
#define COMPOSEHEADER(header,command)\
    header.sourceID = E_DeviceID_PC;\
    header.destID = E_DeviceID_BOARD;\
    header.sourceType = E_DeviceType_PC;\
    header.destType = E_DeviceType_BOARD;\
    header.commandID  = command;
typedef enum E_CommandID
{
    //**** using check_alive struct
    E_CommandID_CHECK_ALIVE_REQ             = 	0x0001,		// request to check board
    E_CommandID_CHECK_ALIVE_RES             = 	0x0002,		// response to annouce board situation

    // *** using configuration struct
    E_CommandID_BOARD_GET_CONFIG_REQ        =	0x000D,		// request to get board configuration
    E_CommandID_BOARD_GET_CONFIG_RES        =	0x000E,
    E_CommandID_BOARD_SET_CONFIG_REQ        =	0x000F,     // request to set baudrate for CAN bus
    E_CommandID_BOARD_SET_CONFIG_RES        =	0x0010,

    // *** using simulation struct
    E_CommandID_START_SIMULATION_REQ        =	0x0013,
    E_CommandID_START_SIMULATION_RES        =	0x0014,
    E_CommandID_RECV_CANFRAME               =	0x0015,     // Rx Message come from another node on CAN bus
    E_CommandID_STOP_SIMULATION_REQ         =	0x0016,     // send msg to board when stop simulation
    E_CommandID_STOP_SIMULATION_RES         =	0x0017,
    E_CommandID_SEND_MESSAGE_REQ            =    0x0018,     // Tx Message
    E_CommandID_SEND_MESSAGE_RES            =    0x0019,     // Tx transmitted and response ok
    //    E_CommandID_CLOSE_CONNECTION_REQ        =	0x0022,     // close software
}E_CommandID;

typedef enum{
    E_BoardStatus_Live=0,
    E_BoardStatus_Die =1,
}E_BoardStatus;

typedef enum{
    E_SimulateStatus_Started=0,
    E_SimulateStatus_Stoped=1,
}E_SimulateStatus;

typedef enum E_DeviceID
{
    E_DeviceID_PC            =   0x01,
    E_DeviceID_BOARD         =   0x02,
}E_DeviceID;

typedef enum E_DeviceType
{
    E_DeviceType_PC            =   0x01,
    E_DeviceType_BOARD         =   0x02,
}E_DeviceType;

typedef struct ST_MsgHeader
{
    uint8_t sourceID;
    uint8_t destID;
    uint8_t sourceType;
    uint8_t destType;
    uint16_t commandID; //E_CommandID
    uint8_t length;
} ST_MsgHeader;

//*********************************************************************************
//
// this is CAN_Frame
//
//**********************************************************************************

typedef struct ST_CANFrame
{
    uint32_t ID;
    uint8_t length;
    uint8_t data[8];
} ST_CANFrame;


//*************************************************************************************
//
// this is USB_Frame
//
//*************************************************************************************
typedef struct ST_MsgCANTransceive
{
    ST_MsgHeader header;
    uint8_t CANChannel;//1: CAN1, 2: CAN2
    ST_CANFrame frame;
} ST_MsgCANTransceive;

typedef ST_MsgHeader ST_MsgCheckAliveReq ;
typedef ST_MsgHeader ST_MsgStartSimulateReq ;
typedef ST_MsgHeader ST_MsgStopSimulateReq ;

typedef struct ST_MsgCheckAliveRsp
{
    ST_MsgHeader header;
    uint8_t status; //0: OK, 1: NG
} ST_MsgCheckAliveRsp;

typedef struct ST_MsgGetConfigurationRsp
{
    ST_MsgHeader header;
    uint32_t baudRate;
    uint8_t CANChannel;//1: CAN1, 2: CAN2
} ST_MsgGetConfigurationRsp;

typedef struct ST_MsgSetConfigurationReq
{
    ST_MsgHeader header;
    uint32_t baudRate;
    uint8_t CANChannel;//1: CAN1, 2: CAN2

} ST_MsgSetConfigurationReq;

typedef struct ST_MsgSetConfigurationRsp
{
    ST_MsgHeader header;
    uint8_t status; //0: OK, 1: NG
    uint8_t CANChannel;//1: CAN1, 2: CAN2
} ST_MsgSetConfigurationRsp;

typedef struct ST_MsgStartSimulateRsp
{
    ST_MsgHeader header;
    uint8_t status; //0: OK, 1: NG
} ST_MsgStartSimulateRsp;

typedef struct ST_MsgStopSimulateRsp
{
    ST_MsgHeader header;
    uint8_t status; //0: OK, 1: NG
} ST_MsgStopSimulateRsp;

typedef struct ST_MsgTransceiveRsp
{
    ST_MsgHeader header;
    uint8_t status; //0: OK, 1: NG
    ST_CANFrame frame;
    uint8_t CANChannel;//1: CAN1, 2: CAN2
} ST_MsgTransceiveRsp;


typedef struct CANHardwareConfig{
    QString m_Name;
    bool m_Used;
    unsigned int m_Baud;
}CANHardwareConfig;

class HardwareInterfaceConfigWindow: public QMainWindow,  Ui_hardwareinterface
{
    Q_OBJECT
public:
    HardwareInterfaceConfigWindow(QWidget * parent=0, HardwareInterfaceManager* manager=0);
    void refreshWindow();
signals:
public slots:
    void slotOkButton();
    void slotCancelButton();
private:
    QVector<CANHardwareConfig> m_TmpHardwareCfg;
    HardwareInterfaceManager * m_HardwareManager;
};



class HardwareInterfaceManager:public MeasureSetupManagerCommon{
    Q_OBJECT
public:
    HardwareInterfaceManager(CANSimulatorDatabaseAssosiate * assosiateDb=NULL);
    ~HardwareInterfaceManager();
    void loadConfig(const QJsonValue & config); //load config from Json node
    const QJsonValue saveConfig(); //Save config to an Json node

    void startSimulate();
    void stopSimulate();
    bool process(MeasureSetupMessageCommon *message);
    //Add the protocol APIs here (init, send, recv,...)
public slots:
    void slotHasData();
protected:
    bool hardwareInit();
    bool hardwareDeInit();

private:

    CANSimulatorDatabaseAssosiate *m_AssosiateDb;
    friend class HardwareInterfaceConfigWindow;
    QVector<CANHardwareConfig> m_HardwareCfg; //Two CAN port
    HardwareIO *m_HardwareIO;
    QTimer m_CheckAliveTimer;
    QTimer m_SendCANTimer;
    QVector<MeasureSetupMessageCAN>m_RxMessages;
    QVector<MeasureSetupMessageCAN> m_TxMessages;
private slots:
    void slotCheckAliveTimeout();
    void slotSendCANTimeout();
private:

    uint16_t parsingReceiveMessage(const char * data, int len);

    void processCheckAliveRsp(ST_MsgCheckAliveRsp * msg);
    void processSendCANRsp(ST_MsgTransceiveRsp * msg);
    void processRecvCAN(ST_MsgCANTransceive * msg);
    void processConfigRsp(ST_MsgSetConfigurationRsp * msg);
    void processStartSimulateRsp(ST_MsgStartSimulateRsp * msg);
    void processStopSimulateRsp(ST_MsgStopSimulateRsp * msg);

    bool sendMessageCheckAliveReq();
    bool sendMessageCANFrame(MeasureSetupMessageCAN * message);
    bool sendMessageConfigureCAN();
    bool sendMessageStartSimulate();
    bool sendMessageStopSimulate();
};

class HardwareIO:public QSerialPort
{
    Q_OBJECT
signals:
    void signalDataReady();
private slots:
    void slotDataReady()
    {
        emit signalDataReady();
    }

public:
    HardwareIO(const QString & port=QString(),QObject * parent=0):
        QSerialPort(port,parent)
    {
        connect(this,SIGNAL(readyRead()),this,SLOT(slotDataReady()));
    }

    qint64 readLine(char * data, qint64 len)
    {
        return QSerialPort::readLine(data,len);
    }

    QByteArray readAll()
    {
        return QSerialPort::readAll();
    }

    qint64 write(const char *data, qint64 len){
        return QSerialPort::write(data,len);
    }
    bool open(OpenMode mode){
        return QSerialPort::open(mode);
    }
    void close()
    {
        QSerialPort::close();
    }
};

#endif // HARDWAREINTERFACE_H
