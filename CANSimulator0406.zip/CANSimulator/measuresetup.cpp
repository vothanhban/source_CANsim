#include "measuresetup.h"
#include "ui_measuresetup.h"
#include "tracemanager.h"
#include "filtermanager.h"
#include "interactivemanager.h"
#include "hardwareinterface.h"
#include<QDateTime>

#include <QDebug>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QPainter>
#include <QToolButton>
#include <QPaintEvent>
#include <QJsonDocument>
#include <QTimer>
int ts=400;
//void MeasureSetupWindow::slotTimerTest()
//{
//    static int t = 0;
//    CANMessageSimulate msg;
//    msg.m_Id = 100+ (t/ts)%2 ;
//    msg.m_Name = QString("Msg1");
//    msg.m_Channel = 1+(t/ts)%2;
//    msg.m_Len = 5;
//    msg.m_Data[0]=0xDE;
//    msg.m_Data[1]=0xAD;
//    msg.m_Data[2]=0xBE;
//    msg.m_Data[3]=0xEF;
//    msg.m_Data[4]=0x01 + (t/ts)%3;
//    msg.m_isReqToTx = (t/ts)%2;
//    msg.m_Direction = (t/ts)%2==0?E_Direction_Rx:E_Direction_Tx;

//    CANSignalSimulate signal;
//    signal.m_Value.dValue = 34.6;
//    signal.m_CANSign.m_Name = QString("Signal 1");
//    msg.m_CANSignals.append(signal);

//    signal.m_Value.dValue = 12.3;
//    signal.m_CANSign.m_Name = QString("Signal 2");
//    msg.m_CANSignals.append(signal);

//    MeasureSetupMessageCAN CANMsg(t,msg);
//    t+=ts;
//    //    emit m_Model->m_IGTable->item(0,0)->sendData(CANMsg);

//}

MeasureSetupWindow::MeasureSetupWindow(QWidget *parent,  MeasureSetupModel * model) :
    QMainWindow(parent),
    m_Model (model)
{
    setupUi(this);
    qDebug()<<__FUNCTION__<<__LINE__;
    if(m_Model){
        m_Model->refreshConnection();
        qDebug()<<__FUNCTION__<<__LINE__;
        drawModel();
        qDebug()<<__FUNCTION__<<__LINE__;
    }
}

MeasureSetupWindow::~MeasureSetupWindow()
{
}

void MeasureSetupWindow::drawModel()
{
//    qDebug()<<__FUNCTION__<<__LINE__<<endl;
    MeasureSetupItemCommon * item;
    //    static QWidget * tmpWidget = new QWidget();

    //    tmpWidget->setMinimumWidth(100);
    //    tmpWidget->setMinimumHeight(100);

    //    tmpWidget->setMaximumWidth(200);
    //    tmpWidget->setMaximumHeight(200);

    QString buttonNodeStyle =
            "QToolButton:pressed {background-color: rgb(200, 200, 200); }"
            " QToolButton{border:none;border-image:url(:/icons/node.png);background-color:none;}";
    QString buttonCANStyle =
            "QToolButton:pressed {background-color: rgb(200, 200, 200); }"
            " QToolButton{border:none;border-image:url(:/icons/canhw.png);background-color:none;}";

    QString buttonJoinStyle =
            "QToolButton:checked{border:none;border-image:url(:/icons/pause.png);background-color:none;}"
            "QToolButton{border:none;border-image:url(:/icons/play.png);background-color:none;}";
//    qDebug()<<__FUNCTION__<<__LINE__<<endl;
    gridLayout->setHorizontalSpacing(15);
    gridLayout->setVerticalSpacing(10);
    int maxRow=0, maxColumn=0;
    int startRow=1,startColumn=1;
    int inc=1, columnCompare=0, startIndex=0;
    int drawColumn;
//    qDebug()<<__FUNCTION__<<__LINE__;
    if(m_Model)
    {
//        qDebug()<<__FUNCTION__<<__LINE__;
        if(m_Model->m_IGTable){
            maxRow=std::max(maxRow,m_Model->m_IGTable->rowCount());
            maxColumn = maxColumn+m_Model->m_IGTable->columnCount();
        }
//        qDebug()<<__FUNCTION__<<__LINE__;
        if(m_Model->m_MainTable){
            maxRow=std::max(maxRow,m_Model->m_MainTable->rowCount());
            maxColumn = maxColumn+m_Model->m_MainTable->columnCount();
        }
//        qDebug()<<__FUNCTION__<<__LINE__;
        if(m_Model->m_ViewTable){
            maxRow=std::max(maxRow,m_Model->m_ViewTable->rowCount());
            maxColumn = maxColumn+m_Model->m_ViewTable->columnCount();
        }

        //        qDebug()<<maxRow<<maxColumn ;
//        qDebug()<<__FUNCTION__<<__LINE__;
        for (int row=0;row<maxRow + 10;row++)
        {
            gridLayout->setRowStretch(row,10);
            for (int column=0;column<maxColumn + 10;column++){
                //                gridLayout->addWidget(tmpWidget,row,column);
                gridLayout->setColumnStretch(column,10);
            }
        }
//        qDebug()<<__FUNCTION__<<__LINE__;
        QMap<E_MeasureSetupBranch, MeasureSetupAbstractTable *> maps;

        maps.insert(E_MeasureSetupBranch_IG,m_Model->m_IGTable);
        maps.insert(E_MeasureSetupBranch_Main,m_Model->m_MainTable);
        maps.insert(E_MeasureSetupBranch_View,m_Model->m_ViewTable);
//        qDebug()<<__FUNCTION__<<__LINE__;
        for (QMap<E_MeasureSetupBranch, MeasureSetupAbstractTable *>::iterator it = maps.begin(); it!=maps.end();it++) {
            E_MeasureSetupBranch branch = it.key();
            MeasureSetupAbstractTable * table = it.value();
            if(table){
                startRow = (maxRow - table->rowCount())/2 + 1;
                for(int row=0;row< table->rowCount();row++ ){
                    if(branch==E_MeasureSetupBranch_View){
                        columnCompare = -1;
                        inc = -1;
                        startIndex = table->m_TableItems[row].size()-1;
                        drawColumn = startColumn + table->columnCount() *2;
                    }else{
                        columnCompare = table->m_TableItems[row].size();
                        inc=1;
                        startIndex = 0;
                        drawColumn = startColumn ;
                    }

                    for(int column=startIndex;column != columnCompare;column+=inc ){
                        item = table->item(row,column);
                        if(branch==E_MeasureSetupBranch_View){
                            //                            qDebug()<< drawColumn<< startColumn << startIndex << columnCompare;
                        }
                        if(item){
                            if(item->m_widget.size()<=0){
                                MeasureSetupWidget * newWidget ;
                                switch (item->getType()) {
                                case E_MeasureSetupItemType_IG:
                                    newWidget=new MeasureSetupWidget(QIcon(""),"IG",this);
                                    newWidget->setProperty("type",(int)item->getType());
                                    newWidget->setStyleSheet(buttonNodeStyle);
                                    newWidget->setMinimumSize(50,50);
                                    newWidget->setMaximumSize(100,100);

                                    item->m_widget.append(newWidget);
                                    connect(newWidget,SIGNAL(signalContextMenu(const QPoint & )),item,SLOT(slotDrawContextMenu(const QPoint &)));
                                    connect(newWidget,SIGNAL(signalDoubleClick()),item,SLOT(slotOpenOpeWindow()));
                                    connect(item,SIGNAL(signalOpenOpeWindow()),this,SLOT(slotOpenOpeWindow()));
                                    connect(item,SIGNAL(signalDrawContextMenu(const QPoint&)),this,SLOT(slotDrawContextMenu(const QPoint&)));

                                    break;
                                case E_MeasureSetupItemType_Filter:
                                    newWidget=new MeasureSetupWidget(QIcon(""),"PF",this);
                                    newWidget->setProperty("type",(int)item->getType());
                                    newWidget->setStyleSheet(buttonNodeStyle);
                                    newWidget->setMinimumSize(30,30);
                                    newWidget->setMaximumSize(40,40);

                                    item->m_widget.append(newWidget);
                                    connect(newWidget,SIGNAL(signalContextMenu(const QPoint & )),item,SLOT(slotDrawContextMenu(const QPoint &)));
                                    connect(newWidget,SIGNAL(signalDoubleClick()),item,SLOT(slotOpenOpeWindow()));
                                    connect(item,SIGNAL(signalOpenOpeWindow()),this,SLOT(slotOpenOpeWindow()));
                                    connect(item,SIGNAL(signalDrawContextMenu(const QPoint&)),this,SLOT(slotDrawContextMenu(const QPoint&)));

                                    break;
                                case E_MeasureSetupItemType_Interface:
                                    newWidget=new MeasureSetupWidget(QIcon(""),"",this);
                                    newWidget->setProperty("type",(int)item->getType());
                                    newWidget->setStyleSheet(buttonCANStyle);
                                    newWidget->setMinimumSize(50,50);
                                    newWidget->setMaximumSize(200,200);

                                    item->m_widget.append(newWidget);
                                    connect(newWidget,SIGNAL(signalContextMenu(const QPoint & )),item,SLOT(slotDrawContextMenu(const QPoint &)));
                                    connect(newWidget,SIGNAL(signalDoubleClick()),item,SLOT(slotOpenOpeWindow()));
                                    connect(item,SIGNAL(signalOpenOpeWindow()),this,SLOT(slotOpenOpeWindow()));
                                    connect(item,SIGNAL(signalDrawContextMenu(const QPoint&)),this,SLOT(slotDrawContextMenu(const QPoint&)));
                                    break;

                                case E_MeasureSetupItemType_Trace:
                                    newWidget=new MeasureSetupWidget(QIcon(""),"Trace",this);
                                    newWidget->setProperty("type",(int)item->getType());
                                    newWidget->setStyleSheet(buttonNodeStyle);
                                    newWidget->setMinimumSize(50,50);
                                    newWidget->setMaximumSize(100,100);

                                    item->m_widget.append(newWidget);
                                    connect(newWidget,SIGNAL(signalContextMenu(const QPoint & )),item,SLOT(slotDrawContextMenu(const QPoint &)));
                                    connect(newWidget,SIGNAL(signalDoubleClick()),item,SLOT(slotOpenOpeWindow()));
                                    connect(item,SIGNAL(signalOpenOpeWindow()),this,SLOT(slotOpenOpeWindow()));
                                    connect(item,SIGNAL(signalDrawContextMenu(const QPoint&)),this,SLOT(slotDrawContextMenu(const QPoint&)));

                                    break;
                                case E_MeasureSetupItemType_Join:
                                    connect(item,SIGNAL(signalDrawContextMenu(const QPoint&)),this,SLOT(slotDrawContextMenu(const QPoint&)));
                                    break;
                                default:
                                    break;
                                }
                                if(item->getType()!= E_MeasureSetupItemType_None){
                                    newWidget=new MeasureSetupWidget(QIcon(""),"",this);
                                    newWidget->setStyleSheet(buttonJoinStyle);
                                    newWidget->setCheckable(true);
                                    newWidget->setChecked(!item->m_IsJoin);
                                    newWidget->setMinimumSize(15,10);
                                    newWidget->setMaximumSize(20,15);

                                    connect(newWidget,SIGNAL(signalContextMenu(const QPoint & )),item,SLOT(slotDrawContextMenu(const QPoint &)));
                                    connect(newWidget,SIGNAL(clicked(bool)),item,SLOT(slotJoinToggle(bool)));
                                    newWidget->setProperty("type",(int)E_MeasureSetupItemType_Join);
                                    item->m_widget.append(newWidget);
                                }
                            }
                            foreach (MeasureSetupWidget *  widget, item->m_widget) {
                                if(widget){
                                    gridLayout->addWidget(widget,startRow,drawColumn);
                                    drawColumn+=inc;
                                    //                                    i++;
                                }
                            }

                        }/*else{
                            i++;
                        }*/
                    }
                    startRow++;
                }
                startColumn += table->columnCount()*2+1;
            }
        }
    }
//    qDebug()<<__FUNCTION__<<__LINE__;
    update();
}

void MeasureSetupWindow::slotOpenOpeWindow()
{
    QMenu menu;
    int row, column;
    MeasureSetupItemCommon * item = qobject_cast<MeasureSetupItemCommon*> (sender());
    MeasureSetupAbstractTable * table =    findItems(item,row, column);
    if(!table || !item){
        qDebug()<< "not found";
        return;
    }

    if(item->m_OperateWindow){
        qobject_cast<QMainWindow*>(item->m_OperateWindow)->show();
        qobject_cast<QMainWindow*>(item->m_OperateWindow)->activateWindow();
        return;
    }
    switch (qobject_cast<MeasureSetupItemCommon*> (sender())->getType()) {
    case E_MeasureSetupItemType_IG:
    {
//        qDebug()<< "open IG window";
        InteractiveManagerWindow * igWindow = new InteractiveManagerWindow(NULL,
                                                                           &(qobject_cast<InteractiveManager*>(item->m_Manager)->getMessageInfo()),m_Model->m_AssosiateDb);
        igWindow->show();
        connect(igWindow,SIGNAL(destroyed()),item,SLOT(slotCloseOpeWindow()));
        item->m_OperateWindow = qobject_cast<QWidget*>(igWindow);
    }
        break;
    case E_MeasureSetupItemType_Filter:
    {
        FilterManagerWindow * filterWindow = new FilterManagerWindow(NULL,qobject_cast<FilterNodeManager*>(item->m_Manager)->getFilterStop(),qobject_cast<FilterNodeManager*>(item->m_Manager)->getFilters(),m_Model->m_AssosiateDb);
        connect(filterWindow,SIGNAL(signalSaveFilter(bool,QVector<FilterData>&)),qobject_cast<FilterNodeManager*>(item->m_Manager),SLOT(slotSaveFilterData(bool,QVector<FilterData>&)));
        item->m_OperateWindow = qobject_cast<QWidget*>(filterWindow);
        filterWindow->show();
    }
        break;

    case E_MeasureSetupItemType_Trace:
    {
        TraceWindow * traceWindow = new TraceWindow(NULL,qobject_cast<TraceManager*>(item->m_Manager));
        item->m_OperateWindow = qobject_cast<QWidget*>(traceWindow);
        traceWindow->show();
    }
        break;
    case E_MeasureSetupItemType_Interface:
    {
        HardwareInterfaceConfigWindow * hwCfgWindow = new HardwareInterfaceConfigWindow(this,qobject_cast<HardwareInterfaceManager*>(item->m_Manager));
        item->m_OperateWindow = qobject_cast<QWidget*>(hwCfgWindow);
        hwCfgWindow->show();
    }
        break;
    default:
        break;
    }
}
void MeasureSetupWindow::slotDrawContextMenu(const QPoint& pos)
{
    QMenu menu;
    int row, column;
    MeasureSetupItemCommon * item = qobject_cast<MeasureSetupItemCommon*> (sender());
    MeasureSetupAbstractTable * table =    findItems(item,row, column);
    if(!table || !item){
        qDebug()<< "not found";
        return;
    }

    switch (qobject_cast<MeasureSetupItemCommon*> (sender())->property("menutype").toInt()) {
    case E_MeasureSetupItemType_Join:
    {
        QAction breakAction("",sender());
        if(item->m_IsJoin){
            breakAction.setText("Break");
        }else{
            breakAction.setText("Remove break");
        }
        QAction inserFilterAction("Insert Filter",sender());
        menu.addAction(&breakAction);
        menu.addAction(&inserFilterAction);
        QAction * retAction = menu.exec(pos);
        if(retAction== &breakAction){
            item->slotJoinToggle(item->m_IsJoin);
        }else if(retAction== &inserFilterAction){
            int inc = 1;
            if(item->getBranch()==E_MeasureSetupBranch_View){
                inc=0;
            }
            table->insertColumns(row,column+inc,1);
            MeasureSetupItemCommon * newItem = new MeasureSetupItemCommon(E_MeasureSetupItemType_Filter,item->getBranch());
            FilterNodeManager *filterManager = new FilterNodeManager();
            newItem->m_Manager = qobject_cast<FilterNodeManager*>(filterManager);
            table->setItem(row,column+inc,newItem);
            if(m_Model){
                m_Model->refreshConnection();
            }
            drawModel();
        }
    }
        break;

    case E_MeasureSetupItemType_IG:
    {
        qDebug()<<"show IG menu";
        QAction viewAction(QString("View Interactive Generator"),sender());
        QAction deleteAction(QString("Remove Interactive Generator"),sender());
        QAction insertAction(QString("Insert Interactive Generator"),sender());
        menu.addAction(&viewAction);
        menu.addAction(&deleteAction);
        menu.addAction(&insertAction);
        QAction * retAction =    menu.exec(pos);
        if(retAction == &viewAction){
            slotOpenOpeWindow();
        }else if(retAction == &deleteAction){
            table->removeRows(row,1);
            if(m_Model){
                m_Model->refreshConnection();
            }
            drawModel();
        }else if(retAction == &insertAction){
            table->insertRows(row+1,1);
            table->insertColumns(row+1,0,1);
            MeasureSetupItemCommon * newItem = new MeasureSetupItemCommon(E_MeasureSetupItemType_IG,item->getBranch());
            InteractiveManager *interactiveManager = new InteractiveManager(m_Model->m_AssosiateDb);
            newItem->m_Manager = qobject_cast<MeasureSetupManagerCommon*>(interactiveManager);
            table->setItem(row+1,0,newItem);
            if(m_Model){
                m_Model->refreshConnection();
            }
            drawModel();
        }
    }
        break;

    case E_MeasureSetupItemType_Filter:
    {
        qDebug()<<"show Filter menu";
        QAction viewAction(QString("Edit Filter"),sender());
        QAction deleteAction(QString("Remove Filter"),sender());
        menu.addAction(&viewAction);
        menu.addAction(&deleteAction);
        QAction * retAction =   menu.exec(pos);
        if(retAction == &viewAction){
            slotOpenOpeWindow();
        }else if(retAction == &deleteAction){
            table->removeColumns(row,column,1);
            if(m_Model){
                m_Model->refreshConnection();
            }
            drawModel();
        }
    }
        break;
    case E_MeasureSetupItemType_Trace:
    {
        qDebug()<<"show Trace menu";
        QAction viewAction(QString("View Trace window"),sender());
        QAction deleteAction(QString("Remove Trace"),sender());
        QAction insertTraceAction(QString("Insert Trace window"),sender());
        QAction inserGraphicAction(QString("Insert Graphical view"),sender());
        menu.addAction(&viewAction);
        menu.addAction(&deleteAction);
        menu.addAction(&insertTraceAction);
        menu.addAction(&inserGraphicAction);

        QAction * retAction =  menu.exec(pos);
        if(retAction == &viewAction){
            slotOpenOpeWindow();
        }else if(retAction == &deleteAction){
            table->removeRows(row,1);
            if(m_Model){
                m_Model->refreshConnection();
            }
            drawModel();
        }else if(retAction == &insertTraceAction){
            table->insertRows(row+1,1);
            table->insertColumns(row+1,0,1);
            MeasureSetupItemCommon * newItem = new MeasureSetupItemCommon(E_MeasureSetupItemType_Trace,item->getBranch());
            TraceManager *traceManager = new TraceManager(NULL,m_Model->m_AssosiateDb);
            newItem->m_Manager = qobject_cast<TraceManager*>(traceManager);
            table->setItem(row+1,0,newItem);
            if(m_Model){
                m_Model->refreshConnection();
            }
            drawModel();
        }
    }
        break;
    case E_MeasureSetupItemType_Interface:
    {
        qDebug()<<"show Hardware interface menu";
        QAction viewAction(QString("View Hardware config"),sender());
        menu.addAction(&viewAction);
        QAction * retAction =  menu.exec(pos);
        if(retAction==&viewAction){
            slotOpenOpeWindow();
        }
    }
        break;

    default:
        break;
    }

}

MeasureSetupAbstractTable * MeasureSetupWindow::findItems(MeasureSetupItemCommon * item, int &row, int & column)
{
    QVector<MeasureSetupAbstractTable *> tables;
    if(!m_Model){
        return NULL;
    }
    tables.append(m_Model->m_IGTable);
    tables.append(m_Model->m_MainTable);
    tables.append(m_Model->m_ViewTable);
    foreach (MeasureSetupAbstractTable * table, tables) {
        for(row=0;row<table->rowCount();row++){
            for(column=0;column<table->columnCount();column++){
                if(table->item(row,column)==item){
                    return table;
                }
            }
        }
    }
    return NULL;
}

void MeasureSetupModel::loadConfig(const QString &configPath)
{
    if(m_AssosiateDb){
        delete m_AssosiateDb;
    }
    m_AssosiateDb = new CANSimulatorDatabaseAssosiate ();
    if(!m_IGTable)
    {
        m_IGTable=new MeasureSetupAbstractTable();
    }
    if(!m_MainTable)
    {
        m_MainTable=new MeasureSetupAbstractTable();
    }
    if(!m_ViewTable)
    {
        m_ViewTable=new MeasureSetupAbstractTable();
    }
    qDebug()<<__FUNCTION__<<__LINE__;
    m_IGTable->removeAll();
    m_MainTable->removeAll();
    m_ViewTable->removeAll();

    /*
{
    "VERSION":{"ver":1,"major":0,"minor":0},
    "MEASURESETUP":{
        "GENERATOR":[
            {
                "CONTENT"  :[
                    {
                        "type": "IG",
                        "connect":true,
                        "name":"IG1",
                        "MSGS":[
                        ]
                    },
                    {
                        "type":"FILTER",
                        "connect":true,
                        "name": "PF",
                        "data":[
                            {"startId":111,"endId":222, "Tx":true, "Rx":true , "channels":"0"}
                        ]
                    }
                ]
            }
        ],
        "MAIN":[
            {
                "CONTENT":[
                    {
                        "type": "CAN",
                        "connect":true,
                        "CAN":[
                        ]
                    },
                    {
                        "type":"FILTER",
                        "connect":true,
                        "name": "PF",
                        "data":[
                        ]
                    }
                ]
            }
        ],
        "VIEW":[
            {
                "CONTENT":[
                    {
                        "connect":true,
                        "type":"TRACE",
                        "name":"trace"
                    }
                ]
            }
        ]
    },
    "DATABASE":[
    ]
}
*/
    qDebug()<<__FUNCTION__<<__LINE__;
    MeasureSetupItemCommon * newItem;
    InteractiveManager * igManager;
    FilterNodeManager *filterManager;
    TraceManager *traceManager;

    QMap<E_MeasureSetupBranch, MeasureSetupAbstractTable *> maps;

    maps.insert(E_MeasureSetupBranch_IG,m_IGTable);
    maps.insert(E_MeasureSetupBranch_Main,m_MainTable);
    maps.insert(E_MeasureSetupBranch_View,m_ViewTable);

    QFile file(configPath);
    if(file.open(QIODevice::ReadOnly)){
        QByteArray fileContent=file.readAll();
        QJsonDocument doc = QJsonDocument::fromJson(fileContent);
        //        qDebug()<< doc.toJson(QJsonDocument::Indented);

        if(!doc.isObject()){
            return;
        }

        QJsonArray rowArray, contentArray, databaseArray;
        QJsonObject rootObj,measureSetupObj,rowObject,contentObject,databaseObj;

        rootObj = doc.object();
        databaseArray = rootObj["DATABASE"].toArray();
        QVector<CANAssosiateDbInfo> DatabaseInfo;
        foreach (const QJsonValue & databaseValue, databaseArray) {
            if(databaseValue.isObject()){
                databaseObj= databaseValue.toObject();
                if(databaseObj["name"].isString() && databaseObj["path"].isString()){
                    CANAssosiateDbInfo newInfo;
                    newInfo.m_Name = databaseObj["name"].toString();
                    newInfo.m_Path = databaseObj["path"].toString();
                    DatabaseInfo.append(newInfo);
                }
            }
        }
        slotUpdateAssosiateDbInfo(DatabaseInfo);
        measureSetupObj = rootObj["MEASURESETUP"].toObject();
        //        qDebug()<<measureSetupObj;
        for (QMap<E_MeasureSetupBranch, MeasureSetupAbstractTable *>::iterator it = maps.begin(); it!=maps.end();it++) {
            E_MeasureSetupBranch branch = it.key();
            MeasureSetupAbstractTable * table = it.value();
            if(branch == E_MeasureSetupBranch_IG){
                rowArray = measureSetupObj["GENERATOR"].toArray();
            }if(branch == E_MeasureSetupBranch_Main){
                rowArray = measureSetupObj["MAIN"].toArray();
            }if(branch == E_MeasureSetupBranch_View){
                rowArray = measureSetupObj["VIEW"].toArray();
            }
            qDebug()<<rowArray;
            //            table->insertRows(0,rowArray.size());
            int row=0,column=0;
            foreach (const QJsonValue & rowValue, rowArray) {
                column=0;
                if(!rowValue.isObject()) continue;
                table->insertRows(row,1);
                rowObject = rowValue.toObject();
                contentArray = rowObject["CONTENT"].toArray();
                if(contentArray.isEmpty()) continue;

                foreach (const QJsonValue & contentValue, contentArray) {
                    if(!contentValue.isObject()) continue;
                    contentObject = contentValue.toObject();
                    if(contentObject["type"]==QString("IG")){
                        table->insertColumns(row,column,1);
                        newItem= new MeasureSetupItemCommon(E_MeasureSetupItemType_IG,branch);
                        igManager = new InteractiveManager(m_AssosiateDb);
                        igManager->loadConfig(contentObject);
                        newItem->m_Manager = qobject_cast<InteractiveManager *>(igManager);
                        table->setItem(row,column,newItem);
                    }else if(contentObject["type"]==QString("CAN")){
                        table->insertColumns(row,column,1);
                        newItem= new MeasureSetupItemCommon(E_MeasureSetupItemType_Interface,branch);
                        HardwareInterfaceManager * hwManager = new HardwareInterfaceManager(m_AssosiateDb);
                        hwManager->loadConfig(contentObject);
                        newItem->m_Manager = qobject_cast<HardwareInterfaceManager *>(hwManager);
                        m_MainTable->setItem(row,column,newItem);
                    }else if(contentObject["type"]==QString("FILTER")){
                        table->insertColumns(row,column,1);
                        newItem= new MeasureSetupItemCommon(E_MeasureSetupItemType_Filter,branch);
                        filterManager = new FilterNodeManager();
                        filterManager->loadConfig(contentObject);
                        newItem->m_Manager = qobject_cast<FilterNodeManager *>(filterManager);
                        m_IGTable->setItem(row,column,newItem);
                    }else if(contentObject["type"]==QString("TRACE")){
                        table->insertColumns(row,column,1);
                        newItem= new MeasureSetupItemCommon(E_MeasureSetupItemType_Trace,branch);
                        traceManager = new TraceManager(NULL,m_AssosiateDb);
                        traceManager->loadConfig(contentObject);
                        newItem->m_Manager = qobject_cast<TraceManager *>(traceManager);
                        table->setItem(row,column,newItem);
                    }else if(contentObject["type"]==QString("JOIN")){
                        table->insertColumns(row,column,1);
                        newItem= new MeasureSetupItemCommon(E_MeasureSetupItemType_Join,branch);
                        m_MainTable->setItem(row,column,newItem);
                    }else{
                        continue;
                    }
                    column++;
                }
                row++;
            }
        }
        file.close();
    }
    qDebug()<<__FUNCTION__<<__LINE__;
}
void MeasureSetupModel::saveConfig(const QString & path)
{
    QMap<E_MeasureSetupBranch, MeasureSetupAbstractTable *> maps;

    maps.insert(E_MeasureSetupBranch_IG,m_IGTable);
    maps.insert(E_MeasureSetupBranch_Main,m_MainTable);
    maps.insert(E_MeasureSetupBranch_View,m_ViewTable);

    QJsonArray rowArray, contentArray,databaseArray;
    QJsonObject rootObj,measureSetupObj,rowObject,contentObject,databaseObj;

    QJsonValue tmpValue;
    MeasureSetupItemCommon * item;
    for (QMap<E_MeasureSetupBranch, MeasureSetupAbstractTable *>::iterator it = maps.begin(); it!=maps.end();it++) {
        E_MeasureSetupBranch branch = it.key();
        MeasureSetupAbstractTable * table = it.value();


        while(rowArray.size()>0)rowArray.removeFirst(); //Remove all item for next row

        for(int row=0;row<table->rowCount();row++){
            while(contentArray.size()>0)contentArray.removeFirst(); //Remove all item for next row
            for(int column=0;column < table->m_TableItems[row].size();column++){
                item = table->item(row,column);
                if(item){
                    tmpValue = item->saveConfig();
                    contentObject = tmpValue.toObject();
                    contentArray.append(contentObject);
                }
            }
            rowObject["CONTENT"]=contentArray;
            rowArray.append(rowObject);
        }

        if(branch == E_MeasureSetupBranch_IG){
            measureSetupObj["GENERATOR"] = rowArray;
        }if(branch == E_MeasureSetupBranch_Main){
            measureSetupObj["MAIN"] = rowArray;
        }if(branch == E_MeasureSetupBranch_View){
            measureSetupObj["VIEW"] = rowArray;
        }
    }
    rootObj["MEASURESETUP"] = measureSetupObj;

    foreach (const CANAssosiateDbInfo & info, m_AssosiateDb->getAssosiateDbInfo()) {
        databaseObj = QJsonObject();
        databaseObj["name"] = info.m_Name ;
        databaseObj["path"] = info.m_Path;
        databaseArray.append(databaseObj);
    }
    rootObj["DATABASE"] = databaseArray ;
    QByteArray rawData =  QJsonDocument(rootObj).toJson(QJsonDocument::Indented);
    qDebug()<< rawData;
    if(path.isEmpty()){
        return;
    }
    QFile file(path);
    if(file.open(QIODevice::ReadWrite)){
        file.write(rawData);
        file.close();
    }else{
        qDebug()<< "Can not write to file: " << path;
    }
}

void MeasureSetupWindow::resizeEvent(QResizeEvent * evt)
{
}

void MeasureSetupWindow::paintEvent(QPaintEvent *evt)
{

    QPoint IGLeftTop(0,0),IGRightBottom(0,0);
    QPoint MainLeftTop(0,0),MainRightBottom(0,0);
    QPoint ViewLeftTop(0,0),ViewRightBottom(0,0);
    MeasureSetupItemCommon * item;
    QWidget * tmpWidget=NULL;
    QPainter  line (this);

    QPen pen(QColor(Qt::blue),2,Qt::SolidLine, Qt::FlatCap, Qt::RoundJoin);
    line.setPen(pen);
    //  qDebug()<<__FUNCTION__<<__LINE__;
    if(m_Model)
    {
        for (int row=0;m_Model->m_IGTable && row<m_Model->m_IGTable->rowCount();row++){
            for (int column=0;column<m_Model->m_IGTable->columnCount();column++){
                item = m_Model->m_IGTable->item(row,column);
                if(item ){
                    foreach (QWidget * widget, item->m_widget) {
                        if(widget){
                            if(widget->pos().rx() < IGLeftTop.rx() || IGLeftTop.rx() == 0){
                                IGLeftTop.setX(widget->pos().rx() - 7);
                            }
                            if(widget->pos().ry()+widget->size().rheight()/2 < IGLeftTop.ry() || IGLeftTop.ry() == 0){
                                IGLeftTop.setY(widget->pos().ry()+widget->size().rheight()/2 );
                            }

                            if(widget->pos().rx()+widget->size().rwidth() > IGRightBottom.rx() || IGRightBottom.rx() == 0){
                                IGRightBottom.setX(widget->pos().rx()+widget->size().rwidth() + 7);
                            }

                            if(widget->pos().ry()+widget->size().rheight()/2 > IGRightBottom.ry() || IGRightBottom.ry() == 0){
                                IGRightBottom.setY(widget->pos().ry()+widget->size().rheight()/2 );
                            }

                        }
                    }
                }
            }
        }
        line.drawLine(IGRightBottom.rx(),IGLeftTop.ry(), IGRightBottom.rx(),IGRightBottom.ry());
        for (int row=0;m_Model->m_IGTable && row<m_Model->m_IGTable->rowCount();row++){
            tmpWidget=NULL;
            for (int column=0;column<m_Model->m_IGTable->columnCount();column++){
                item = m_Model->m_IGTable->item(row,column);
                if(item ){
                    for(int i=0;i<item->m_widget.size();i++){
                        if(tmpWidget!=NULL){
                            line.drawLine(tmpWidget->pos().x()+tmpWidget->size().width(),
                                          tmpWidget->pos().y()+tmpWidget->size().height()/2,
                                          item->m_widget[i]->pos().x(),
                                          tmpWidget->pos().y()+tmpWidget->size().height()/2
                                          );
                        }
                        tmpWidget=item->m_widget[i];
                    }
                }
            }
            if(tmpWidget){
                line.drawLine(tmpWidget->pos().x()+tmpWidget->size().width(),
                              tmpWidget->pos().y()+tmpWidget->size().height()/2,
                              IGRightBottom.rx(),
                              tmpWidget->pos().y()+tmpWidget->size().height()/2
                              );
            }
        }

        //Draw main branch
        pen.setColor(QColor(Qt::red));
        line.setPen(pen);

        for (int row=0;m_Model->m_MainTable && row<m_Model->m_MainTable->rowCount();row++){
            for (int column=0;column<m_Model->m_MainTable->columnCount();column++){
                item = m_Model->m_MainTable->item(row,column);
                if(item ){
                    foreach (QWidget * widget, item->m_widget) {
                        if(widget){
                            if(widget->pos().rx() < MainLeftTop.rx() || MainLeftTop.rx() == 0){
                                MainLeftTop.setX(widget->pos().rx() - 7);
                            }
                            if(widget->pos().ry()+widget->size().rheight()/2 < MainLeftTop.ry() || MainLeftTop.ry() == 0){
                                MainLeftTop.setY(widget->pos().ry()+widget->size().rheight()/2 );
                            }

                            if(widget->pos().rx()+widget->size().rwidth() > MainRightBottom.rx() || MainRightBottom.rx() == 0){
                                MainRightBottom.setX(widget->pos().rx()+widget->size().rwidth() + 7);
                            }

                            if(widget->pos().ry()+widget->size().rheight()/2 > MainRightBottom.ry() || MainRightBottom.ry() == 0){
                                MainRightBottom.setY(widget->pos().ry()+widget->size().rheight()/2 );
                            }

                        }
                    }
                }
            }
        }

        line.drawLine(MainLeftTop.rx(),MainLeftTop.ry(), MainLeftTop.rx(),MainRightBottom.ry());
        line.drawLine(MainRightBottom.rx(),MainLeftTop.ry(), MainRightBottom.rx(),MainRightBottom.ry());

        for (int row=0;m_Model->m_MainTable && row<m_Model->m_MainTable->rowCount();row++){
            tmpWidget=NULL;
            for (int column=0;column<m_Model->m_MainTable->columnCount();column++){
                item = m_Model->m_MainTable->item(row,column);
                if(item ){
                    for(int i=0;i<item->m_widget.size();i++){
                        if(tmpWidget!=NULL){
                            line.drawLine(tmpWidget->pos().x()+tmpWidget->size().width(),
                                          tmpWidget->pos().y()+tmpWidget->size().height()/2,
                                          item->m_widget[i]->pos().x(),
                                          tmpWidget->pos().y()+tmpWidget->size().height()/2
                                          );
                        }else{
                            line.drawLine(MainLeftTop.rx(),
                                          item->m_widget[i]->pos().y()+item->m_widget[i]->size().height()/2,
                                          item->m_widget[i]->pos().x(),
                                          item->m_widget[i]->pos().y()+item->m_widget[i]->size().height()/2
                                          );
                        }
                        tmpWidget=item->m_widget[i];
                    }
                }
            }
            if(tmpWidget){
                line.drawLine(tmpWidget->pos().x()+tmpWidget->size().width(),
                              tmpWidget->pos().y()+tmpWidget->size().height()/2,
                              MainRightBottom.rx(),
                              tmpWidget->pos().y()+tmpWidget->size().height()/2
                              );
            }
        }

        //Draw View branch
        pen.setColor(QColor(Qt::blue));
        line.setPen(pen);

        for (int row=0;m_Model->m_ViewTable && row<m_Model->m_ViewTable->rowCount();row++){
            for (int column=0;column<m_Model->m_ViewTable->columnCount();column++){
                item = m_Model->m_ViewTable->item(row,column);
                if(item ){
                    foreach (QWidget * widget, item->m_widget) {
                        if(widget){
                            if(widget->pos().rx() < ViewLeftTop.rx() || ViewLeftTop.rx() == 0){
                                ViewLeftTop.setX(widget->pos().rx() - 7);
                            }
                            if(widget->pos().ry()+widget->size().rheight()/2 < ViewLeftTop.ry() || ViewLeftTop.ry() == 0){
                                ViewLeftTop.setY(widget->pos().ry()+widget->size().rheight()/2 );
                            }

                            if(widget->pos().rx()+widget->size().rwidth() > ViewRightBottom.rx() || ViewRightBottom.rx() == 0){
                                ViewRightBottom.setX(widget->pos().rx()+widget->size().rwidth() + 7);
                            }

                            if(widget->pos().ry()+widget->size().rheight()/2 > ViewRightBottom.ry() || ViewRightBottom.ry() == 0){
                                ViewRightBottom.setY(widget->pos().ry()+widget->size().rheight()/2 );
                            }

                        }
                    }
                }
            }
        }
        line.drawLine(ViewLeftTop.rx(),ViewLeftTop.ry(), ViewLeftTop.rx(),ViewRightBottom.ry());
        for (int row=0;m_Model->m_ViewTable && row<m_Model->m_ViewTable->rowCount();row++){
            tmpWidget=NULL;
            for (int column=m_Model->m_ViewTable->columnCount()-1;column>=0;column--){
                item = m_Model->m_ViewTable->item(row,column);
                if(item ){
                    for(int i=0;i< item->m_widget.size();i++){
                        if(tmpWidget!=NULL){
                            line.drawLine(item->m_widget[i]->pos().x() +item->m_widget[i]->size().width(),
                                          tmpWidget->pos().y()+tmpWidget->size().height()/2,
                                          tmpWidget->pos().x(),
                                          tmpWidget->pos().y()+tmpWidget->size().height()/2
                                          );
                        }
                        tmpWidget=item->m_widget[i];
                    }
                }
            }
            if(tmpWidget){
                line.drawLine(tmpWidget->pos().x(),
                              tmpWidget->pos().y()+tmpWidget->size().height()/2,
                              ViewLeftTop.rx(),
                              tmpWidget->pos().y()+tmpWidget->size().height()/2
                              );
            }
        }

        //Connect together
        if(!MainLeftTop.isNull() && !MainRightBottom.isNull()){
            if(!IGLeftTop.isNull()&& !IGRightBottom.isNull()){
                line.drawLine( MainLeftTop.rx(),(MainLeftTop.ry()+MainRightBottom.ry())/2,
                               IGRightBottom.rx(),(MainLeftTop.ry()+MainRightBottom.ry())/2);

            }

            if(!ViewLeftTop.isNull()&& !ViewRightBottom.isNull()){
                line.drawLine( MainRightBottom.rx(),(MainLeftTop.ry()+MainRightBottom.ry())/2,
                               ViewLeftTop.rx(),(MainLeftTop.ry()+MainRightBottom.ry())/2);

            }
        }
    }
    //  qDebug()<<__FUNCTION__<<__LINE__;
}
bool MeasureSetupWidget::event(QEvent *e)
{
    if(e &&e->type()==QEvent::MouseButtonDblClick)
    {
        //        qDebug()<<"evt dblclick";
        emit signalDoubleClick();
    }
    return QToolButton::event(e);
}

void MeasureSetupWidget::mouseReleaseEvent(QMouseEvent *mouse)
{
    switch (mouse->button()) {
    case Qt::RightButton:
    {
        emit signalContextMenu(mouse->globalPos());
    }
    case Qt::LeftButton:
        if(mouse->type()==QEvent::MouseButtonDblClick){
            //            qDebug()<<"dclick";
            emit signalDoubleClick();
        }
        break;
    default:
        break;
    }
    QToolButton::mouseReleaseEvent(mouse);
}

MeasureSetupItemCommon::MeasureSetupItemCommon(E_MeasureSetupItemType itemType ,E_MeasureSetupBranch itemBranch )
{
    //    m_parentItem = parent;
    m_itemType = itemType ;
    m_itemBranch = itemBranch;
    m_IsJoin = true;
    m_OperateWindow = NULL;
    m_Manager=NULL;
}

MeasureSetupItemCommon::~MeasureSetupItemCommon()
{
    qDebug()<< __FUNCTION__;
    cleanWidget();
    cleanWindow();
}

void MeasureSetupItemCommon::slotEventNotify(MeasureSetupMessageCommon & data){
    if(m_itemBranch!=E_MeasureSetupBranch_View && m_IsJoin==false){
        return;
    }
    switch (data.getMessageType()) {
    case E_MsgDataID_CANMsg:
    {
        MeasureSetupMessageCAN fwData(*static_cast<MeasureSetupMessageCAN*>(&data));
        emit sendData(fwData);
    }
        break;
    case E_MsgDataID_Timer:
    {
        MeasureSetupMessageTimer fwData(data.getTimeStamp());
        emit sendData(fwData);
    }
        break;
    case E_MsgDataID_Command:
    {
        MeasureSetupMessageCommand fwData(*static_cast<MeasureSetupMessageCommand*>(&data));
        emit sendData(fwData);
    }
    case E_MsgDataID_Status:
    {
        MeasureSetupMessageStatus fwData(*static_cast<MeasureSetupMessageStatus*>(&data));
        emit sendData(fwData);
    }
        break;
    default:
        break;
    }
}

void MeasureSetupItemCommon::slotDrawContextMenu(const QPoint & pos)
{
    this->setProperty("menutype",sender()->property("type").toInt());
    emit signalDrawContextMenu(pos);
}

void MeasureSetupItemCommon::slotJoinToggle(bool check)
{
    foreach (MeasureSetupWidget * widget, m_widget) {
        if(widget==sender() && sender()->property("type")==E_MeasureSetupItemType_Join){
            widget->setChecked(check);
            m_IsJoin = !check;
            qDebug()<< m_IsJoin;
            break;
        }
    }
}

const QJsonValue  MeasureSetupItemCommon::saveConfig()
{
    QJsonObject retObj;

    if(this->getType()==E_MeasureSetupItemType_None){
        return QJsonValue();
    }

    if(m_Manager){
        retObj = m_Manager->saveConfig().toObject();
    }else{

    }
    if(this->getType()==E_MeasureSetupItemType_Join){
        retObj["type"]=QJsonValue(QString("JOIN"));
    }
    if(this->getType()==E_MeasureSetupItemType_Trace){
        retObj["type"]=QJsonValue(QString("TRACE"));
    }

    retObj["connect"]=m_IsJoin;
    return retObj;
}

void MeasureSetupItemCommon::loadConfig(const QJsonValue &config)
{
    if(m_Manager){
        m_Manager->loadConfig(config);
    }
}

void MeasureSetupItemCommon::slotOpenOpeWindow()
{
    switch (getType()) {
    case E_MeasureSetupItemType_IG:
    {
        emit signalOpenOpeWindow();
    }
        break;
    case E_MeasureSetupItemType_Filter:
    {
        emit signalOpenOpeWindow();
    }
        break;
    case E_MeasureSetupItemType_Trace:
    {
        emit signalOpenOpeWindow();
    }
        break;

    default:
        emit signalOpenOpeWindow();
        break;
    }
}

void MeasureSetupItemCommon::rcvData(MeasureSetupMessageCommon & data){

    //    qDebug()<<"Rcv: "<<getType()<<getBranch() << m_IsJoin;
    if(!m_IsJoin && getBranch()==E_MeasureSetupBranch_View){
        return;
    }
    if(processData(&data)==true || data.getMessageType() != E_MsgDataID_CANMsg){
        if(m_IsJoin || data.getMessageType() != E_MsgDataID_CANMsg ){
            switch (data.getMessageType()) {
            case E_MsgDataID_CANMsg:
            {
                MeasureSetupMessageCAN fwData(*static_cast<MeasureSetupMessageCAN*>(&data));
                emit sendData(fwData);
            }
                break;
            case E_MsgDataID_Timer:
            {
                MeasureSetupMessageTimer fwData(data.getTimeStamp());
                emit sendData(fwData);
            }
                break;
            case E_MsgDataID_Command:
            {
                MeasureSetupMessageCommand fwData(*static_cast<MeasureSetupMessageCommand*>(&data));
                emit sendData(fwData);
            }
            case E_MsgDataID_Status:
            {
                MeasureSetupMessageStatus fwData(*static_cast<MeasureSetupMessageStatus*>(&data));
                emit sendData(fwData);
            }
                break;
            default:
                break;
            }
        }
    }
}

MeasureSetupAbstractTable::MeasureSetupAbstractTable()
{

}

MeasureSetupAbstractTable::~MeasureSetupAbstractTable()
{
    while(m_TableItems.size()>0){
        qDeleteAll (m_TableItems.takeFirst());
    }
}

int MeasureSetupAbstractTable::rowCount(){
    return m_TableItems.size();
}

int MeasureSetupAbstractTable::columnCount(){
    int max=0;
    for (int row=0;row<m_TableItems.size();row++){
        if(max< m_TableItems[row].size())
        {
            max = m_TableItems[row].size();
        }
    }
    return max;
}

void MeasureSetupAbstractTable::insertRows(int position, int rows)
{
    for(int r=0;r<rows;r++){
        QVector<MeasureSetupItemCommon *> addRow;
        m_TableItems.insert(position,addRow);
    }
}

void MeasureSetupAbstractTable::insertColumns(int row,int position, int columns)
{
    if(row >= m_TableItems.size()) return;
    for(int c=0;c<columns;c++){
        m_TableItems[row].insert(position,NULL);
    }
}

void MeasureSetupAbstractTable::removeRows(int position, int rows)
{
    for(int c = 0;c<rows;c++){
        if(position < m_TableItems.size()){
            QVector<MeasureSetupItemCommon*> rowItems = m_TableItems.takeAt(position);
            MeasureSetupItemCommon * item;
            while(rowItems.size()>0){
                item=rowItems.takeFirst();
                if(item){
                    item->deleteLater();
                }
            }
            //            qDebug()<<"Pos" << position;
        }
    }
}

void MeasureSetupAbstractTable::removeColumns(int row,int position, int columns)
{
    if(row >= m_TableItems.size()) return;
    MeasureSetupItemCommon * item;
    for(int c=0;c<columns;c++){
        if(position< m_TableItems[row].size()){
            item = m_TableItems[row].takeAt(position);
            if(item) item->deleteLater();
        }
    }
}

void MeasureSetupAbstractTable::removeAll()
{
    removeRows(0,rowCount());
}

MeasureSetupModel::~MeasureSetupModel()
{
    delete m_IGTable;
    delete m_MainTable;
    delete m_ViewTable;
}

void MeasureSetupModel::removeConnection()
{

}

void MeasureSetupModel::refreshConnection()
{
    MeasureSetupItemCommon * item1, *item2;
    disconnect(&m_rootItem,SIGNAL(sendData(MeasureSetupMessageCommon&)));
    if(m_IGTable){
        for(int row=0;row<m_IGTable->rowCount();row++){
            for(int column=0;column<m_IGTable->m_TableItems[row].size();column++){
                if(column==0){
                    item1 = m_IGTable->item(row,0);
                    if(item1){
                        connect(&m_rootItem,SIGNAL(sendData(MeasureSetupMessageCommon&)),item1,SLOT(rcvData(MeasureSetupMessageCommon&)));
                    }
                }
                item1=m_IGTable->item(row,column);
                item2=m_IGTable->item(row,column+1);
                if(item1){
                    disconnect(item1,SIGNAL(sendData(MeasureSetupMessageCommon&)));
                    if(item1->m_Manager){
                        disconnect(item1->m_Manager,SIGNAL(notifyEvent(MeasureSetupMessageCommon&)));
                        connect(item1->m_Manager,SIGNAL(notifyEvent(MeasureSetupMessageCommon&)),item1,SLOT(slotEventNotify(MeasureSetupMessageCommon&)));
                    }
                    if(item2){
                        //                        qDebug()<<"connect 1";
                        connect(item1,SIGNAL(sendData(MeasureSetupMessageCommon&)),item2,SLOT(rcvData(MeasureSetupMessageCommon&)));
                    }else{
                        //connect to next table
                        if(m_MainTable){
                            for(int r=0;r<m_MainTable->rowCount();r++){
                                item2=m_MainTable->item(r,0);
                                if(item2){
                                    //                                    qDebug()<<"connect 2";
                                    connect(item1,SIGNAL(sendData(MeasureSetupMessageCommon&)),item2,SLOT(rcvData(MeasureSetupMessageCommon&)));
                                }
                            }
                        }
                    }
                }
            }
        }
    }
#if 1
    if(m_MainTable){
        for(int row=0;row<m_MainTable->rowCount();row++){
            for(int column=0;column<m_MainTable->m_TableItems[row].size();column++){
                item1=m_MainTable->item(row,column);
                item2=m_MainTable->item(row,column+1);
                if(item1){
                    disconnect(item1,SIGNAL(sendData(MeasureSetupMessageCommon&)));
                    if(item1->m_Manager){
                        disconnect(item1->m_Manager,SIGNAL(notifyEvent(MeasureSetupMessageCommon&)));
                        connect(item1->m_Manager,SIGNAL(notifyEvent(MeasureSetupMessageCommon&)),item1,SLOT(slotEventNotify(MeasureSetupMessageCommon&)));
                    }

                    if(item2){
                        connect(item1,SIGNAL(sendData(MeasureSetupMessageCommon&)),item2,SLOT(rcvData(MeasureSetupMessageCommon&)));
                    }else{
                        //connect to next table
                        if(m_ViewTable){
                            for(int r=0;r<m_ViewTable->rowCount();r++){
                                item2=m_ViewTable->item(r,0);
                                if(item2){
                                    connect(item1,SIGNAL(sendData(MeasureSetupMessageCommon&)),item2,SLOT(rcvData(MeasureSetupMessageCommon&)));
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if(m_ViewTable){
        for(int row=0;row<m_ViewTable->rowCount();row++){
            for(int column=0;column<m_ViewTable->m_TableItems[row].size();column++){
                item1=m_ViewTable->item(row,column);
                item2=m_ViewTable->item(row,column+1);
                if(item1){
                    disconnect(item1,SIGNAL(sendData(MeasureSetupMessageCommon&)));
                    if(item1->m_Manager){
                        disconnect(item1->m_Manager,SIGNAL(notifyEvent(MeasureSetupMessageCommon&)));
                        connect(item1->m_Manager,SIGNAL(notifyEvent(MeasureSetupMessageCommon&)),item1,SLOT(slotEventNotify(MeasureSetupMessageCommon&)));
                    }
                    if(item2){
                        connect(item1,SIGNAL(sendData(MeasureSetupMessageCommon&)),item2,SLOT(rcvData(MeasureSetupMessageCommon&)));
                    }else{

                    }
                }
            }
        }
    }
#endif
}

void MeasureSetupModel::slotStartStopSimulate()
{
    if(m_Running){
        stopSimulate();
    }else{
        startSimulate();
    }
}

void MeasureSetupModel::startSimulate()
{
    QMap<E_MeasureSetupBranch, MeasureSetupAbstractTable *> maps;

    maps.insert(E_MeasureSetupBranch_IG,m_IGTable);
    maps.insert(E_MeasureSetupBranch_Main,m_MainTable);
    maps.insert(E_MeasureSetupBranch_View,m_ViewTable);

    MeasureSetupItemCommon * item;
    for (QMap<E_MeasureSetupBranch, MeasureSetupAbstractTable *>::iterator it = maps.begin(); it!=maps.end();it++) {
        E_MeasureSetupBranch branch = it.key();
        MeasureSetupAbstractTable * table = it.value();
        for(int row=0;row<table->rowCount();row++){
            for(int column=0;column < table->m_TableItems[row].size();column++){
                item=table->item(row,column);
                if(item&& item->m_Manager){
                    item->m_Manager->startSimulate();
                }
            }
        }
    }
    m_Running=true;
    m_TimeStamp=0;
    testMs=QDateTime::currentMSecsSinceEpoch();
//    m_SyncTimer.setSingleShot(false);
    m_SyncTimer.setInterval(1);
    m_SyncTimer.start();

}

void MeasureSetupModel::stopSimulate()
{
    m_Running=false;
    testMs=0;
//    m_SyncTimer=QTimer();
//    m_SyncTimer.setSingleShot(true);
    m_SyncTimer.stop();
    QMap<E_MeasureSetupBranch, MeasureSetupAbstractTable *> maps;
    maps.insert(E_MeasureSetupBranch_IG,m_IGTable);
    maps.insert(E_MeasureSetupBranch_Main,m_MainTable);
    maps.insert(E_MeasureSetupBranch_View,m_ViewTable);

    MeasureSetupItemCommon * item;
    for (QMap<E_MeasureSetupBranch, MeasureSetupAbstractTable *>::iterator it = maps.begin(); it!=maps.end();it++) {
        E_MeasureSetupBranch branch = it.key();
        MeasureSetupAbstractTable * table = it.value();
        for(int row=0;row<table->rowCount();row++){
            for(int column=0;column < table->m_TableItems[row].size();column++){
                item=table->item(row,column);
                if(item&& item->m_Manager){
                    item->m_Manager->stopSimulate();
                }
            }
        }
    }
}

void MeasureSetupModel::slotSyncTimer()
{
    m_TimeStamp++;
    if(m_TimeStamp==0) {
        m_TimeStamp=1;
    }
    if(m_TimeStamp%10==0){
//        testMs =  QDateTime
//        qDebug() << m_TimeStamp/1000 << QDateTime::currentMSecsSinceEpoch() - testMs;
           m_TimeStamp =  QDateTime::currentMSecsSinceEpoch() - testMs;
    }
    MeasureSetupMessageTimer timer(m_TimeStamp);
    emit m_rootItem.sendData(timer);
}
