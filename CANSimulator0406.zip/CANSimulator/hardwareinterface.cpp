#include "hardwareinterface.h"
#include <math.h>
#include <QJsonArray>
#include <QJsonObject>
HardwareInterfaceConfigWindow::HardwareInterfaceConfigWindow(QWidget * parent,HardwareInterfaceManager* manager):
    QMainWindow(parent),
    m_HardwareManager(manager)
{
    setupUi(this);
    refreshWindow();
    connect(m_ButtonBox,SIGNAL(accepted()),this,SLOT(slotOkButton()));
    connect(m_ButtonBox,SIGNAL(rejected()),this,SLOT(slotCancelButton()));
}

void HardwareInterfaceConfigWindow::refreshWindow()
{
    QMap<int,int> baudMap;
    baudMap.insert(0,125);
    baudMap.insert(1,250);
    baudMap.insert(2,500);
    baudMap.insert(3,1000);

    if(m_HardwareManager){
        foreach (const CANHardwareConfig & CANCfg, m_HardwareManager->m_HardwareCfg) {
            if(CANCfg.m_Name == "CAN1"){
                m_CAN1Baud->setCurrentIndex(baudMap.key(CANCfg.m_Baud,2));
                m_CAN1Used->setChecked(CANCfg.m_Used);
            }else if(CANCfg.m_Name == "CAN2"){
                m_CAN2Baud->setCurrentIndex(baudMap.key(CANCfg.m_Baud,2));
                m_CAN2Used->setChecked(CANCfg.m_Used);
            }
        }
    }
    //TODO: disable
    m_CheckConnection->hide();
    m_CheckProgress->hide();
}

void HardwareInterfaceConfigWindow::slotOkButton(){
    QMap<int,int> baudMap;
    baudMap.insert(0,125);
    baudMap.insert(1,250);
    baudMap.insert(2,500);
    baudMap.insert(3,1000);
    if(m_HardwareManager){
        m_HardwareManager->m_HardwareCfg.clear();
        CANHardwareConfig cfg;
        cfg.m_Name = QString("CAN1");
        cfg.m_Baud = baudMap.value(m_CAN1Baud->currentIndex(),500);
        cfg.m_Used = m_CAN1Used->isChecked();
        m_HardwareManager->m_HardwareCfg.append(cfg);

        cfg.m_Name = QString("CAN2");
        cfg.m_Baud = baudMap.value(m_CAN2Baud->currentIndex(),500);
        cfg.m_Used = m_CAN2Used->isChecked();
        m_HardwareManager->m_HardwareCfg.append(cfg);
    }
    close();
}

void HardwareInterfaceConfigWindow::slotCancelButton(){
    close();
}

HardwareInterfaceManager::HardwareInterfaceManager(CANSimulatorDatabaseAssosiate * assosiateDb):
    m_HardwareIO(NULL),
    m_AssosiateDb(assosiateDb)
{
    m_SendCANTimer.setSingleShot(true);
    connect(&m_SendCANTimer,SIGNAL(timeout()),this,SLOT(slotSendCANTimeout()));
    connect(&m_CheckAliveTimer,SIGNAL(timeout()),this,SLOT(slotCheckAliveTimeout()));
}

HardwareInterfaceManager::~HardwareInterfaceManager(){
    if(m_HardwareIO){
        if(m_HardwareIO->isOpen()){
            sendMessageStopSimulate();
        }
        delete m_HardwareIO;
        m_HardwareIO=NULL;
    }
}

void HardwareInterfaceManager::loadConfig(const QJsonValue & config)
{
    /*
       {
                   "type": "CAN",
                   "AFTER":1,
                   "CAN":[
                        {"name":"CAN1", "used":true,"baud":500 },
                        {"name":"CAN2", "used":false,"baud":500 }
                    ]
       }
*/
    QJsonArray CANarray;
    QJsonObject rootObj, CANObj;
    m_HardwareCfg.clear();
    qDebug()<< config;
    if(config.isObject()){
        rootObj = config.toObject();
        CANarray= rootObj["CAN"].toArray();
        foreach (const QJsonValue &CANitem, CANarray) {
            qDebug()<<CANitem;
            if(CANitem.isObject()){
                CANHardwareConfig cfg;
                CANObj = CANitem.toObject();
                QJsonValue proValue;

                proValue = CANObj["name"];
                cfg.m_Name = proValue.toString();

                proValue = CANObj["used"];
                cfg.m_Used = proValue.toBool();

                proValue = CANObj["baud"];
                cfg.m_Baud = proValue.toInt();

                m_HardwareCfg.append(cfg);
            }
        }
    }
}

const QJsonValue HardwareInterfaceManager::saveConfig()
{
    /*
           {
                       "type": "CAN",
                       "AFTER":1,
                       "CAN":[
                            {"name":"CAN1", "used":true,"baud":500 },
                            {"name":"CAN2", "used":false,"baud":500 }
                        ]
           }
    */
    QJsonArray CANarray;
    QJsonObject rootObj, CANObj;

    foreach (const CANHardwareConfig & canCfg, m_HardwareCfg) {
        CANObj["name"]=canCfg.m_Name;
        CANObj["used"]=canCfg.m_Used;
        CANObj["baud"]=QJsonValue((int)canCfg.m_Baud);
        CANarray.append(CANObj);
    }
    rootObj["CAN"]=CANarray;
    rootObj["connect"]=true;
    rootObj["type"]=QString("CAN");

    return rootObj;
}


void HardwareInterfaceManager::startSimulate(){
    hardwareInit();
}

void HardwareInterfaceManager::stopSimulate(){
    hardwareDeInit();
}

bool HardwareInterfaceManager::hardwareInit()
{
    if(!m_HardwareIO){
        m_HardwareIO = new HardwareIO("COM4",this);
        connect(m_HardwareIO,SIGNAL(signalDataReady()),this,SLOT(slotHasData()));
        qDebug()<<"Select" << m_HardwareIO->portName();
    }
    m_HardwareIO->setBaudRate(QSerialPort::Baud115200);
    if(m_HardwareIO->open(QIODevice::ReadWrite) == false){
        return false;
    }
    qDebug()<<"Open OK" << m_HardwareIO->portName();
    sendMessageStartSimulate();
    sendMessageConfigureCAN();

    return true;
}

bool HardwareInterfaceManager::hardwareDeInit()
{
    if(m_HardwareIO){
        sendMessageStopSimulate();
        m_HardwareIO->close();
    }
    return true;
}
void HardwareInterfaceManager::slotHasData()
{
    if(m_HardwareIO){
        QByteArray data =  m_HardwareIO->readAll();
        parsingReceiveMessage(data.data(),data.size());
    }
}

bool HardwareInterfaceManager::process(MeasureSetupMessageCommon *message){
    if(!message) return false;
    bool ret=false;

    m_TimeStamp = message->getTimeStamp();
    switch (message->getMessageType()) {
    case E_MsgDataID_CANMsg:
    {
        MeasureSetupMessageCAN * canMsg = static_cast<MeasureSetupMessageCAN*>(message);
        //        qDebug()<< "Dir"<< canMsg->getMessageInfo().m_Direction;
        if(canMsg->getMessageInfo().m_Direction==E_Direction_Tx){
            //transmit message
            if(m_HardwareIO){
                //                qDebug()<< "Send data to CAN";
                if(m_TxMessages.size()>100) {
                    m_TxMessages.takeFirst();
                }
                sendMessageCANFrame(canMsg);
                m_TxMessages.append(*canMsg);
                m_SendCANTimer.start(100);
                ret =false; //Do not forward to another node
            }
        }else{
            ret=true;
        }
    }
        break;
    case E_MsgDataID_Timer:
    {
        MeasureSetupMessageTimer * timer = static_cast<MeasureSetupMessageTimer*>(message);
        m_TimeStamp =  timer->getTimeStamp();
        ret=true;
    }
        break;
    default:
        ret = true;
        break;
    }

    return ret;
}

uint16_t HardwareInterfaceManager::parsingReceiveMessage(const char * data, int len)
{
    if(!data|| len<=0)  return 0;
    ST_MsgHeader * header = (ST_MsgHeader*)data;
    switch (header->commandID) {
    case E_CommandID_CHECK_ALIVE_RES:
        processCheckAliveRsp((ST_MsgCheckAliveRsp*)data);
        break;

    case E_CommandID_SEND_MESSAGE_RES:
        processSendCANRsp((ST_MsgTransceiveRsp*)data);
        break;
    case E_CommandID_RECV_CANFRAME:
        processRecvCAN((ST_MsgCANTransceive*)data);
        break;
    default:
        break;
    }
    return header->commandID;
}

void HardwareInterfaceManager::processCheckAliveRsp(ST_MsgCheckAliveRsp * msg){
    qDebug()<<__FUNCTION__<<__LINE__;
    m_CheckAliveTimer.stop();
}

void HardwareInterfaceManager::processSendCANRsp(ST_MsgTransceiveRsp * msg){
    //    qDebug()<<__FUNCTION__<<__LINE__ << msg->status;
    m_SendCANTimer.stop();
    if(msg->status == 1){
        MeasureSetupMessageStatus status(m_TimeStamp,E_MsgStatus_CANTxFailed);
        emit notifyEvent(status);
    }else   if(m_TxMessages.size()>0){
        MeasureSetupMessageCAN sendMsg(m_TxMessages.takeFirst());
        emit notifyEvent(sendMsg);
    }
}

void HardwareInterfaceManager::processRecvCAN(ST_MsgCANTransceive * msg)
{
    //    qDebug()<<__FUNCTION__<<__LINE__ << m_TimeStamp;
    CANMessageSimulate messageCAN;
    messageCAN = m_AssosiateDb->findMessageById(msg->frame.ID,msg->frame.length);
    messageCAN.unpack();
    messageCAN.m_Direction =E_Direction_Rx;
    messageCAN.m_Channel = msg->CANChannel;
    memcpy( messageCAN.m_DataRun , msg->frame.data, 8);
    messageCAN.m_LenRun = msg->frame.length;
    messageCAN.m_Id = msg->frame.ID;
    MeasureSetupMessageCAN sendMsg(m_TimeStamp,messageCAN);
    emit notifyEvent(sendMsg);
}

void HardwareInterfaceManager::processConfigRsp(ST_MsgSetConfigurationRsp * msg){
    qDebug()<<__FUNCTION__<<__LINE__;
}

void HardwareInterfaceManager::processStartSimulateRsp(ST_MsgStartSimulateRsp * msg)
{
    qDebug()<<__FUNCTION__<<__LINE__;

}

void HardwareInterfaceManager::processStopSimulateRsp(ST_MsgStopSimulateRsp * msg){

}

bool HardwareInterfaceManager::sendMessageCheckAliveReq()
{
    if(!m_HardwareIO) return false;
    ST_MsgCheckAliveReq msg;
    COMPOSEHEADER(msg,E_CommandID_CHECK_ALIVE_REQ);
    msg.length=0;
    m_HardwareIO->write((const char*)&msg,sizeof(msg));
    return true;
}

bool HardwareInterfaceManager::sendMessageCANFrame(MeasureSetupMessageCAN * message)
{
    if(!m_HardwareIO) return false;
    ST_MsgCANTransceive  msg;
    COMPOSEHEADER(msg.header,E_CommandID_SEND_MESSAGE_REQ);
    msg.header.length=sizeof(ST_MsgCANTransceive)-sizeof(ST_MsgHeader);
    msg.CANChannel = message->getMessageInfo().m_Channel;
    msg.frame.ID = message->getMessageInfo().m_Id;
    msg.frame.length = message->getMessageInfo().m_LenRun;
    memcpy(msg.frame.data,message->getMessageInfo().m_DataRun,8);
    m_HardwareIO->write((const char*)&msg,sizeof(msg));
}

bool HardwareInterfaceManager::sendMessageConfigureCAN()
{
    if(!m_HardwareIO) return false;
    ST_MsgSetConfigurationReq  msg;
    qint64 len;
    COMPOSEHEADER(msg.header,E_CommandID_BOARD_SET_CONFIG_REQ);
    foreach (const CANHardwareConfig & cfg, m_HardwareCfg) {
        if(cfg.m_Used){
            msg.CANChannel = cfg.m_Name=="CAN1"?1:2;
            msg.baudRate = cfg.m_Baud;
            len= m_HardwareIO->write((const char*)&msg,sizeof(msg));
        }
    }
    len= m_HardwareIO->write((const char*)&msg,sizeof(msg));
    return (len==sizeof(msg));
}
bool HardwareInterfaceManager::sendMessageStartSimulate()
{
    if(!m_HardwareIO) return false;
    ST_MsgStartSimulateReq  msg;
    COMPOSEHEADER(msg,E_CommandID_START_SIMULATION_REQ);
    qint64 len;
    len= m_HardwareIO->write((const char*)&msg,sizeof(msg));
    return (len==sizeof(msg));
}

bool HardwareInterfaceManager::sendMessageStopSimulate()
{
    if(!m_HardwareIO) return false;
    ST_MsgStartSimulateReq  msg;

    COMPOSEHEADER(msg,E_CommandID_STOP_SIMULATION_REQ);
    qint64 len;
    len= m_HardwareIO->write((const char*)&msg,sizeof(msg));
    return len==sizeof(msg);
}

void HardwareInterfaceManager::slotCheckAliveTimeout()
{
    MeasureSetupMessageStatus status(m_TimeStamp,E_MsgStatus_HardwareFailed);
    emit notifyEvent(status);
}

void HardwareInterfaceManager::slotSendCANTimeout()
{
    MeasureSetupMessageStatus status(m_TimeStamp,E_MsgStatus_CANTxFailed);
    emit notifyEvent(status);
}
