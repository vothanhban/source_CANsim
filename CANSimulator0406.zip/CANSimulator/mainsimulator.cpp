#include "mainsimulator.h"
#include "measuresetup.h"
#include <QMdiArea>
#include <QMdiSubWindow>
#include <QFileDialog>
#include <QMessageBox>
MainSimulator::MainSimulator(QWidget *parent) :
    QMainWindow(parent)
  //    ui(new Ui::MainSimulator)
{
    setupUi(this);
    m_MeasureWindow = NULL;
    m_MeasureModel = NULL;

    actionSave->setEnabled(false);
    actionSaveAs->setEnabled(false);
    actionOpenAssosiateDatabase->setEnabled(false);
    actionRemove->setEnabled(false);
    actionEditView->setEnabled(false);
    actionStartSimulate->setEnabled(false);

    connect(actionOpenConfig,SIGNAL(triggered()),this, SLOT(slotOpenConfig()));
    connect(actionSave,SIGNAL(triggered()),this, SLOT(slotSaveConfig()));
    connect(actionSaveAs,SIGNAL(triggered()),this, SLOT(slotSaveAsConfig()));
    connect(actionAssosiate,SIGNAL(triggered()),this, SLOT(slotAssosiateDatabase()));
    //    setAttribute(Qt::WA_DeleteOnClose);
    //    connect(this,SIGNAL())
}

MainSimulator::~MainSimulator()
{
    qDebug()<< __FUNCTION__<<__LINE__;
    if(m_MeasureModel){
        delete m_MeasureModel;
        m_MeasureModel=NULL;
    }
    if(m_MeasureWindow){
        delete m_MeasureWindow;
        m_MeasureWindow=NULL;
    }
}

void MainSimulator::closeEvent(QCloseEvent * event)
{
    qDebug()<< __FUNCTION__<<__LINE__;
    if(m_MeasureModel){
        int ret = QMessageBox::question(this,"Close configuration","Do you want to save your changes?",QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
        if(ret== QMessageBox::Save){
            if(m_MeasureModel){
                m_MeasureModel->saveConfig();
            }
            if(m_MeasureModel){
                delete m_MeasureModel;
                m_MeasureModel=NULL;
            }
            if(m_MeasureWindow){
                delete m_MeasureWindow;
                m_MeasureWindow=NULL;
            }

            event->accept();
        }if(ret== QMessageBox::Discard){
            if(m_MeasureModel){
                delete m_MeasureModel;
                m_MeasureModel=NULL;
            }
            if(m_MeasureWindow){
                delete m_MeasureWindow;
                m_MeasureWindow=NULL;
            }
            event->accept();
        }if(ret== QMessageBox::Cancel){
            event->ignore();
        }
    }else{
        event->accept();
    }
    return;
}

bool MainSimulator::close()
{
    qDebug()<< __FUNCTION__<<__LINE__;
    return QMainWindow::close();
}

void MainSimulator::showMeasureSetup()
{
    if(m_MeasureWindow){
        m_MeasureWindow->showMaximized();
    }else{
        if(!m_MeasureModel){
            m_MeasureModel = new MeasureSetupModel(m_ConfigPath);
        }
        QMdiSubWindow * subWin;
        m_MeasureWindow = new MeasureSetupWindow(this,m_MeasureModel);
        m_MeasureWindow->setWindowTitle(QString("Measurement Setup [") + m_ConfigPath +QString("]"));
        QMdiArea * mdiArea = new QMdiArea(this);
        setCentralWidget(mdiArea);
        subWin =  mdiArea->addSubWindow(m_MeasureWindow,0);
        connect(m_MeasureWindow,SIGNAL(destroyed()),this, SLOT(slotCloseMeasureSetup()));
    }
}

void MainSimulator::slotOpenConfig()
{
    QFileDialog * fileDialog=new QFileDialog();
    //    QString fileName = QFileDialog::getOpenFileName( fileDialog, ("Create new database file"), QDir::currentPath(), ("Database files (*.json);;All files (*.*)"), 0, QFileDialog::DontUseNativeDialog );
    QString fileName = QFileDialog::getOpenFileName( fileDialog, ("Open configuration"), QDir::currentPath(), ("Configuration file (*.json);;All files (*.*)"), 0, QFileDialog::DontUseNativeDialog );
    if(!fileName.isEmpty()){
        if(m_MeasureModel){
            delete m_MeasureModel;
            m_MeasureModel=NULL;
        }
        if(m_MeasureWindow){
            delete m_MeasureWindow;
            m_MeasureWindow = NULL;
        }
        m_MeasureModel =  new MeasureSetupModel(fileName);
        m_ConfigPath = fileName;
        showMeasureSetup();
        actionSave->setEnabled(true);
        actionSaveAs->setEnabled(true);
        actionOpenAssosiateDatabase->setEnabled(true);
        actionRemove->setEnabled(false);
        actionEditView->setEnabled(false);
        actionStartSimulate->setEnabled(true);
        connect(actionStartSimulate,SIGNAL(triggered()),m_MeasureModel,SLOT(slotStartStopSimulate()));
    }
}

void MainSimulator::slotSaveAsConfig()
{
    QFileDialog * fileDialog=new QFileDialog();
    QString fileName = QFileDialog::getSaveFileName(fileDialog, ("Save configuration"), QDir::currentPath(), ("Configuration file (*.json);;All files (*.*)"), 0, QFileDialog::DontUseNativeDialog );
    if(!fileName.isEmpty()){
        if(m_MeasureModel){
            m_ConfigPath = fileName;
            m_MeasureModel->saveConfig(fileName);
        }
    }
}
void MainSimulator::slotSaveConfig()
{
    if(m_MeasureModel){
        m_MeasureModel->saveConfig(m_ConfigPath);
    }
}

void MainSimulator::slotCloseMeasureSetup(){
    qDebug()<<__FUNCTION__<<__LINE__;
    m_MeasureWindow = NULL;
}

void MainSimulator::slotAssosiateDatabase()
{
    if(m_MeasureModel){
        AssosiateDbDialog dialog(this,m_MeasureModel->m_AssosiateDb->getAssosiateDbInfo());
        connect(&dialog,SIGNAL(acceptAssosiateDbInfo(QVector<CANAssosiateDbInfo>)),m_MeasureModel,SLOT(slotUpdateAssosiateDbInfo(QVector<CANAssosiateDbInfo>)));
        dialog.exec();
    }
}
