#ifndef FILTERMANAGER_H
#define FILTERMANAGER_H

#include <QMainWindow>
#include <QJsonValue>
#include"candefine.h"
#include"assosiatedb.h"
#include "measuresetup.h"
#include "ui_filtermanager.h"
#include "ui_filterinsert.h"
#include "ui_insertmessagedialog.h"

class FilterNodeManager;

typedef enum{
    E_FilterType_None=0,
    E_FilterType_CANRange,
    E_FilterType_CANMessage,
    E_FilterType_ErrFrame,
}E_FilterType;

typedef struct FilterData{
    unsigned int m_StartID;
    unsigned int m_EndID;
    bool m_isExtended;
    bool m_Tx;
    bool m_Rx;
    bool m_TxRq;
    bool m_RTRData;
    bool m_RTRRemote;
    int m_Channels;
    QString m_DbName;
    QString m_Name;
    QString m_Comment;
    E_FilterType m_Type;
    FilterData(){
        m_Type = E_FilterType_None;
        m_StartID = 0;
        m_EndID = 0;
        m_isExtended=false;
        m_Tx = true;
        m_Rx = true;
        m_TxRq = false;
        m_RTRData=true;
        m_RTRRemote=true;
        m_Channels = 0;
    }
}FilterData;

class FilterManagerWindow : public  QMainWindow, Ui_FilterManager
{
    Q_OBJECT

public:
    explicit FilterManagerWindow(QWidget *parent = 0,
                                 const bool filterStop = false,
                                 const QVector<FilterData> & filter = QVector<FilterData>(),
                                 CANSimulatorDatabaseAssosiate * assosiateDb=NULL
                                 );
    ~FilterManagerWindow();
signals:
    void signalSaveFilter(bool stopFilter, QVector<FilterData>&);
public slots:
    void addFilter(FilterData & newFilter);
    void slotOKButton();
    void slotCancelButton();
    void slotInsertRangeButton();
    void slotInsertMessageButton();
    void slotRemoveButton();
private:
    void drawFilterData();
    CANSimulatorDatabaseAssosiate * m_AssisiateDatabase;
    QVector<FilterData> m_Filters;
    bool m_StopFilter;
};


class FilterNodeManager: public MeasureSetupManagerCommon
{
    Q_OBJECT

public:
    FilterNodeManager(){}
    void loadConfig(const QJsonValue & config); //load config from Json node
    const QJsonValue saveConfig(); //Save config to an Json node
/*
 *         {
             "type": "FILTER",
             "AFTER":1,
             "name":"PF",
             "IdMin":111,
             "IdMax":222,
             "Channels":"1"
        }
*/
    bool process(MeasureSetupMessageCommon * message=NULL); // true: pass,false: stop (do not forward)
    QVector<FilterData> & getFilters(){return m_Filters ;}
    bool getFilterStop(){return m_StopFilter ;}
public slots:
        void slotSaveFilterData( bool stopFilter,QVector<FilterData> & filters){
            m_Filters.clear();
            m_Filters = filters;
            m_StopFilter =  stopFilter;
            //TODO: just test
        }

private:
    QVector<FilterData> m_Filters;
    bool m_StopFilter; //true: pass filter, false: stop filter
};

class FilterInsertDialog:public QDialog, Ui_FilterInserDialog
{
    Q_OBJECT
public:
    FilterInsertDialog(QWidget *parent = 0, FilterData *RspData =0):
    QDialog(parent)
    {
            setupUi(this);
            setWindowTitle("Insert Filter");
            m_rspData = RspData;
    }
public slots:
    void accept()
    {
        if(m_rspData){
            m_rspData->m_StartID = m_StartID->text().toUInt(0,16);
            m_rspData->m_EndID = m_EndID->text().toUInt(0,16);
            m_rspData->m_Type = E_FilterType_CANRange;
            m_rspData->m_isExtended = m_isExtended->isChecked();
        }
        QDialog::accept();
    }
private:
    FilterData *m_rspData;
};

class FilterInsertMessageDialog: public QDialog, Ui_InsertMessageDialog
{
    Q_OBJECT
public :
    FilterInsertMessageDialog(QWidget * parent = 0,CANSimulatorDatabaseAssosiate * AssosiateDb=0,QVector<FilterData> * rspData=NULL);
    ~FilterInsertMessageDialog(){}

signals:
    void signalAddNewItem(FilterData& filter);

public slots:
    void slotSearchButton();
    void accept(); //overwrite

private:


    CANSimulatorDatabaseAssosiate * m_AssosiateDb;
    QVector<FilterData> * m_rspFilterData;
};

#endif // FILTERMANAGER_H
