#ifndef UTILITIES_H
#define UTILITIES_H

#include <QStringList>
#include <QAbstractSpinBox>
#include <QLineEdit>
#include <algorithm>
#include <limits>
#include <QDebug>
#define PI 3.1415926535898

class  ULongLongSpinBox : public QAbstractSpinBox
{
    Q_OBJECT

public:
    ULongLongSpinBox(QWidget * parent = 0);

    virtual void fixup(QString & input) const;
    virtual void stepBy(int steps);
    virtual QValidator::State validate(QString & input, int & pos) const;

    qulonglong value() const;
    void setValue(qulonglong value);

    qulonglong minimum() const;
    void setMinimum(qulonglong minimum);

    qulonglong maximum() const;
    void setMaximum(qulonglong maximum);

    qulonglong step() const;
    void setStep(qulonglong step);

    void setRange(qulonglong min,
                  qulonglong max);
    void setBase(int base = 10);
signals:
    void valueChanged(qulonglong value);

protected slots:
    void onEditingFinished();

protected:
    virtual StepEnabled stepEnabled() const;

private:
    QString textFromValue(qulonglong value);
    qulonglong valueFromText(const QString & text);
    qulonglong validateAndInterpret(const QString & input,
                                    int & pos,
                                    QValidator::State & state) const;

private:
    qulonglong m_min;
    qulonglong m_max;
    qulonglong m_step;
    qulonglong m_value;
    int m_base;
};

class HexStringValidator : public QIntValidator {
public:
    HexStringValidator(QObject * parent) : QIntValidator(parent) {}

public:
    virtual void fixup(QString &input) const {
        input = input.toUpper();
    }

    virtual State validate(QString &input, int &pos) const {
        if(!input.isEmpty()) {
            bool ok;
            int number = input.toInt(&ok,16);
            if(ok){
                if(number < bottom() || number > top()){
                    return QValidator::Invalid;
                }else{
                    input = QString::number(number,16).toUpper();
                    return QValidator::Acceptable;
                }
            }else{
                return QValidator::Invalid;
            }
        }else{
            return QValidator::Acceptable;
        }
    }
};

class LineEdit: public QLineEdit
{
    Q_OBJECT
public:
    LineEdit(QWidget * parent=NULL):
        QLineEdit(parent)
        {}
    ~LineEdit(){}
protected:
    void mousePressEvent(QMouseEvent * evt)
    {
        emit textChanged(text());
    }

};
#endif // UTILITIES_H
