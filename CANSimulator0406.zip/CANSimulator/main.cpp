#include "mainsimulator.h"
#include "tracemanager.h"
#include "filtermanager.h"
#include "interactivemanager.h"
#include "hardwareinterface.h"
#include <QApplication>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QJsonValue>
#include <QFile>
#include <QFileDialog>
#include <QObject>
#include <QSerialPort>
#include <stdint.h>
#include <stdint-gcc.h>
#include <limits.h>
#include <float.h>
#include <math.h>
double retval(double vl){return vl;}
int main(int argc, char *argv[])
{

    QApplication a(argc, argv);
    MainSimulator w;
    w.show();
#if 0
    TraceManager * traceManager = new TraceManager(NULL,NULL);
    CANMessageSimulate msg;
    msg.m_Id = 100;
    msg.m_Name = QString("Msg1");
    msg.m_Channel = 1;
    msg.m_Len = 5;
    msg.m_Data[0]=0xDE;
    msg.m_Data[1]=0xAD;
    msg.m_Data[2]=0xBE;
    msg.m_Data[3]=0xEF;
    msg.m_Data[4]=0x01;
    msg.m_isReqToTx = true;
    msg.m_Direction = E_Direction_Rx;

    CANSignalSimulate signal;
    signal.m_Value.dValue = 34.6;
    signal.m_CANSign.m_Name = QString("Signal 1");
    msg.m_CANSignals.append(signal);

    signal.m_Value.dValue = 12.3;
    signal.m_CANSign.m_Name = QString("Signal 2");
    msg.m_CANSignals.append(signal);

    MeasureSetupMessageCAN item1(1,msg);

    msg.m_isReqToTx = true;
    msg.m_Id = 100;
    msg.m_Channel = 2;
    msg.m_Name = QString("Msg2");
    msg.m_Direction = E_Direction_Rx;
    MeasureSetupMessageCAN item2(2,msg);

    traceManager->process(&item1);
    traceManager->process(&item2);
    TraceWindow * traceWindow = new TraceWindow (&w,traceManager);
    traceWindow->show();
#elif 0
    CANSimulatorDatabaseAssosiate *            dbAssosiate = new CANSimulatorDatabaseAssosiate();
    dbAssosiate->test();

    FilterNodeManager * filterManager = new FilterNodeManager();
    QJsonDocument doc = QJsonDocument::fromJson(
                "{\
                \"type\":\"FILTER\",\
                \"AFTER\":1,\
                \"name\": \"PF\",\
                \"stop\": false,\
                \"data\":\[\
    \{\"kind\":1,\"startId\":111,\"endId\":222, \"Tx\":true, \"Rx\":false , \"RTRData\":true, \"RTRRemote\":false , \"channels\":0},\
       \{\"kind\":1,\"startId\":222,\"endId\":333, \"Tx\":false, \"Rx\":true , \"RTRData\":false, \"RTRRemote\":true, \"channels\":1},\
          \{\"kind\":2,\"database\":\"ECU1.dbc\",\"name\":\"ENGINE\",\"id\":44, \"Tx\":false, \"Rx\":true, \"RTRData\":true, \"RTRRemote\":true , \"channels\":2},\
             \{\"kind\":3,\"Tx\":false, \"Rx\":true, \"RTRData\":false, \"RTRRemote\":false , \"channels\":2}\
                \]\
             }"  );
             filterManager->loadConfig(doc.object());
             FilterManagerWindow * filterWindow = new FilterManagerWindow(&w,filterManager->getFilterStop(),filterManager->getFilters(),dbAssosiate);
             QObject::connect(filterWindow,SIGNAL(signalSaveFilter(bool,QVector<FilterData>&)),filterManager,SLOT(slotSaveFilterData(bool,QVector<FilterData>&)));
             filterWindow->show();
         #elif 0
    CANSimulatorDatabaseAssosiate *            dbAssosiate = new CANSimulatorDatabaseAssosiate();
    dbAssosiate->test();

    InteractiveManager *interactiveManager =  new InteractiveManager(dbAssosiate);
    QJsonDocument doc = QJsonDocument::fromJson("\{\
                                                \"type\": \"IG\",\
                                                \"AFTER\":1,\
                                                \"name\":\"IG1\",\
                                                \"MSGS\":\[\
    \{\
                                                    \"file\":\"ECU1.dbc\",\
                                                    \"name\": \"ENGINE\",\
                                                    \"cycle\": 100,\
                                                    \"enable\": true,\
                                                    \"txreq\": false,\
                                                    \"len\": 8,\
                                                    \"data\":\[1,2,3,4,5,6,7,8\],\
                                                    \"SIGNS\":\[\
                                                    \{ \"name\":\"SPEED\", \"sb\": 0,\"wave\":\"none\",\"enable\":true,\
                                                        \"waveprop\": \{\
                                                        \"none\":\{\},\
                                                        \"sine\":\{\"amplitude\":10.0,\"cycles\":100,\"phase\":45,\"offset\":10.0\},\
                                                        \"square\":\{\"crestval\":10.0, \"troughval\":0.0,\"crestcycles\":100, \"troughcycles\":100\}\
                                                    \}\
                                                \}\
                                                \]\
\}\
\]\
\}");
interactiveManager->loadConfig(doc.object());
QJsonValue jValue =  interactiveManager->saveConfig();
qDebug()<<QJsonDocument(jValue.toObject()).toJson(QJsonDocument::Indented);
InteractiveManagerWindow * interactiveWindow =  new InteractiveManagerWindow(&w,/*&interactiveManager->getMessageInfo()*/NULL,dbAssosiate);
interactiveWindow->show();
#elif 0
    QJsonDocument doc = QJsonDocument::fromJson  ("\{\
                                                  \"type\": \"CAN\",\
                                                  \"AFTER\":1,\
                                                  \"CAN\":\[\
    \{\"name\":\"CAN1\", \"used\":true,\"baud\":250 \},\
       \{\"name\":\"CAN2\", \"used\":false,\"baud\":125 \}\
          \]\
       \}"
       );
       HardwareInterfaceManager * hwManager = new HardwareInterfaceManager();
       hwManager->loadConfig(doc.object());
       QJsonValue retValue ;
       retValue= hwManager->saveConfig().toObject();
       qDebug()<<QJsonDocument(retValue.toObject()).toJson(QJsonDocument::Indented);
       HardwareInterfaceConfigWindow *hwConfigWindow= new HardwareInterfaceConfigWindow(NULL,hwManager);
       hwConfigWindow->show();

       CANMessageSimulate msgData;
       msgData.m_Name = QString("Hello message");
       MeasureSetupMessageCAN  canmsg(1,msgData);
       MeasureSetupMessageCommon *common = dynamic_cast<MeasureSetupMessageCommon*>(&canmsg);

       MeasureSetupMessageCAN *castedCanMsg = static_cast<MeasureSetupMessageCAN*>(common);
       qDebug()<<castedCanMsg->getMessageInfo().m_Name;
   #endif


       return a.exec();
                                                  }
