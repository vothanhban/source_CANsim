#include "utilities.h"
#include "candefine.h"
#include <math.h>

CANSignalSimulate::CANSignalSimulate()
{
    m_WaveForm =  E_CANSignalWaveForm_None;
    m_WaveUsed = false;
    m_StartBit = 0;
    m_Value.uValue = 0;
}

void CANSignalSimulate::pack(unsigned char * data /*byte array of message*/,
                             unsigned char length /*Length in byte of message*/,
                             unsigned long long timestamp,unsigned int cycle)
{
    double value;
    value = get_waveform_value(timestamp,cycle);
    pack(data,length,value);
}

void CANSignalSimulate::pack(unsigned char * data,unsigned char length, double phy_value)
{
    unsigned long long signalVal;

    signalVal= to_signal_value(phy_value).uValue;

    switch (this->m_CANSign.m_ByteOrder) {
    case E_CANByteOrder_Intel:
        /* data[0|1|2|3|4|5|6|7]
 * Intel: LSB first
*/
        pack_intel(data,m_StartBit,length,signalVal);
        break;
    case E_CANByteOrder_Motorola:
        /* data[0|1|2|3|4|5|6|7]
 * Intel: MSB first
*/
        pack_motorola(data,m_StartBit,length,signalVal);
        break;
    default:
        break;
    }

}

void CANSignalSimulate::unpack(unsigned char * data, unsigned char length){
    /*For transmit and receive*/

    unsigned long long signalValue ;
    double physical_value;
    switch (this->m_CANSign.m_ByteOrder) {
    case E_CANByteOrder_Intel:
        /* data[0|1|2|3|4|5|6|7]
 * Intel: LSB first
*/
        signalValue = unpack_intel(data,this->m_CANSign.m_ValueType!=E_CANSignalType_UnSigned,m_StartBit,length);
        break;
    case E_CANByteOrder_Motorola:
        /* data[0|1|2|3|4|5|6|7]
 * Motorola: MSB first
*/
        signalValue = unpack_motorola(data,this->m_CANSign.m_ValueType!=E_CANSignalType_UnSigned,m_StartBit,length);
        break;
    default:
        break;
    }
    /*Step 2:  m_Value = signal value * resolution + offset*/
    physical_value =to_physical_value(signalValue);
    this->m_ValueRun.dValue =  physical_value;
}

double CANSignalSimulate::get_waveform_value(unsigned long long timestamp, unsigned int cycle){
    double value=0.0;
    switch (m_WaveForm) {
    case E_CANSignalWaveForm_Sine:
        value = m_WaveFormProperties.m_Sine.m_Amplitude * sin(2*PI/m_WaveFormProperties.m_Sine.m_Cycle * (timestamp/cycle) + PI*m_WaveFormProperties.m_Sine.m_Phase/180.0) + m_WaveFormProperties.m_Sine.m_Offset;
        break;
    case E_CANSignalWaveForm_Square:
        value = (timestamp/cycle)%(m_WaveFormProperties.m_Square.m_CycleH + m_WaveFormProperties.m_Square.m_CycleL) <= m_WaveFormProperties.m_Square.m_CycleH ?
                    m_WaveFormProperties.m_Square.m_PeakH:
                    m_WaveFormProperties.m_Square.m_PeakL;
    default:
        value = m_Value.dValue; //Get value (not run-time value);
        break;
    }

    return value;
}

U_CANValue CANSignalSimulate::to_signal_value(double phy_value)
{
    U_CANValue ret;
    // raw value = physical value * resolution + offset
    ret.dValue =  phy_value / this->m_CANSign.m_Factor + this->m_CANSign.m_Offset;
//    qDebug()<<m_CANSign.m_Name << "Len" << m_CANSign.m_Length << "SB"<<m_StartBit << "Fact"<<m_CANSign.m_Factor << "Offs" << m_CANSign.m_Offset << "Type"<<m_CANSign.m_ValueType;

    switch (m_CANSign.m_ValueType) {
    case E_CANSignalType_Signed:
        ret.lValue = (long long)ret.dValue;
        if(ret.lValue<0){
            ret.lValue = 0 - ret.lValue;
            ret.lValue | (1<<m_CANSign.m_Length-1);
        }else{
            
        }
        break;
    case E_CANSignalType_UnSigned:
        ret.uValue = (unsigned long long)ret.dValue;
        break;
    case E_CANSignalType_Float:
        ret.fValue = (float)ret.dValue;
        break;
    case E_CANSignalType_Double:
        break;
    default:
        break;
    }
    return ret;
}

double CANSignalSimulate::to_physical_value(unsigned long long value /*Raw value*/){
    U_CANValue ret;
    unsigned long long mask = 1,tmp ;
    ret.uValue = value;
    switch (m_CANSign.m_ValueType) {
    case E_CANSignalType_Signed:
        mask = mask << (m_CANSign.m_Length-1);
        tmp = mask & value;
        if(tmp != 0){
            value = value & (~mask);//remove signed bit
            ret.uValue = 0-value;
        }else{
            ret.uValue = value;
        }
        ret.dValue = ret.lValue;
        break;
    case E_CANSignalType_UnSigned:
        ret.dValue = ret.uValue;
        break;
    case E_CANSignalType_Float:
        ret.dValue = ret.fValue;
        break;
    case E_CANSignalType_Double:
        break;
    default:
        break;
    }
    ret.dValue = ret.dValue * m_CANSign.m_Factor + m_CANSign.m_Offset;
    return ret.dValue;
}

void CANSignalSimulate::pack_intel(unsigned char * data, unsigned char startbit, unsigned char bitcount, unsigned long long  value)
{
    unsigned char shift;
    while (bitcount > 0) {
        shift = startbit % 8;
        /* Clear the bits to write. */
        data[startbit / 8] &= ~(((1 << bitcount) - 1) << shift);
        /* Set the bits to write. */
        data[startbit / 8] |= (((1 << bitcount) - 1) & value) << shift;
        /* Get the next bit position. */
        bitcount -= 8 - shift;
        startbit += 8 - shift;
        /* Remove the currently written part of value. */
        value >>= 8 - shift;
    }
}

void CANSignalSimulate::pack_motorola(unsigned char * data, unsigned char startbit, unsigned char bitcount, unsigned long long  value)
{
    unsigned char bits;

    while (bitcount > 0) {
        /* Get the number of bits to work on. */
        bits = startbit % 8 + 1;
        bits = bits < bitcount ? bits : bitcount;
        /* Clear the bits to write. */
        data[startbit / 8] &= ~(((1 << bits) - 1) << (startbit % 8 + 1 - bits));
        /* Set the bits to write. */
        data[startbit / 8] |= (((1 << bitcount) - 1) & value) >> (bitcount - bits) << (startbit % 8 + 1 - bits);
        /* Get the next bit position. */
        bitcount -= bits;
        startbit = (startbit & ~(0x07)) + 15;
    }
}

unsigned long long CANSignalSimulate::unpack_intel(unsigned char  const * data, bool sign,unsigned char startbit, unsigned char bitcount )
{
    ulong value = 0;
    uchar shift = 0;
    while (bitcount > 0) {
        /* Get the bottommost part of the value. */
        value |= ((data[startbit / 8] >> (startbit % 8)) & ((1ul << bitcount) - 1)) << shift;
        /* Update counters. */
        bitcount -= 8 - (startbit % 8);
        shift += 8 - (startbit % 8);
        startbit += 8 - (startbit % 8);
    }

    if (sign && (value >> (shift + bitcount - 1))) {
        return ((~0ul) << (shift + bitcount)) | value;
    }
    return value;
}

unsigned long long CANSignalSimulate::unpack_motorola(unsigned char  const * data, bool sign,unsigned char startbit, unsigned char bitcount )
{

}

void CANMessageSimulate::pack(unsigned long long timestamp)
{
    //pack all signals
    //    m_Data[0] =0xDE;
    for(int i=0;i< m_CANSignals.size();i++){
        m_CANSignals[i].pack(m_DataRun,m_CANSignals[i].m_CANSign.m_Length,timestamp,m_Cycle);
    }
}

void CANMessageSimulate::packall()
{
    for(int i=0;i< m_CANSignals.size();i++){
        m_CANSignals[i].pack(m_DataRun,m_CANSignals[i].m_CANSign.m_Length,m_CANSignals[i].m_Value.dValue);
    }
    for(int i=0;i<8;i++)m_Data[i]=m_DataRun[i];
}

void CANMessageSimulate::unpack()
{
    //unpack all signals
    for(int i=0;i< m_CANSignals.size();i++){
        m_CANSignals[i].unpack(m_DataRun,m_CANSignals[i].m_CANSign.m_Length);
    }
}
