#ifndef CANDEFINES_H
#define CANDEFINES_H
#include <QVector>
#include <QMap>
#include <QString>
/*Byte order*/
typedef enum {
    E_CANIntelBitOrder_Sequential = 0,
    E_CANIntelBitOrder_Standard
}E_CANIntelBitOrder;

typedef enum {
    E_CANMotoBitOrder_ForwardLSB,
    E_CANMotoBitOrder_ForwardMSB,
    E_CANMotoBitOrder_Sequential,
    E_CANMotoBitOrder_Backward
}E_CANMotoBitOrder;

typedef enum {
    E_CANByteOrder_Intel = 0,
    E_CANByteOrder_Motorola = 1,
}E_CANByteOrder;
/*End Byte order*/

/*multiplex*/
typedef enum {
    E_CANSignalMultiplex_None=0,
    E_CANSignalMultiplex_OR,
    E_CANSignalMultiplex_ED,
}E_CANSignalMultiplex;
/*End multiplex*/

/*type*/
typedef enum {
    E_CANSignalType_Signed=0,
    E_CANSignalType_UnSigned,
    E_CANSignalType_Float,
    E_CANSignalType_Double,
}E_CANSignalType;
/*End type*/

/*ID type*/
typedef enum {
    E_CANMsgIDType_Standard=0,
    E_CANMsgIDType_Extended
}E_CANMsgIDType;
/*End ID type*/

typedef enum{
//    E_CANChannels_None=0,
    E_CANChannels_All=0,
    E_CANChannels_1,
    E_CANChannels_2,

}E_CANChannels;
/*union value in different types*/
typedef union{
    long long lValue;
    unsigned long long uValue;
    float fValue;
    double dValue;
}U_CANValue;
/*End union value in different types*/

/*Wave form*/
typedef enum{
    E_CANSignalWaveForm_None=0,
    E_CANSignalWaveForm_Sine,
    E_CANSignalWaveForm_Square
}E_CANSignalWaveForm;
/*End Wave form*/

typedef struct  CANSignal{
    QString m_Name; // signal names
    QString m_Unit;
    QString m_Comment; // signal comments
    QString m_Node;
    QString m_ValueTable;
    unsigned char m_Length; //length in bit
    E_CANByteOrder m_ByteOrder;
    E_CANSignalType m_ValueType;
    E_CANSignalMultiplex m_Multiplex;
    double m_MultiplexedValue;
    U_CANValue m_InitValue;
    double m_Factor;
    double m_Offset;
    double m_Min;
    double m_Max;
#ifdef __cplusplus
    CANSignal(){
        m_Factor=1.0;
        m_Offset=0;
        m_Min=0;
        m_Max=0;
        m_ByteOrder = E_CANByteOrder_Intel;
        m_ValueType = E_CANSignalType_Signed;
        m_Length = 8;
        m_Multiplex =E_CANSignalMultiplex_None;
    }
#endif
}CANSignal;

typedef struct CANSignalInMessage{
    unsigned char m_StartBit;
    CANSignal m_Signal;
#ifdef __cplusplus
    CANSignalInMessage(){
        m_StartBit = 0;
    }
#endif
}CANSignalInMessage;

typedef struct CANMessage{
    QString m_Name; // signal names
    QString m_Comment; // signal comments
    unsigned char m_Length; //length in byte
    unsigned int m_ID;
    E_CANMsgIDType m_IdType;
    QVector<CANSignalInMessage> m_Signals;
#ifdef __cplusplus
    CANMessage(){
        m_Length = 8;
        m_IdType = E_CANMsgIDType_Standard;
        m_Signals.clear();
        m_ID = 0;
    }
#endif
}CANMessage;

typedef enum{
    E_Direction_Tx=0,
    E_Direction_Rx,
}E_Direction;

typedef enum{
    E_EventType_None=0,
    E_EventType_RTR,
    E_EventType_Error,
}E_EventType;

enum{
    E_DBCIndexSignal_Name=1,
    E_DBCIndexSignal_StartBit,
    E_DBCIndexSignal_Len,
    E_DBCIndexSignal_ByteOrder,
    E_DBCIndexSignal_ValueType=E_DBCIndexSignal_ByteOrder,
    E_DBCIndexSignal_Factor,
    E_DBCIndexSignal_Offset,
    E_DBCIndexSignal_Min,
    E_DBCIndexSignal_Max,
    E_DBCIndexSignal_Unit,
    E_DBCIndexSignal_Node
}E_DBCIndexSignal;

enum{
    E_DBCIndexMsg_Id=1,
    E_DBCIndexMsg_Name,
    E_DBCIndexMsg_Len,
    E_DBCIndexMsg_RxNode
}E_DBCIndexMsg;

typedef struct CANSignalWaveData{
    struct __sine{
        unsigned int m_Cycle;
        double m_Amplitude;
        double m_Offset;
        int m_Phase;
    }m_Sine;
    struct __square{
        unsigned int m_CycleH;
        double m_PeakH;
        unsigned int m_CycleL;
        double m_PeakL;
    }m_Square;
    CANSignalWaveData(){
        m_Sine.m_Cycle = 1000;
        m_Sine.m_Amplitude = 10;
        m_Sine.m_Offset = 0;
        m_Sine.m_Phase = 0;
        m_Square.m_PeakH = 1;
        m_Square.m_PeakL = 0;
        m_Square.m_CycleH = 10;
        m_Square.m_CycleL = 10;
    }
}CANSignalWaveData;

class CANSignalSimulate{
public:
    CANSignalSimulate();
    ~CANSignalSimulate(){}
    unsigned char m_StartBit;
    CANSignal m_CANSign;
    bool m_WaveUsed;
    E_CANSignalWaveForm m_WaveForm;
    CANSignalWaveData m_WaveFormProperties;
    U_CANValue m_Value;
    U_CANValue m_ValueRun;
    double get_waveform_value(unsigned long long timestamp, unsigned int cycle);
    U_CANValue to_signal_value(double phy_value);
    double to_physical_value(unsigned long long value);
    static void pack_intel(unsigned char * data, unsigned char startbit, unsigned char bitcount, unsigned long long value);
    static void pack_motorola(unsigned char * data, unsigned char startbit, unsigned char bitcount, unsigned long long value);
    static unsigned long long unpack_intel(unsigned char  const * data, bool sign,unsigned char startbit, unsigned char bitcount );
    static unsigned long long unpack_motorola(unsigned char  const * data, bool sign,unsigned char startbit, unsigned char bitcount );
    void pack(unsigned char * data,unsigned char length, unsigned long long timestamp, unsigned int cycle); /*For transmit*/
    void pack(unsigned char * data,unsigned char length,double phy_val);
    void unpack(unsigned char * data,unsigned char length); /*For transmit and receive*/
};

class CANMessageSimulate{
public:
    void pack(unsigned long long timestamp);
    void packall();
    void unpack();
    CANMessageSimulate(){
        m_CANSignals.clear();
        m_Direction = E_Direction_Rx;
        m_isReqToTx = false;
        m_Channel = 1;
        m_Cycle = 0;
        m_Id = 0;
        m_Len = 8;
        m_LenRun = 8;
        m_isCANErrorFrame=false;
        m_CycleSent = false;
        for (int i=0;i<8;i++) {
            m_Data[i]=0;
            m_DataRun[i]=0;
        }
    }
    ~CANMessageSimulate(){}
    QVector<CANSignalSimulate> m_CANSignals;
    bool m_isCANErrorFrame;
    QString m_DbPath;
    QString m_DbName;
    QString m_Name;
    QString m_Comment;
    QStringList m_RxNodes;
    QStringList m_TxNodes;
    E_Direction m_Direction;
    bool m_isReqToTx; //true RTR
    unsigned int m_Cycle;
    bool m_CycleSent;
    //    E_EventType m_Event;
    unsigned int m_Channel; //0: CAN, 1: CAN1, 2: CAN2
    unsigned int m_Id;
    unsigned char m_Len;
    unsigned char m_Data[8];
    unsigned char m_LenRun;
    unsigned char m_DataRun[8];
};

typedef struct CANValueTable{
    QString m_VtName;
    QMap<unsigned long long, QString> m_VtMap;
}CANValueTable;


#endif // CANDEFINES_H
